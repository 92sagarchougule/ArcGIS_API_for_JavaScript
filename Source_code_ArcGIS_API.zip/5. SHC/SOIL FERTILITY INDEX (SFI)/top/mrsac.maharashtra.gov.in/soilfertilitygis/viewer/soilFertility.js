/**
 * @author shahana.sheikh
 */
define(["dojo/_base/declare", "dijit/registry", "dijit/_WidgetBase", "dijit/_TemplatedMixin", "dojo/text!./templates/soilFertility.html", "dojo/_base/window", "dijit/_WidgetsInTemplateMixin", "dijit/layout/AccordionContainer", "esri/Map", "esri/views/MapView", "esri/widgets/Expand", "esri/layers/KMLLayer", "esri/geometry/geometryEngine", "esri/layers/Layer", "esri/WebMap", "esri/widgets/Search", "esri/widgets/Locate", "esri/widgets/Track", "esri/Graphic", "esri/widgets/Compass", "esri/layers/MapImageLayer", "esri/widgets/CoordinateConversion", "esri/tasks/Geoprocessor", "dijit/Tooltip", "esri/tasks/support/RelationshipQuery", "esri/tasks/Locator", "esri/widgets/Home", "esri/widgets/Search", "esri/widgets/BasemapToggle", "esri/widgets/Swipe", "esri/widgets/ScaleBar", "esri/geometry/Extent", "dojo/_base/lang", "dojo/topic", "esri/config", "esri/identity/ServerInfo", "esri/identity/IdentityManager", "esri/layers/FeatureLayer", "esri/tasks/support/FeatureSet", "esri/layers/ImageryLayer", "esri/layers/MapImageLayer", "esri/tasks/ClosestFacilityTask", "esri/tasks/support/ClosestFacilityParameters", "dojo/_base/array", "dojo/on", "dojo/dom", "dojo/dom-construct", "dojo/dom-style", "dojo/dom-attr", "dojo/dom-class", "esri/symbols/PictureMarkerSymbol", "esri/renderers/SimpleRenderer", "esri/symbols/SimpleMarkerSymbol", "esri/Graphic", "esri/widgets/Popup", "esri/PopupTemplate", "dijit/TooltipDialog", "esri/core/lang", "esri/tasks/QueryTask", "esri/tasks/support/Query", "dojo/query", "dojo/store/Memory", "dijit/form/ComboBox", "dijit/form/DateTextBox", "dojo/data/ItemFileReadStore", "dijit/form/Select", "dijit/form/FilteringSelect", "esri/layers/GraphicsLayer", "esri/widgets/Sketch", "esri/geometry/Point", "esri/geometry/Circle", "esri/geometry/SpatialReference", "esri/symbols/SimpleLineSymbol", "esri/symbols/SimpleFillSymbol", "esri/Color", "esri/Graphic", "esri/request", "dojo/dom-style", "esri/widgets/Legend", "esri/tasks/FindTask", "dojo/request/xhr", 'dojo/data/ObjectStore', "dojo/request", "dojo/number", "dijit/layout/BorderContainer", "dijit/layout/TabContainer", "dijit/layout/ContentPane", "esri/renderers/UniqueValueRenderer", "dijit/TitlePane", "dijit/form/Form", "esri/widgets/BasemapGallery", "dijit/form/TextBox", "dijit/Dialog", "dijit/form/CheckBox", "dijit/form/RadioButton", "dijit/Menu", "esri/layers/ImageryLayer", "esri/layers/support/RasterFunction", "esri/layers/support/DimensionalDefinition", "esri/layers/support/MosaicRule", "dijit/MenuItem", "dijit/layout/ContentPane", "dijit/Toolbar", "dijit/form/Button", "dojox/widget/TitleGroup", "esri/core/urlUtils", "dojo/_base/json", "dojo/domReady!"], function(declare, registry, _WidgetBase, _TemplatedMixin, template, win, _WidgetsInTemplateMixin, AccordionContainer, Map, MapView, Expand, KMLLayer, geometryEngine, Layer, WebMap, Search, Locate, Track, Graphic, Compass, MapImageLayer, CoordinateConversion, Geoprocessor, Tooltip, RelationshipQuery, Locator, Home, Search, BasemapToggle, Swipe, ScaleBar, Extent, lang, topic, esriConfig, ServerInfo, esriId, FeatureLayer, FeatureSet, ImageryLayer, MapImageLayer, ClosestFacilityTask, ClosestFacilityParameters, array, on, dom, domConstruct, domStyle, domAttr, domClass, PictureMarkerSymbol, SimpleRenderer, SimpleMarkerSymbol, Graphic, Popup, PopupTemplate, TooltipDialog, esriLang, QueryTask, Query, query, Memory, ComboBox, DateTextBox, ItemFileReadStore, FilteringSelect, Select, GraphicsLayer, Sketch, Point, Circle, SpatialReference, SimpleLineSymbol, SimpleFillSymbol, Color, Graphic, esriRequest, domStyle, Legend, FindTask, xhr, ObjectStore, request, number, BorderContainer, TabContainer, ContentPane, UniqueValueRenderer, TitlePane, Form, BasemapGallery, TextBox, Dialog, CheckBox, RadioButton, Menu, ImageryLayer, RasterFunction, DimensionalDefinition, MosaicRule, urlUtils, MenuItem, json) {
	return declare("mrsac.viewer.soilFertility", [_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
		constructor : function() {
			zoneGetdivchange = [];
			zoneGetDistSoilHealth = [];
			zoneGetTalSoilHealth = [];
			zoneGetVillSoilHealth = [];
			zF = [];
			zF1 = [];
			villGraphic1 = [];
			villGraphic = [];
			graphic = [];
			distrcitCode = [];
			talukaCode = [];
			paraCode = [];
			cadastrallayer = null;

		},

		currentTab : "soilFertility",
		templateString : template,
		bufgeometry : null,

		postMixInProperties : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				alert("err" + err);
				console.error(err);
			}
		},
		postCreate : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				console.error(err);
			}
		},

		startup : function() {
			if (this._started) {

				return;
			}
			try {
				view.graphics.removeAll();
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});

				//----------------------services  used-------------
				this.state = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/0";
				this.division = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/1";
				this.district = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/2";
				this.taluka = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/3";
				this.village = "https://portal.mrsac.org.in/webadpgis8/rest/services/admin2011/admin_village_16/MapServer/0";

				featureLayer = new MapImageLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
					outFields : ["*"],
					mode : FeatureLayer.MODE_ONDEMAND,
				});
				map.add(featureLayer);

				noncropmask = new ImageryLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/noncropmask_2019/ImageServer",
					opacity : 0.3,
					id : "noncropmaskId"

				});
				map.add(noncropmask);

				graphicsTextLayer = new GraphicsLayer({
					visible : true,
					id : 'gCadText'
				});
				map.add(graphicsTextLayer);

				// console.log(noncropmask);
				dom.byId("temp").style.display = 'block';
				this.getDivision();

			} catch (err) {
				console.error("SearchWidget::startup", err);
			}

		},

		getDivision : function() {
			debugger
			zoneGetdivision = [];
			var testVals = {};
			// document.getElementById("villsoil").value = " ";
			document.getElementById("districtsoil").value = " ";
			document.getElementById("talukasoil").value = " ";
			// document.getElementById("surveyno").value = " ";

			selectDivision = document.getElementById("divisionsoil");

			queryTaskYearSown = new QueryTask(this.division);
			var queryYear = new Query();
			queryYear.outFields = ["ADVENAME ", "ADVNCODE"];
			queryYear.returnGeometry = false;
			queryYear.returnDistinctValues = true;
			queryYear.where = "1=1";

			queryTaskYearSown.execute(queryYear).then(function(featureset) {

				var result = featureset.features;

				array.forEach(result, lang.hitch(this, function(value) {

					divname = value.attributes.ADVENAME;
					divcode = value.attributes.ADVNCODE;

					if (divname) {
						if (!testVals[divname]) {
							testVals[divname] = true;
							zoneGetdivision.push({
								name : divname,
								code : divcode
							});
						}
					}
				}));

				zoneGetdivision.sort(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});

				zoneGetdivision.reverse(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				// zoneGetdivision.push({
				// name : "All",
				// code : "All"
				// });

				testValsn = {};

				array.forEach(zoneGetdivision, lang.hitch(this, function(vals) {
					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;
							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectDivision.add(option, 0);
						}
					}
				}));
				document.getElementById("divisionsoil").value = "";
				dom.byId("divLoadingIndicator").style.display = 'none';

			});
		},

		getDivChangSoil : function() {

			document.getElementById("districtsoil").value = " ";
			document.getElementById("talukasoil").value = " ";
			document.getElementById("villsoil").value = " ";
			view.graphics.removeAll();

			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.basemap = "topo";
			map.add(featureLayer);
			view.graphics.removeAll();
			map.remove(cadastrallayer);

			zoneGetDistSoilHealth = [];
			var values = [];
			var testVals = {};
			var namevalue;
			i = 1;

			map.basemap = "topo";
			selectdistsoilcard = document.getElementById("districtsoil");
			while (selectdistsoilcard.firstChild) {
				selectdistsoilcard.removeChild(selectdistsoilcard.firstChild);
			}
			divi = document.getElementById("divisionsoil").value;
			for (var i = 0; i < zoneGetdivision.length; i++) {
				if (zoneGetdivision[i].name === divi) {
					divisionCode = zoneGetdivision[i].code;
				}
			}

			queryTaskdistsoil = new QueryTask(this.district);
			var query = new Query();
			query.outFields = ["DTENAME ,DTNCODE"];
			query.returnGeometry = false;
			query.returnDistinctValues = true;
			query.where = "ADVNCODE = '" + divisionCode + "' and DTNCODE <> ''";
			query.outSpatialReference = {
				"wkid" : 102100
			};
			queryTaskdistsoil.execute(query).then(function(featureset) {
				var result = featureset.features;
				array.forEach(result, lang.hitch(this, function(value) {

					dist_name = value.attributes.DTENAME;
					dist_code = value.attributes.DTNCODE;

					if (dist_name) {
						if (!testVals[dist_name]) {
							testVals[dist_name] = true;
							zoneGetDistSoilHealth.push({
								name : dist_name,
								code : dist_code
							});
						}
					}
				}));
				zoneGetDistSoilHealth.sort(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				zoneGetDistSoilHealth.reverse(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				testValsn = {};

				array.forEach(zoneGetDistSoilHealth, lang.hitch(this, function(vals) {
					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectdistsoilcard.add(option, 0);
						}
					}
				}));
				document.getElementById("districtsoil").value = "";

			});

		},

		distChangesoilhealth : function() {

			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.basemap = "topo";
			map.add(featureLayer);
			view.graphics.removeAll();
			map.remove(cadastrallayer);

			// document.getElementById("districtsoil").value = "";
			document.getElementById("talukasoil").value = "";
			// document.getElementById("villsoil").value = "";
			// document.getElementById("surveyno").value = "";
			// map.remove(graphicsLayer);
			// map.remove(graphicsTextLayer);
			view.extent = initExtent;
			zoneGetTalSoilHealth = [];
			var testVals = {};

			selecttalsoilcard = document.getElementById("talukasoil");
			while (selecttalsoilcard.firstChild) {
				selecttalsoilcard.removeChild(selecttalsoilcard.firstChild);
			}
			distname = document.getElementById("districtsoil").value;
			for (var i = 0; i < zoneGetDistSoilHealth.length; i++) {
				if (zoneGetDistSoilHealth[i].name === distname) {
					distrcitCode = zoneGetDistSoilHealth[i].code;
				}
			}

			document.getElementById("talukasoil").value = " ";
			// document.getElementById("villsoil").value = " ";
			// document.getElementById("surveyno").value = " ";
			queryTasktalsoilcard = new QueryTask(this.taluka);

			var query = new Query();
			query.outFields = ["THENAME", "THNCODE"];
			query.returnGeometry = false;
			query.outSpatialReference = {
				"wkid" : 102100
			};
			query.returnDistinctValues = true;

			query.where = "DTNCODE = '" + distrcitCode + "'";

			queryTasktalsoilcard.execute(query).then(function(featureset) {

				var result = featureset.features;

				array.forEach(result, lang.hitch(this, function(value) {
					tal_name = value.attributes.THENAME;
					tal_code = value.attributes.THNCODE;
					if (tal_name) {
						if (!testVals[tal_name]) {
							testVals[tal_name] = true;
							zoneGetTalSoilHealth.push({
								name : tal_name,
								code : tal_code
							});
						}
					}
				}));

				zoneGetTalSoilHealth.sort(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				zoneGetTalSoilHealth.reverse(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});

				testValsn = {};
				array.forEach(zoneGetTalSoilHealth, lang.hitch(this, function(vals) {
					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selecttalsoilcard.add(option, 0);
						}
					}
				}));
				document.getElementById("talukasoil").value = "";

			});
		},

		talChangesoilhealth : function() {
			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});

			divname = document.getElementById("divisionsoil").value;
			distname = document.getElementById("districtsoil").value;
			talname = document.getElementById("talukasoil").value;
			for (var i = 0; i < zoneGetDistSoilHealth.length; i++) {
				if (zoneGetDistSoilHealth[i].name === distname) {
					distrcitCode = zoneGetDistSoilHealth[i].code;
				}
			}
			for (var i = 0; i < zoneGetTalSoilHealth.length; i++) {
				if (zoneGetTalSoilHealth[i].name === talname) {
					talukaCode = zoneGetTalSoilHealth[i].code;
				}
			}

			view.graphics.removeAll();
			map.remove(cadastrallayer);
			// map.remove(graphicsLayer);
			// map.remove(graphicsTextLayer);
			zoneGetVillSoilHealth = [];
			var testVals = {};
			distname = document.getElementById("districtsoil").value;
			talname = document.getElementById("talukasoil").value;
			selectvillsoilcard = document.getElementById("villsoil");
			while (selectvillsoilcard.firstChild) {
				selectvillsoilcard.removeChild(selectvillsoilcard.firstChild);
			}
			for (var i = 0; i < zoneGetDistSoilHealth.length; i++) {
				if (zoneGetDistSoilHealth[i].name === distname) {
					distrcitCode = zoneGetDistSoilHealth[i].code;
				}
			}
			for (var i = 0; i < zoneGetTalSoilHealth.length; i++) {
				if (zoneGetTalSoilHealth[i].name === talname) {
					talukaCode = zoneGetTalSoilHealth[i].code;
				}
			}

			document.getElementById("villsoil").value = " ";
			// document.getElementById("surveyno").value = " ";
			queryTaskvillsoilcard = new QueryTask("https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/soilfertility/MapServer/34");

			var query = new Query();
			query.outFields = ["*"];
			query.returnGeometry = false;
			query.outSpatialReference = {
				"wkid" : 102100
			};
			query.returnDistinctValues = true;

			query.where = "1=1";

			queryTaskvillsoilcard.execute(query).then(function(featureset) {

				var result = featureset.features;

				array.forEach(result, lang.hitch(this, function(value) {

					vill_name = value.attributes.name;
					vill_code = value.attributes.code;

					if (vill_name) {
						if (!testVals[vill_name]) {
							testVals[vill_name] = true;
							zoneGetVillSoilHealth.push({
								name : vill_name,
								code : vill_code
							});
						}
					}
				}));

				zoneGetVillSoilHealth.sort(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});

				zoneGetVillSoilHealth.reverse(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});

				// zoneGetVillSoilHealth.push({
				// name : "All",
				// code : "All"
				// });

				testValsn = {};

				array.forEach(zoneGetVillSoilHealth, lang.hitch(this, function(vals) {
					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectvillsoilcard.add(option, 0);
						}
					}
				}));
				document.getElementById("villsoil").value = "";

			});
		},

		submitbtnSoil : function() {
			// dom.byId("divLoadingIndicator").style.display = 'block';
			// map.removeAll(featureLayer);
			view.graphics.removeAll();
			map.removeAll(cadastrallayer);
			// view.graphics.add(graphic, 0);
			divname = document.getElementById("divisionsoil").value;
			distname = document.getElementById("districtsoil").value;
			talname = document.getElementById("talukasoil").value;
			paraname = document.getElementById("villsoil").value;
			zF.length = 0;

			// view.goTo(zF);
			dom.byId("print").style.display = 'block';
			dom.byId("legend").style.display = 'block';
			dom.byId("legend1").style.display = 'block';
			dom.byId("mainContent").style.display = 'none';

			document.getElementById("znsuf").style.display = "none";
			document.getElementById("zndesuf").style.display = "none";
			document.getElementById("fesuf").style.display = "none";
			document.getElementById("fedesuf").style.display = "none";
			document.getElementById("cusuf").style.display = "none";
			document.getElementById("cudesuf").style.display = "none";
			document.getElementById("mnsuf").style.display = "none";
			document.getElementById("mndesuf").style.display = "none";
			document.getElementById("bsuf").style.display = "none";
			document.getElementById("bdesuf").style.display = "none";
			document.getElementById("ssuf").style.display = "none";
			document.getElementById("sdesuf").style.display = "none";

			document.getElementById("nvl").style.display = "none";
			document.getElementById("nl").style.display = "none";
			document.getElementById("nm").style.display = "none";
			document.getElementById("nh").style.display = "none";
			document.getElementById("nvh").style.display = "none";
			document.getElementById("pvl").style.display = "none";
			document.getElementById("pl").style.display = "none";
			document.getElementById("pm").style.display = "none";
			document.getElementById("ph").style.display = "none";
			document.getElementById("pvh").style.display = "none";
			document.getElementById("kvl").style.display = "none";
			document.getElementById("kl").style.display = "none";
			document.getElementById("km").style.display = "none";
			document.getElementById("kh").style.display = "none";
			document.getElementById("kvh").style.display = "none";

			document.getElementById("ocvl").style.display = "none";
			document.getElementById("ocl").style.display = "none";
			document.getElementById("ocm").style.display = "none";
			document.getElementById("och").style.display = "none";
			document.getElementById("ocvh").style.display = "none";

			document.getElementById("ecn").style.display = "none";
			document.getElementById("ecgerm").style.display = "none";
			document.getElementById("ecgrow").style.display = "none";
			document.getElementById("ecsev").style.display = "none";

			document.getElementById("phstralk").style.display = "none";
			document.getElementById("phmalk").style.display = "none";
			document.getElementById("phn").style.display = "none";
			document.getElementById("phsliaci").style.display = "none";
			document.getElementById("phmaci").style.display = "none";
			document.getElementById("phstraci").style.display = "none";
			document.getElementById("phhaci").style.display = "none";
			document.getElementById("phasul").style.display = "none";

			document.getElementById("zinc").style.display = "none";
			document.getElementById("iron").style.display = "none";
			document.getElementById("copper").style.display = "none";
			document.getElementById("maganese").style.display = "none";
			document.getElementById("boron").style.display = "none";
			document.getElementById("sulfur").style.display = "none";

			document.getElementById("nitrogen").style.display = "none";
			document.getElementById("phosphorus").style.display = "none";
			document.getElementById("potassium").style.display = "none";

			document.getElementById("organic").style.display = "none";
			document.getElementById("electrical").style.display = "none";
			document.getElementById("phmain").style.display = "none";

			// console.log(talname);
			// console.log(paraname);

			if (distname === "" || talname === "") {
				swal("Please select proper input");
				view.graphics.removeAll();
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});
				map.basemap = "topo";
				view.graphics.removeAll();
				dom.byId("print").style.display = 'none';
				map.add(featureLayer);
				map.add(noncropmask);
				dom.byId("divLoadingIndicator").style.display = 'none';
			} else {
				for (var i = 0; i < zoneGetDistSoilHealth.length; i++) {
					if (zoneGetDistSoilHealth[i].name === distname) {
						distrcitCode = zoneGetDistSoilHealth[i].code;
					}
				}

				for (var i = 0; i < zoneGetTalSoilHealth.length; i++) {
					if (zoneGetTalSoilHealth[i].name === talname) {
						talukaCode = zoneGetTalSoilHealth[i].code;
					}
				}

				for (var i = 0; i < zoneGetVillSoilHealth.length; i++) {
					if (zoneGetVillSoilHealth[i].name === paraname) {
						paraCode = zoneGetVillSoilHealth[i].code;
					}
				}
				// console.log(talukaCode);
				// console.log(paraCode);

				this.featureLayer1 = new FeatureLayer(this.village, {
					mode : FeatureLayer.MODE_SNAPSHOT,
					outFields : ["*"],
				});

				this.featureLayer1.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";

				map.add(this.featureLayer1);

				// this.featureLayer2 = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/masklayer/MapServer/0", {
				// mode : FeatureLayer.MODE_SNAPSHOT,
				// outFields : ["*"],
				// });
				//
				// this.featureLayer2.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";
				//
				// map.add(this.featureLayer2);

				var data;
				var testresult;

				var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/soilfertility/MapServer?f=pjson";
				esriRequest(url, {
					responseType : "json"
				}).then(function(response) {
					// The requested data
					var geoJson = response.data;
					var layersArray = geoJson.layers;
					array.forEach(layersArray, lang.hitch(this, function(LayerAll) {
						// console.log(LayerAll.name);

						// console.log(LayerAll.id);

						if (LayerAll.name) {
							idDistLyr = LayerAll.id;
							lyerURL = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/soilfertility/MapServer/" + idDistLyr;

							if (distname === LayerAll.name) {

								cadastrallayer = new FeatureLayer({
									url : lyerURL
								});
								queryTaskvillzoomsoilcard = new QueryTask(lyerURL);

								map.add(cadastrallayer);
								debugger;
								var querypin = new Query();

								querypin.returnGeometry = true;
								querypin.outSpatialReference = {
									"wkid" : 102100
								};
								if (paraCode === "N") {
									querypin.outFields = ["N,VIL_NAME"];
									querypin.where = "THNCODE = '" + talukaCode + "' AND N IS NOT NULL ";
									cadastrallayer.definitionExpression = "THNCODE = '" + talukaCode + "' AND N IS NOT NULL ";
								} else if (paraCode === "P") {
									querypin.outFields = ["P,VIL_NAME"];
									querypin.where = "THNCODE = '" + talukaCode + "' AND P IS NOT NULL ";
									cadastrallayer.definitionExpression = "THNCODE = '" + talukaCode + "' AND P IS NOT NULL ";
								} else if (paraCode === "K") {
									querypin.outFields = ["K,VIL_NAME"];
									querypin.where = "THNCODE = '" + talukaCode + "' AND K IS NOT NULL ";
									cadastrallayer.definitionExpression = "THNCODE = '" + talukaCode + "' AND K IS NOT NULL ";
								} else if (paraCode === "Zn") {
									querypin.outFields = ["Zn,VIL_NAME"];
									querypin.where = "THNCODE = '" + talukaCode + "' AND Zn IS NOT NULL ";
									cadastrallayer.definitionExpression = "THNCODE = '" + talukaCode + "' AND Zn IS NOT NULL ";
								} else if (paraCode === "Fe") {
									querypin.outFields = ["Fe,VIL_NAME"];
									querypin.where = "THNCODE = '" + talukaCode + "' AND Fe IS NOT NULL ";
									cadastrallayer.definitionExpression = "THNCODE = '" + talukaCode + "' AND Fe IS NOT NULL ";
								} else if (paraCode === "Cu") {
									querypin.outFields = ["Cu,VIL_NAME"];
									querypin.where = "THNCODE = '" + talukaCode + "' AND Cu IS NOT NULL ";
									cadastrallayer.definitionExpression = "THNCODE = '" + talukaCode + "' AND Cu IS NOT NULL ";
								} else if (paraCode === "Mn") {
									querypin.outFields = ["Mn,VIL_NAME"];
									querypin.where = "THNCODE = '" + talukaCode + "' AND Mn IS NOT NULL ";
									cadastrallayer.definitionExpression = "THNCODE = '" + talukaCode + "' AND Mn IS NOT NULL ";
								} else if (paraCode === "B") {
									querypin.outFields = ["B,VIL_NAME"];
									querypin.where = "THNCODE = '" + talukaCode + "' AND B IS NOT NULL ";
									cadastrallayer.definitionExpression = "THNCODE = '" + talukaCode + "' AND B IS NOT NULL ";
								} else if (paraCode === "S") {
									querypin.outFields = ["S,VIL_NAME"];
									querypin.where = "THNCODE = '" + talukaCode + "' AND S IS NOT NULL ";
									cadastrallayer.definitionExpression = "THNCODE = '" + talukaCode + "' AND S IS NOT NULL ";
								} else if (paraCode === "OC") {
									querypin.outFields = ["OC,VIL_NAME"];
									querypin.where = "THNCODE = '" + talukaCode + "' AND OC IS NOT NULL ";
									cadastrallayer.definitionExpression = "THNCODE = '" + talukaCode + "' AND OC IS NOT NULL ";
								} else if (paraCode === "pH") {
									querypin.outFields = ["pH,VIL_NAME"];
									querypin.where = "THNCODE = '" + talukaCode + "' AND pH IS NOT NULL ";
									cadastrallayer.definitionExpression = "THNCODE = '" + talukaCode + "' AND pH IS NOT NULL ";
								} else if (paraCode === "EC") {
									querypin.outFields = ["EC,VIL_NAME"];
									querypin.where = "THNCODE = '" + talukaCode + "' AND EC IS NOT NULL ";
									cadastrallayer.definitionExpression = "THNCODE = '" + talukaCode + "' AND EC IS NOT NULL ";
								}

								// querypin.where = "THNCODE = '" + talukaCode + "'";
								// cadastrallayer.definitionExpression = "THNCODE = '" + talukaCode + "'";

								map.add(cadastrallayer);
								console.log(querypin.where);
								// console.log(cadastrallayer.definitionExpression);
								// map.basemap = "";
								queryTaskvillzoomsoilcard.execute(querypin).then(function(featureset) {

									var result_features = featureset.features;

									if (result_features.length === 0) {
										swal("No Data Available");
									} else {

										array.forEach(result_features, lang.hitch(this, function(value) {

											oc = value.attributes.OC;
											ec = value.attributes.EC;
											ph = value.attributes.pH;
											fe = value.attributes.Fe;
											b = value.attributes.B;
											cu = value.attributes.Cu;
											mn = value.attributes.Mn;
											s = value.attributes.S;
											zn = value.attributes.Zn;
											n = value.attributes.N;
											p = value.attributes.P;
											k = value.attributes.K;

											village = value.attributes.VIL_NAME;

											// console.log(n);
											// console.log(p);
											// console.log(k);
											bufgeometry = value.geometry;
											zF.push(value);
											var symbol = {
												type : "simple-line", // autocasts as new SimpleLineSymbol()
												color : "gray",
												width : "0.05px",
												style : "solid"
											};
											var districtGraphic = new Graphic(value.geometry, symbol);
											// view.graphics.add(districtGraphic, 0);
											view.goTo(zF);
											geomextent = value.geometry.extent;
											ringgeom = value.geometry.rings;
											areageom = value.geometry;

											dom.byId("divLoadingIndicator").style.display = 'none';
											dom.byId("viewDiv").style.cursor = 'pointer';

											//-------------------fill poly------------------

											// console.log(gtext);

											if (zn % 1 === 0) {
												document.getElementById("zinc").style.display = "block";
											}

											if (zn <= 40) {
												// alert();
												// debugger;
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(158,215,194)",
													// width : "1px",
													// style : "solid"
													outline : {// autocasts as new SimpleLineSymbol()
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("znsuf").style.display = "block";
												//document.getElementById("zinc").style.display = "block";

											}
											if (zn >= 40 && zn <= 100) {
												// alert();
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,215,158)",
													// width : "1px",
													// style : "solid"
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("zndesuf").style.display = "block";

											}

											if (fe % 1 === 0) {
												document.getElementById("iron").style.display = "block";
											}

											if (fe <= 40) {
												// alert();
												// debugger;
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(158,215,194)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 1);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("fesuf").style.display = "block";
												//document.getElementById("iron").style.display = "block";
											}
											if (fe >= 40 && fe <= 100) {
												// alert();
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,215,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 1);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("fedesuf").style.display = "block";
											}

											if (cu % 1 === 0) {
												document.getElementById("copper").style.display = "block";
											}

											if (cu <= 40) {
												// alert();
												// debugger;
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(158,215,194)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("cusuf").style.display = "block";
												//document.getElementById("copper").style.display = "block";
											}
											if (cu >= 40 && cu <= 100) {
												// alert();
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,215,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("cudesuf").style.display = "block";
											}

											if (mn % 1 === 0) {
												document.getElementById("maganese").style.display = "block";
											}

											if (mn <= 40) {
												// alert();
												// debugger;
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(158,215,194)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("mnsuf").style.display = "block";
												//document.getElementById("maganese").style.display = "block";
											}
											if (mn >= 40 && mn <= 100) {
												// alert();
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,215,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("mndesuf").style.display = "block";
											}

											if (b % 1 === 0) {
												document.getElementById("boron").style.display = "block";
											}

											if (b <= 40) {
												// alert();
												// debugger;
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(158,215,194)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("bsuf").style.display = "block";
												//document.getElementById("boron").style.display = "block";
											}
											if (b >= 40 && b <= 100) {
												// alert();
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,215,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("bdesuf").style.display = "block";
											}

											if (s % 1 === 0) {
												document.getElementById("sulfur").style.display = "block";
											}

											if (s <= 40) {
												// alert();
												// debugger;
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(158,215,194)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("ssuf").style.display = "block";
												//document.getElementById("sulfur").style.display = "block";
											}

											if (s >= 40 && s <= 100) {
												// alert();
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,215,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("sdesuf").style.display = "block";
											}

											if (n % 1 === 0) {
												//alert();
												document.getElementById("nitrogen").style.display = "block";
											}

											if (n <= 0.75) {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,215,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("nvl").style.display = "block";
												//document.getElementById("nitrogen").style.display = "block";
											}
											if (n >= 0.76 & n <= 1.25) {
												// alert();
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(158,215,194)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("nl").style.display = "block";

											}
											if (n >= 1.26 & n <= 2.25) {
												// alert();
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(205,245,122)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("nm").style.display = "block";
											}
											if (n >= 2.26 & n <= 2.75) {
												// alert();
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,158,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("nh").style.display = "block";
											}
											if (n >= 2.76 & n <= 3) {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(137,112,68)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("nvh").style.display = "block";
											}

											if (p % 1 === 0) {
												document.getElementById("phosphorus").style.display = "block";
											}
											//-------------p---------------
											if (p <= 0.75) {
												// alert();
												// debugger;
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,215,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("pvl").style.display = "block";
												//document.getElementById("phosphorus").style.display = "block";
											}
											if (p >= 0.76 & p <= 1.25) {
												// alert();
												// debugger;

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(158,215,194)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("pl").style.display = "block";

											}
											if (p >= 1.26 & p <= 2.25) {
												// alert();
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(205,245,122)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("pm").style.display = "block";

											}
											if (p >= 2.26 & p <= 2.75) {
												// alert();

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,158,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("ph").style.display = "block";

											}
											if (p >= 2.76 & p <= 3) {
												// alert();
												// debugger;
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(137,112,68)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("pvh").style.display = "block";
											}

											if (k % 1 === 0) {
												document.getElementById("potassium").style.display = "block";
											}

											if (k <= 0.75) {
												// alert();
												// debugger;
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,215,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("kvl").style.display = "block";
												//document.getElementById("potassium").style.display = "block";
											}
											if (k >= 0.76 & k <= 1.25) {
												// alert();
												// debugger;

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(158,215,194)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("kl").style.display = "block";
											}
											if (k >= 1.26 & k <= 2.25) {
												// alert();
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(205,245,122)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("km").style.display = "block";
											}
											if (k >= 2.26 & k <= 2.75) {
												// alert();

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,158,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("kh").style.display = "block";
											}
											if (k >= 2.76 & k <= 3) {
												// alert();
												// debugger;
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(137,112,68)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("kvh").style.display = "block";
											}

											if (oc % 1 === 0) {
												document.getElementById("organic").style.display = "block";
											}

											if (oc === "Very Low(0.2)") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(217,240,209)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("ocvl").style.display = "block";
												//document.getElementById("organic").style.display = "block";
											}
											if (oc === "Low(0.21-0.40)") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(205,245,122)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("ocl").style.display = "block";
											}
											if (oc === "Moderate(0.41-0.60)") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(180,215,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("ocm").style.display = "block";
											}
											if (oc === "High(0.61-1)") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(114,137,68)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("och").style.display = "block";
											}
											if (oc === "Very High(>1 )") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(137,112,68)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("ocvh").style.display = "block";
											}

											console.log(ec);

											if (ec % 1 === 0) {
												document.getElementById("electrical").style.display = "block";
											}
											if (ec === "Normal(< 1)") {
												// debugger;
												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(158,215,194)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("ecn").style.display = "block";
												//document.getElementById("electrical").style.display = "block";
											}
											if (ec === "Critical for Germination") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,215,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("ecgerm").style.display = "block";
											}
											if (ec === "Critical for Growth") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(194,158,215)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("ecgrow").style.display = "block";
											}
											if (ec === "Severe Injury to Crop") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(205,102,102)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("ecsev").style.display = "block";
											}

											if (ph % 1 === 0) {
												document.getElementById("phmain").style.display = "block";
											}
											if (ph === " Acid Sulphate(< 4.5)") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(112,68,137)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("phasul").style.display = "block";
												//document.getElementById("phmain").style.display = "block";
											}
											if (ph === "Highly Acidic(4.5-5.0)") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(112,68,137)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("phhaci").style.display = "block";
											}
											if (ph === "Strongly Acidic(5.1-5.5)") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(255,235,175)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("phstraci").style.display = "block";
											}
											if (ph === "Moderately Acidic(5.6-6.0)") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(194,158,215)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("phmaci").style.display = "block";
											}
											if (ph === "Slightly Acidic(6.1-6.5)") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(232,222,255)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("phsliaci").style.display = "block";
											}
											if (ph === "Neutral(6.6-7.3)") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(245,245,122)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("phn").style.display = "block";
											}
											if (ph === "Moderately Alkaline(7.4-8.4)") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(215,194,158)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("phmalk").style.display = "block";
											}
											if (ph === "Strongly Alkaline(> 8.5)") {

												bufgeometry = value.geometry;
												zF.push(value);
												var symbol = {
													type : "simple-fill", // autocasts as new SimpleLineSymbol()
													color : "rgb(137,68,68)",
													outline : {
														color : "gray",
														width : "0.5px"
													}
												};
												var districtGraphic = new Graphic(value.geometry, symbol);
												view.graphics.add(districtGraphic, 0);
												view.goTo(zF);
												geomextent = value.geometry.extent;
												ringgeom = value.geometry.rings;
												areageom = value.geometry;
												document.getElementById("phstralk").style.display = "block";
											}

											distLayer = new FeatureLayer({
												url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/masklayer/MapServer/0",
												id : "distLayerDisplay"
											});
											distLayer.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";
											map.add(distLayer);

											dom.byId("divLoadingIndicator").style.display = 'none';

										}));
									}
								});

								// }else {
								// alert();
							}

						}

					}));
				});

			}

			if ((divname != "All" && distname != "All" && talname != "All")) {
				var taluka_LayerUrlZm = this.taluka;
				var queryTaskZm = new QueryTask({
					url : taluka_LayerUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";

				talLayer = new FeatureLayer({
					url : this.taluka,
					id : "talLayerDisplay"
				});
				talLayer.definitionExpression = queryZm.where;
				map.add(talLayer);

			}
			// console.log(queryZm.where);
			queryTaskZm.execute(queryZm).then(function(results) {
				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {
					bufgeometry = value.geometry;
					zF1.push(value);
					var symbol = {
						type : "simple-line", // autocasts as new SimpleLineSymbol()
						color : "black",
						width : "2px",
						style : "solid"
					};
					var districtGraphic = new Graphic(value.geometry, symbol);
					view.graphics.add(districtGraphic, 0);
					// view.goTo(zF1);
					geomextent = value.geometry.extent;
					ringgeom = value.geometry.rings;
					areageom = value.geometry;

				}));

			});

		},
		generatemap : function() {

			dom.byId("divLoadingIndicator").style.display = 'block';
			divname = document.getElementById("divisionsoil").value;
			distname = document.getElementById("districtsoil").value;
			talname = document.getElementById("talukasoil").value;
			paraname = document.getElementById("villsoil").value;

			for (var i = 0; i < zoneGetdivision.length; i++) {
				if (zoneGetdivision[i].name === divname) {
					divisionCode = zoneGetdivision[i].code;
				}
			}

			for (var i = 0; i < zoneGetDistSoilHealth.length; i++) {
				if (zoneGetDistSoilHealth[i].name === distname) {
					distrcitCode = zoneGetDistSoilHealth[i].code;
				}
			}
			for (var i = 0; i < zoneGetTalSoilHealth.length; i++) {
				if (zoneGetTalSoilHealth[i].name === talname) {
					talukaCode = zoneGetTalSoilHealth[i].code;
				}
			}

			for (var i = 0; i < zoneGetVillSoilHealth.length; i++) {
				if (zoneGetVillSoilHealth[i].name === paraname) {
					paraCode = zoneGetVillSoilHealth[i].code;
				}
			}

			// console.log(distrcitCode);
			var gpUrl = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/soilfertilitytempnew/GPServer/soilfertilitytempnew";
			var gp = new Geoprocessor(gpUrl);
			var parameters = {
				"division" : divname,
				"district" : distname,
				"taluka" : talname,
				"div_cd" : divisionCode,
				"dist_cd" : distrcitCode,
				"tal_cd" : talukaCode,
				"parameter" : paraCode
			};

			// console.log(parameters);
			gp.execute(parameters).then(ShowResultData);

			function ShowResultData(result) {
				// alert(result);
				// console.log(result.results[0].value);
				var resultImg = result.results[0].value.url;
				var center_left = (screen.width / 2.5) - (400 / 2);
				var center_top = (screen.height / 2.5) - (400 / 2);
				window.open(resultImg, target = '_blank', 'width=1000,height=750, top=' + center_top + ', left=' + center_left);
				dom.byId("divLoadingIndicator").style.display = 'none';
			}

		},

		clear : function() {

			view.graphics.removeAll();
			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.basemap = "topo";

			map.removeAll(cadastrallayer);
			map.remove(this.featureLayer1);
			document.getElementById("districtsoil").value = "";
			document.getElementById("talukasoil").value = "";
			document.getElementById("villsoil").value = "";
			document.getElementById("divisionsoil").value = "";
			dom.byId("print").style.display = 'none';
			dom.byId("legend").style.display = 'none';
			dom.byId("legend1").style.display = 'none';
			dom.byId("mainContent").style.display = 'none';
			featureLayer = new MapImageLayer({
				url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
				outFields : ["*"],
				mode : FeatureLayer.MODE_ONDEMAND,
			});
			map.add(featureLayer);
			map.add(noncropmask);
		},

		ViewReport : function() {
			debugger;
			divname = document.getElementById("divisionsoil").value;
			distname = document.getElementById("districtsoil").value;
			talname = document.getElementById("talukasoil").value;
			paraname = document.getElementById("villsoil").value;

			console.log(paraname);

			if (divname === "" || distname === "") {
				swal("Please select proper input");
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});
				map.basemap = "topo";
				view.graphics.removeAll();
				dom.byId("print").style.display = 'none';
				map.add(featureLayer);
				map.add(noncropmask);
				dom.byId("divLoadingIndicator").style.display = 'none';
			} else {

				for (var i = 0; i < zoneGetdivision.length; i++) {
					if (zoneGetdivision[i].name === divname) {
						divisionCode = zoneGetdivision[i].code;
					}
				}

				for (var i = 0; i < zoneGetDistSoilHealth.length; i++) {
					if (zoneGetDistSoilHealth[i].name === distname) {
						distrcitCode = zoneGetDistSoilHealth[i].code;
					}
				}
				for (var i = 0; i < zoneGetTalSoilHealth.length; i++) {
					if (zoneGetTalSoilHealth[i].name === talname) {
						talukaCode = zoneGetTalSoilHealth[i].code;
					}
				}

				for (var i = 0; i < zoneGetVillSoilHealth.length; i++) {
					if (zoneGetVillSoilHealth[i].name === paraname) {
						paraCode = zoneGetVillSoilHealth[i].code;
					}
				}
				var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/soilfertility/MapServer?f=pjson";
				esriRequest(url, {
					responseType : "json"
				}).then(function(response) {
					// The requested data
					var geoJson = response.data;
					var layersArray = geoJson.layers;
					array.forEach(layersArray, lang.hitch(this, function(LayerAll) {

						if (distname === LayerAll.name) {
							idDistLyr = LayerAll.id;

							document.getElementById("mainContent").style.display = "block";
							// var str = "EC (Electrical Conductivity)";
							str = paraname.split("(");
							console.log(str);
							str = $.trim(str[0]) + "(" + $.trim(str[1]);
							str=str.trim().replace(/\s/g, '%20');
							console.log(str);

							$("#mainContent").load("http://117.240.213.118:6080/cropacreagereport1/soilfertility?distServCode=" + idDistLyr + "&dtnCode=" + distrcitCode + "&thnCode=" + talukaCode + "&nutrient=" + str + "&division_n=" + divname + "&district_n=" + distname + "&circle_n=All&taluka_n=" + talname, function() {
								//alert("Load was performed.");
								$('#datatable').DataTable();
							});

						}
					}));
				});
			}
		},
	});
});
