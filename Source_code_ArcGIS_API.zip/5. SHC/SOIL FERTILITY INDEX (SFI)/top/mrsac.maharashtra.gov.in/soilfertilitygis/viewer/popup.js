

// function getImage() 
// {
 
//   var element=document.getElementById("villsoil").value;
//   str = element.split("(");
//   str = $.trim(str[0]) ;
//   console.log(str);

//       if(str=='OC'||str=='EC'||str=='pH')
//       {
//         swal("Image Not Present!"," ","info");
//       }
      

//       else
//       {

//       var img_path = "./images/fertility_images/"+str+"_IDW.jpg";

//       console.log(img_path);


//       let text = "\n\n Would you like to download the Image";

//       if (confirm(text) == true) 
//       {
//         // text = "You pressed OK!";
//         // window.location.href = url;

//       window4 = window.open(img_path);

//       window4.document.write('<img src="'+img_path+'" width="500">');
      
//       window4.document.write('<a href="'+img_path+'" download><button type="button">Download</button></a>');


//       // const a = document.createElement("a");
//       // a.href = img_path;
//       // a.download = "myFile.jpg";
//       // a.click();


     

//       }
//       else {}

//       }

//     }


function getImage()
{
  var str=document.getElementById("nutrient-list").value;
  console.log(str);

  if(str=='#')
  {
    swal( "Please Select Valid Input");
  }
  else
  {
    //var img_path = "./images/fertility_images/"+str+"_IDW.jpg";
	var img_path = "./images/fertility_images_NEW/"+str+"_Maha.jpg";
  // console.log(img_path);

                  window4 =window.open(img_path,'_blank',"width=1200,height=900,titlebar=no,status=no,top=120,left=370");

                  window4.document.write('<img src="'+img_path+'" width="1200 "  >');
        
                  //window4.document.write('<a href="'+img_path+'"   download><button type="button" style="float:right; background-color:#0c70b6; color:white; border-radius:3px;" >Download</button></a>');
				  window4.document.write('<a href="'+img_path+'"   download><button type="button" style="float:right; background-color:#0c70b6; color:white; border-radius:3px; margin-right: 20px;" >Download</button></a>');

  }
  


}



// var img_path
// function getImage()
//     {


//       var element=document.getElementById("villsoil").value;
//       str = element.split("(");
//       str = $.trim(str[0]) ;
//       console.log(str);

//       // if(str.length > 1)
//       // {

//       // }

//       if(str=='OC'||str=='EC'||str=='pH')
//       {
//         swal("Image Not Present!"," ","info");
//       }
      

//       else
//       {

//        img_path = "./images/fertility_images/"+str+"_IDW.jpg";
//       // console.log(str);




//         // swal({
//         //         title: "Download",
//         //         text: "Do you want to download this file !",
//         //         icon: "info",
//         //         buttons: true,
//         //         infoMode: true,
//         //       })

//     //     .then((okButton) => {
//     //         if (okButton) 
//     //         {
//     //             // swal("Poof! Your imaginary file has been deleted!", {
//     //             //   icon: "success",
//     //             // });

//     //             // const a = document.createElement("a");
//     //             //                 a.href = img_path;
//     //             //                 a.download = "myFile.png";
//     //             //                 a.click();

//                 // window4 = window.open(img_path);

//                 window4 =window.open(img_path,'_blank',"width=1200,height=900,titlebar=no,status=no,top=120,left=170");

//                 window4.document.write('<img src="'+img_path+'" width="1200 " >');
      
//                 window4.document.write('<a href="'+img_path+'" download><button type="button">Download</button></a>');


//     //         } 
//     //         else 
//     //         {
//     //             // swal("Your imaginary file is safe!");
//     //         }
//     // });
//     }}

