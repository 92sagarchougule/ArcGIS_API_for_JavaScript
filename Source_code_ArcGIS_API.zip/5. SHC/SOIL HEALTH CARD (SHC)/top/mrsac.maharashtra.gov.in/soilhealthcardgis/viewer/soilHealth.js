/**
 * @author shahana.sheikh
 */
define(["dojo/_base/declare", "dijit/registry", "dijit/_WidgetBase", "dijit/_TemplatedMixin", "dojo/text!./templates/soilHealth.html", "dojo/_base/window", "dijit/_WidgetsInTemplateMixin", "dijit/layout/AccordionContainer", "esri/Map", "esri/views/MapView", "esri/widgets/Expand", "esri/layers/KMLLayer", "esri/geometry/geometryEngine", "esri/layers/Layer", "esri/WebMap", "esri/widgets/Search", "esri/widgets/Locate", "esri/widgets/Track", "esri/Graphic", "esri/widgets/Compass", "esri/layers/MapImageLayer", "esri/widgets/CoordinateConversion", "esri/tasks/Geoprocessor", "dijit/Tooltip", "esri/tasks/support/RelationshipQuery", "esri/tasks/Locator", "esri/widgets/Home", "esri/widgets/Search", "esri/widgets/BasemapToggle", "esri/widgets/Swipe", "esri/widgets/ScaleBar", "esri/geometry/Extent", "dojo/_base/lang", "dojo/topic", "esri/config", "esri/identity/ServerInfo", "esri/identity/IdentityManager", "esri/layers/FeatureLayer", "esri/tasks/support/FeatureSet", "esri/layers/ImageryLayer", "esri/layers/MapImageLayer", "esri/tasks/ClosestFacilityTask", "esri/tasks/support/ClosestFacilityParameters", "dojo/_base/array", "dojo/on", "dojo/dom", "dojo/dom-construct", "dojo/dom-style", "dojo/dom-attr", "dojo/dom-class", "esri/symbols/PictureMarkerSymbol", "esri/renderers/SimpleRenderer", "esri/symbols/SimpleMarkerSymbol", "esri/Graphic", "esri/widgets/Popup", "esri/PopupTemplate", "dijit/TooltipDialog", "esri/core/lang", "esri/tasks/QueryTask", "esri/tasks/support/Query", "dojo/query", "dojo/store/Memory", "dijit/form/ComboBox", "dijit/form/DateTextBox", "dojo/data/ItemFileReadStore", "dijit/form/Select", "dijit/form/FilteringSelect", "esri/layers/GraphicsLayer", "esri/widgets/Sketch", "esri/geometry/Point", "esri/geometry/Circle", "esri/geometry/SpatialReference", "esri/symbols/SimpleLineSymbol", "esri/symbols/SimpleFillSymbol", "esri/Color", "esri/Graphic", "esri/request", "dojo/dom-style", "esri/widgets/Legend", "esri/tasks/FindTask", "dojo/request/xhr", 'dojo/data/ObjectStore', "dojo/request", "dojo/number", "dijit/layout/BorderContainer", "dijit/layout/TabContainer", "dijit/layout/ContentPane", "dijit/TitlePane", "dijit/form/Form", "esri/widgets/BasemapGallery", "dijit/form/TextBox", "dijit/Dialog", "dijit/form/CheckBox", "dijit/form/RadioButton", "dijit/Menu", "esri/layers/ImageryLayer", "esri/layers/support/RasterFunction", "esri/layers/support/DimensionalDefinition", "esri/layers/support/MosaicRule", "dijit/MenuItem", "dijit/layout/ContentPane", "dijit/Toolbar", "dijit/form/Button", "dojox/widget/TitleGroup", "esri/core/urlUtils", "dojo/_base/json", "dojo/domReady!"], function(declare, registry, _WidgetBase, _TemplatedMixin, template, win, _WidgetsInTemplateMixin, AccordionContainer, Map, MapView, Expand, KMLLayer, geometryEngine, Layer, WebMap, Search, Locate, Track, Graphic, Compass, MapImageLayer, CoordinateConversion, Geoprocessor, Tooltip, RelationshipQuery, Locator, Home, Search, BasemapToggle, Swipe, ScaleBar, Extent, lang, topic, esriConfig, ServerInfo, esriId, FeatureLayer, FeatureSet, ImageryLayer, MapImageLayer, ClosestFacilityTask, ClosestFacilityParameters, array, on, dom, domConstruct, domStyle, domAttr, domClass, PictureMarkerSymbol, SimpleRenderer, SimpleMarkerSymbol, Graphic, Popup, PopupTemplate, TooltipDialog, esriLang, QueryTask, Query, query, Memory, ComboBox, DateTextBox, ItemFileReadStore, FilteringSelect, Select, GraphicsLayer, Sketch, Point, Circle, SpatialReference, SimpleLineSymbol, SimpleFillSymbol, Color, Graphic, esriRequest, domStyle, Legend, FindTask, xhr, ObjectStore, request, number, BorderContainer, TabContainer, ContentPane, TitlePane, Form, BasemapGallery, TextBox, Dialog, CheckBox, RadioButton, Menu, ImageryLayer, RasterFunction, DimensionalDefinition, MosaicRule, urlUtils, MenuItem, json) {
	return declare("mrsac.viewer.soilHealth", [_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
		constructor : function() {
			zoneGetdivchange = [];
			zoneGetDistSoilHealth = [];
			zoneGetTalSoilHealth = [];
			zoneGetVillSoilHealth = [];
			zF = [];
			villGraphic1 = [];
			villGraphic = [];
			graphic = [];
			distrcitCode = [];
			talukaCode = [];
			villageCode = [];
			cadastrallayer = null;

		},

		currentTab : "soilhealth",
		templateString : template,
		bufgeometry : null,

		postMixInProperties : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				alert("err" + err);
				console.error(err);
			}
		},
		postCreate : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				console.error(err);
			}
		},

		startup : function() {
			if (this._started) {

				return;
			}
			try {
				view.graphics.removeAll();
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});

				//----------------------services  used-------------
				this.state = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/0";
				this.division = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/1";
				this.district = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/2";
				this.taluka = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/3";
				this.village = "https://portal.mrsac.org.in/webadpgis8/rest/services/admin2011/admin_village_16/MapServer/0";

				featureLayer = new MapImageLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
					outFields : ["*"],
					mode : FeatureLayer.MODE_ONDEMAND,
				});
				map.add(featureLayer);

				noncropmask = new ImageryLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/noncropmask_2019/ImageServer",
					opacity : 0.3,
					id : "noncropmaskId"

				});
				map.add(noncropmask);
				// console.log(noncropmask);
				
				//----------------------------------------
				 graphicsLayer = new GraphicsLayer({
                visible: true,
                        id: 'selectedGraphics',
                        title :'Cadastral Boundary',
                        listMode:"hide",
                        
                });
                
                 graphicsLayer1 = new GraphicsLayer({
                visible: true,
                        id: 'GraphicsLayer',
                        title :'Cadastral Boundary',
                        listMode:"hide",
                        
                });
                //=========================================

				this.getDivision();

			} catch (err) {
				console.error("SearchWidget::startup", err);
			}

		},

		getDivision : function() {
			// debugger
			zoneGetdivision = [];
			var testVals = {};
			document.getElementById("villsoil").value = " ";
			document.getElementById("districtsoil").value = " ";
			document.getElementById("talukasoil").value = " ";
			document.getElementById("surveyno").value = " ";

			selectDivision = document.getElementById("divisionsoil");

			queryTaskYearSown = new QueryTask(this.division);
			var queryYear = new Query();
			queryYear.outFields = ["ADVENAME ", "ADVNCODE"];
			queryYear.returnGeometry = false;
			queryYear.returnDistinctValues = true;
			queryYear.where = "1=1";

			queryTaskYearSown.execute(queryYear).then(function(featureset) {

				var result = featureset.features;

				array.forEach(result, lang.hitch(this, function(value) {

					divname = value.attributes.ADVENAME;
					divcode = value.attributes.ADVNCODE;

					if (divname) {
						if (!testVals[divname]) {
							testVals[divname] = true;
							zoneGetdivision.push({
								name : divname,
								code : divcode
							});
						}
					}
				}));

				zoneGetdivision.sort(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});

				zoneGetdivision.reverse(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				// zoneGetdivision.push({
				// name : "All",
				// code : "All"
				// });

				testValsn = {};

				array.forEach(zoneGetdivision, lang.hitch(this, function(vals) {
					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;
							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectDivision.add(option, 0);
						}
					}
				}));
				document.getElementById("divisionsoil").value = "";
				dom.byId("divLoadingIndicator").style.display = 'none';

			});
		},

		getDivChangSoil : function() {
			document.getElementById("villsoil").value = " ";
			document.getElementById("districtsoil").value = " ";
			document.getElementById("talukasoil").value = " ";
			document.getElementById("surveyno").value = " ";

			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.basemap = "topo";
			map.add(featureLayer);
			view.graphics.removeAll();

			zoneGetDistSoilHealth = [];
			var values = [];
			var testVals = {};
			var namevalue;
			i = 1;

			map.basemap = "topo";
			selectdistsoilcard = document.getElementById("districtsoil");
			while (selectdistsoilcard.firstChild) {
				selectdistsoilcard.removeChild(selectdistsoilcard.firstChild);
			}

			divi = document.getElementById("divisionsoil").value;
			for (var i = 0; i < zoneGetdivision.length; i++) {
				if (zoneGetdivision[i].name === divi) {
					divisionCode = zoneGetdivision[i].code;
				}
			}

			queryTaskdistsoil = new QueryTask(this.district);
			var query = new Query();
			query.outFields = ["DTENAME ,DTNCODE"];
			query.returnGeometry = false;
			query.returnDistinctValues = true;
			query.where = "ADVNCODE = '" + divisionCode + "' and DTNCODE <> ''";
			query.outSpatialReference = {
				"wkid" : 102100
			};
			queryTaskdistsoil.execute(query).then(function(featureset) {
				var result = featureset.features;
				array.forEach(result, lang.hitch(this, function(value) {

					dist_name = value.attributes.DTENAME;
					dist_code = value.attributes.DTNCODE;

					if (dist_name) {
						if (!testVals[dist_name]) {
							testVals[dist_name] = true;
							zoneGetDistSoilHealth.push({
								name : dist_name,
								code : dist_code
							});
						}
					}
				}));
				zoneGetDistSoilHealth.sort(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				zoneGetDistSoilHealth.reverse(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				testValsn = {};

				array.forEach(zoneGetDistSoilHealth, lang.hitch(this, function(vals) {
					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectdistsoilcard.add(option, 0);
						}
					}
				}));
				document.getElementById("districtsoil").value = "";

			});

		},

		distChangesoilhealth : function() {

			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.basemap = "topo";
			map.add(featureLayer);
			view.graphics.removeAll();

			// document.getElementById("districtsoil").value = "";
			document.getElementById("talukasoil").value = "";
			document.getElementById("villsoil").value = "";
			document.getElementById("surveyno").value = "";
			// map.remove(graphicsLayer);
			// map.remove(graphicsTextLayer);
			view.extent = initExtent;
			zoneGetTalSoilHealth = [];
			var testVals = {};

			selecttalsoilcard = document.getElementById("talukasoil");
			while (selecttalsoilcard.firstChild) {
				selecttalsoilcard.removeChild(selecttalsoilcard.firstChild);
			}
			distname = document.getElementById("districtsoil").value;
			for (var i = 0; i < zoneGetDistSoilHealth.length; i++) {
				if (zoneGetDistSoilHealth[i].name === distname) {
					distrcitCode = zoneGetDistSoilHealth[i].code;
				}
			}

			document.getElementById("talukasoil").value = " ";
			document.getElementById("villsoil").value = " ";
			document.getElementById("surveyno").value = " ";
			queryTasktalsoilcard = new QueryTask(this.taluka);

			var query = new Query();
			query.outFields = ["THENAME", "THNCODE"];
			query.returnGeometry = false;
			query.outSpatialReference = {
				"wkid" : 102100
			};
			query.returnDistinctValues = true;

			query.where = "DTNCODE = '" + distrcitCode + "'";

			queryTasktalsoilcard.execute(query).then(function(featureset) {

				var result = featureset.features;

				array.forEach(result, lang.hitch(this, function(value) {
					tal_name = value.attributes.THENAME;
					tal_code = value.attributes.THNCODE;
					if (tal_name) {
						if (!testVals[tal_name]) {
							testVals[tal_name] = true;
							zoneGetTalSoilHealth.push({
								name : tal_name,
								code : tal_code
							});
						}
					}
				}));

				zoneGetTalSoilHealth.sort(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				zoneGetTalSoilHealth.reverse(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});

				testValsn = {};
				array.forEach(zoneGetTalSoilHealth, lang.hitch(this, function(vals) {
					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selecttalsoilcard.add(option, 0);
						}
					}
				}));
				document.getElementById("talukasoil").value = "";

			});
		},

		talChangesoilhealth : function() {
			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			// map.basemap = "";

			view.graphics.removeAll();
			// map.remove(graphicsLayer);
			// map.remove(graphicsTextLayer);
			zoneGetVillSoilHealth = [];
			var testVals = {};
			distname = document.getElementById("districtsoil").value;
			talname = document.getElementById("talukasoil").value;
			selectvillsoilcard = document.getElementById("villsoil");
			while (selectvillsoilcard.firstChild) {
				selectvillsoilcard.removeChild(selectvillsoilcard.firstChild);
			}
			for (var i = 0; i < zoneGetDistSoilHealth.length; i++) {
				if (zoneGetDistSoilHealth[i].name === distname) {
					distrcitCode = zoneGetDistSoilHealth[i].code;
				}
			}
			for (var i = 0; i < zoneGetTalSoilHealth.length; i++) {
				if (zoneGetTalSoilHealth[i].name === talname) {
					talukaCode = zoneGetTalSoilHealth[i].code;
				}
			}

			document.getElementById("villsoil").value = " ";
			document.getElementById("surveyno").value = " ";
			queryTaskvillsoilcard = new QueryTask(this.village);

			var query = new Query();
			query.outFields = ["VIL_NAME", "VINCODE"];
			query.returnGeometry = false;
			query.outSpatialReference = {
				"wkid" : 102100
			};
			query.returnDistinctValues = true;

			query.where = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";

			queryTaskvillsoilcard.execute(query).then(function(featureset) {

				var result = featureset.features;

				array.forEach(result, lang.hitch(this, function(value) {

					vill_name = value.attributes.VIL_NAME;
					vill_code = value.attributes.VINCODE;
					if (vill_name) {
						if (!testVals[vill_name]) {
							testVals[vill_name] = true;
							zoneGetVillSoilHealth.push({
								name : vill_name,
								code : vill_code
							});
						}
					}
				}));

				zoneGetVillSoilHealth.sort(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				zoneGetVillSoilHealth.reverse(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				testValsn = {};

				array.forEach(zoneGetVillSoilHealth, lang.hitch(this, function(vals) {
					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectvillsoilcard.add(option, 0);
						}
					}
				}));
				document.getElementById("villsoil").value = "";

			});
		},
		villChangesoilhealth : function() {
			// debugger;
			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			// map.basemap = "";
			view.graphics.removeAll();
			// map.remove(graphicsLayer);
			// map.remove(graphicsTextLayer);
			divname = document.getElementById("divisionsoil").value;
			distname = document.getElementById("districtsoil").value;
			talname = document.getElementById("talukasoil").value;
			villname = document.getElementById("villsoil").value;
			dom.byId("divLoadingIndicator").style.display = 'block';
			selectsurveysoilcard = document.getElementById("surveyno");
			zF = [];
			while (selectsurveysoilcard.firstChild) {
				selectsurveysoilcard.removeChild(selectsurveysoilcard.firstChild);
			}
			for (var i = 0; i < zoneGetDistSoilHealth.length; i++) {
				if (zoneGetDistSoilHealth[i].name === distname) {
					distrcitCode = zoneGetDistSoilHealth[i].code;
				}
			}
			for (var i = 0; i < zoneGetTalSoilHealth.length; i++) {
				if (zoneGetTalSoilHealth[i].name === talname) {
					talukaCode = zoneGetTalSoilHealth[i].code;
				}
			}
			for (var i = 0; i < zoneGetVillSoilHealth.length; i++) {
				if (zoneGetVillSoilHealth[i].name === villname) {
					villageCode = zoneGetVillSoilHealth[i].code;
				}
			}

			//-----------------------------create query---------------
			if ((distname != "All" && talname != "All" && villname != "All")) {
				var queryTaskZm = new QueryTask(this.village);
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE  ='" + distrcitCode + "' and THNCODE  ='" + talukaCode + "' and VINCODE  ='" + villageCode + "'";
			}
			// console.log(queryZm.where);
			queryTaskZm.execute(queryZm).then(function(results) {
				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {

					bufgeometry = value.geometry;
					// console.log(bufgeometry);
					var symbol = {
						type : "simple-line",
						color : "black",
						width : "1px",
						style : "solid"
					};
					graphic = new Graphic(value.geometry, symbol);
					view.graphics.add(graphic, 0);
					// view.goTo(zF);
					geomextent = value.geometry.extent;

					zF.push(value);
					// view.goTo(zF);

				}));
			});

			var villageCode;
			for (var i = 0; i < zoneGetVillSoilHealth.length; i++) {
				if (zoneGetVillSoilHealth[i].name === villname) {
					villageCode = zoneGetVillSoilHealth[i].code;
				}
			}

			var zonesurvey = [];
			var testVals = {};

			document.getElementById("surveyno").value = " ";

			var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/baselayers/cadastral/MapServer?f=pjson";
			esriRequest(url, {
				responseType : "json"
			}).then(function(response) {
				// The requested data
				var geoJson = response.data;
				var layersArray = geoJson.layers;
				array.forEach(layersArray, lang.hitch(this, function(LayerAll) {
					// console.log(LayerAll.name);
					// console.log(LayerAll.id);
					if (LayerAll.name) {
						idDistLyr = LayerAll.id;
						lyerURL = "https://portal.mrsac.org.in/webadpgis8/rest/services/baselayers/cadastral/MapServer/" + idDistLyr;

						// console.log(lyerURL);

						if (distname === LayerAll.name) {
							queryTasksurveysoilcard = new QueryTask(lyerURL);
							//  graphicsLayerTrans.graphics.add(g);

							var query = new Query();
							query.outFields = ["PIN"];
							query.returnGeometry = false;
							query.outSpatialReference = {
								"wkid" : 102100
							};
							query.returnDistinctValues = true;
							query.where = "VINCODE = '" + villageCode + "'";
							queryTasksurveysoilcard.execute(query).then(function(featureset) {

								var result = featureset.features;

								array.forEach(result, lang.hitch(this, function(value) {
									pinno = value.attributes.PIN;
									if (pinno) {
										if (!testVals[pinno]) {
											testVals[pinno] = true;
											zonesurvey.push({
												name : pinno,

											});
										}
									}
								}));

								zonesurvey.sort(function(a, b) {
									if (a.name < b.name)
										return -1;
									if (a.name > b.name)
										return 1;
									return 0;
								});
								zonesurvey.reverse(function(a, b) {
									if (a.name < b.name)
										return -1;
									if (a.name > b.name)
										return 1;
									return 0;
								});
								testValsn = {};

								array.forEach(zonesurvey, lang.hitch(this, function(vals) {
									if (vals.name) {
										if (!testValsn[vals.name]) {
											testValsn[vals.name] = true;

											var option = document.createElement('option');
											option.text = option.value = vals.name;
											selectsurveysoilcard.add(option, 0);

											dom.byId("divLoadingIndicator").style.display = 'none';
										}
									}
								}));
								document.getElementById("surveyno").value = "";

							});
						}
					}
				}));
			});
		},
		submitbtnSoil : function() {
			dom.byId("divLoadingIndicator").style.display = 'block';
			dom.byId("infoDiv").style.display = 'block';
			map.removeAll(featureLayer);
			graphicsLayer.graphics.removeAll();
			graphicsLayer1.graphics.removeAll();
			view.graphics.removeAll();
			view.goTo(zF);
			view.graphics.add(graphic, 0);
			divname = document.getElementById("divisionsoil").value;
			distname = document.getElementById("districtsoil").value;
			talname = document.getElementById("talukasoil").value;
			villname = document.getElementById("villsoil").value;
			pinno = document.getElementById("surveyno").value;
			var pinArray = [];
			var value;
			var marathidata;
			if (distname === "" || talname === "" || villname === "") {
				swal("Selection of All Fields are compulsory");
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});
				map.basemap = "topo";
				dom.byId("divLoadingIndicator").style.display = 'none';
				featureLayer = new MapImageLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
					outFields : ["*"],
					mode : FeatureLayer.MODE_ONDEMAND,
				});
				map.add(featureLayer);
			} else {

				for (var i = 0; i < zoneGetVillSoilHealth.length; i++) {
					if (zoneGetVillSoilHealth[i].name === villname) {
						villageCode = zoneGetVillSoilHealth[i].code;
					}
				}

				//---------------------------------------------------------------------------------------//

				var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/baselayers/cadastral/MapServer?f=pjson";
				esriRequest(url, {
					responseType : "json"
				}).then(function(response) {

					var geoJson = response.data;
					var layersArray = geoJson.layers;
					array.forEach(layersArray, lang.hitch(this, function(LayerAll) {
						if (LayerAll.name == distname) {
							idDistLyr = LayerAll.id;
							lyerURL = "https://portal.mrsac.org.in/webadpgis8/rest/services/baselayers/cadastral/MapServer/" + idDistLyr;

							cadastrallayer = new FeatureLayer({
								url : lyerURL
							});
							queryTaskvillzoomsoilcard = new QueryTask(lyerURL);

							map.basemap = "";
							var querypin = new Query();
							querypin.outFields = ["*"];
							querypin.returnGeometry = true;
							querypin.outSpatialReference = {
								"wkid" : 102100
							};

							querypin.where = "VINCODE = '" + villageCode + "'";
							cadastrallayer.definitionExpression = "VINCODE = '" + villageCode + "'";
							map.add(cadastrallayer);
							console.log(villageCode);
							map.basemap = "";
							queryTaskvillzoomsoilcard.execute(querypin).then(function(featureset) {

								var result_features = featureset.features;

								if (result_features.length === 0) {
									swal("No Data Available");
								} else {

									array.forEach(result_features, lang.hitch(this, function(values) {

										//pinArray.push(value.attributes.PIN);

										pinArray.push({
											pin : values.attributes.PIN,
											geometry : values.geometry
										});

									}));
								}
							});

							//-------------------------------postmen service-----------------------------------------------------//
							url = "https://soilhealth.dac.gov.in/api/FarmerSurveyDetail";
							var xmlhttp1;
							var json;
							if (window.XMLHttpRequest) {
								xmlhttp1 = new XMLHttpRequest();
							} else {
								xmlhttp1 = new ActiveXObject("Microsoft.XMLHTTP");
							}
							xmlhttp1.onreadystatechange = function() {
								if (xmlhttp1.readyState == 4 && xmlhttp1.status == 200) {

									json = JSON.parse(xmlhttp1.responseText.trim());
									//console.log(json);

									if (json.length < 1) {
										//alert();
										swal("Soil Health Card details are not available");
										map.basemap = "";
									} else {
										data = json;
										marathidata = json;
										console.log(data);
										array.forEach(data, lang.hitch(this, function(valueData) {
											array.forEach(pinArray, lang.hitch(this, function(value1) {
												//console.log(value1);
												if (value1.pin === valueData.SurveyNo) {
													//console.log("yes");
													//console.log(value);
													bufgeometry1 = value1.geometry;
													var symbol1 = {
														type : "simple-fill",
														color : "#9BD3CB",
														style : "solid",
														outline : {
															color : "white",
															width : 1
														}
													};

													villGraphic1 = new Graphic(value1.geometry, symbol1);
													//view.graphics.add(villGraphic1);
													graphicsLayer1.graphics.add(villGraphic1);
													map.add(graphicsLayer1,0);
		
													bufgeometry = value1.geometry;
													zF.push(value);
													villGraphic = new Graphic(value1.geometry);
													//view.graphics.add(villGraphic, 0);

													geomextent = value1.geometry.extent;
													ringgeom = value1.geometry.rings;
													areageom = value1.geometry;
													view.goTo({
														target : zF
													});
													//----------------------------------------
												}
											}));
										}));

									}
								}
							}, xmlhttp1.open("POST", url, true);
							xmlhttp1.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
							xmlhttp1.send("VillageCode=" + villageCode + "&LanguageCode=13");

						}
					}));
				});
				dom.byId("divLoadingIndicator").style.display = 'none';
				dom.byId("viewDiv").style.cursor = 'pointer';
				//========================================
				view.on("click", function(event) {
					console.log(event);
					graphicsLayer.graphics.removeAll();
			//graphicsLayer1.graphics.removeAll();
					//view.graphics.removeAll();
					var x1 = event.screenPoint.x;
					var y1 = event.screenPoint.y;
					map.basemap = "topo";
					view.goTo({
						target : zF,
						// zoom : 16
					});

					//---------------------------------------------

					view.hitTest(event).then(function(response) {
						//view.graphics.remove(villGraphicSelected);
						// do something with the result graphic
						var graphic = response.results[1].graphic;
						console.log(response);
						pinno = graphic.attributes.PIN;
						var geom = graphic.geometry;

						var symbolsel = {
							type : "simple-fill",
							color : "#FF9AA2",
							style : "solid",
							outline : {
								color : "#FF9AA2",
								width : 4
							}
						};

						villGraphicSelected = new Graphic(geom, symbolsel);
						
						//view.graphics.add(villGraphicSelected);
						
					graphicsLayer.graphics.add(villGraphicSelected);
						map.add(graphicsLayer,1);
						//alert("addded")
						//view.graphics.add(villGraphicSelected);

					});

					setTimeout(function() {

						url = "https://soilhealth.dac.gov.in/api/SHCDetail";
						var xmlhttp;
						//*************Line *******************
						var json;
						if (window.XMLHttpRequest) {
							xmlhttp = new XMLHttpRequest();
						} else {
							xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
						}
						xmlhttp.onreadystatechange = function() {
							if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

								json = JSON.parse(xmlhttp.responseText.trim());

								abc = JSON.stringify(json);

								if (json.length < 1) {
									//swal("Soil Health Card details are not available for Survey No. " + pinno);

									url = "https://soilhealth.dac.gov.in/api/SHCDetail";
									var xmlhttp1;
									//*************Line *******************
									var json;
									if (window.XMLHttpRequest) {
										xmlhttp1 = new XMLHttpRequest();
									} else {
										xmlhttp1 = new ActiveXObject("Microsoft.XMLHTTP");
									}
									xmlhttp1.onreadystatechange = function() {
										if (xmlhttp1.readyState == 4 && xmlhttp1.status == 200) {

											json = JSON.parse(xmlhttp1.responseText.trim());

											abc = JSON.stringify(json);

											console.log(abc);

											if (json.length < 1) {
												swal("Soil Health Card details are not available for Survey No. " + pinno);
												map.basemap = "";
											} else {
												//console.log(json[0]);
												
												data = json[0];
												if (+pinno + "/1" === data.SurvayNo) {
													//alert(pinno + "====pinno and surveyno=======" + data.SurvayNo + "/");
													this._soilHealthData = json[0];
													testresult = data.TestResult;
													cropvariety = data.CropVariety;

												}

												var count = 0;

												console.log("---------marathi data-----------");
												console.log(marathidata);

												//console.log(zF);
												var modal = document.getElementById("myModal");
												modal.style.display = "block";

												var x1 = event.screenPoint.x;
												var y1 = event.screenPoint.y;

												var second = "",
												    third = "",
												    fourth = "";
												fifth = "";
												sixth = "";
												seventh = "";
												eighth = "";
												image = " ";
												ninth = " ";

												var width = 400;
												var height = 250;

												var options = {
													width : 400,
													height : 250
												};

												var options1 = {

													area : {
														x : x1 - 200,
														y : y1 - 130,
														width : width,
														height : height
													}
												};

												if (data.KhasraNo == "-") {
													data.KhasraNo = " ";
												}

												var first = " ";
												first = "<div  class='modal-content1'  style='width: 100%;left: 0;top: 0;margin-top: -7px;'><div ><div  style='appearance: button;-webkit-writing-mode: horizontal-tb !important;text-rendering: auto;color: -internal-light-dark(black, white);letter-spacing: normal;word-spacing: normal;text-transform: none;text-indent: 0px;text-shadow: none;  display: inline-block;text-align: center;align-items: flex-start; cursor: default;background-color: -internal-light-dark(rgb(239, 239, 239), rgb(59, 59, 59)); box-sizing: border-box; margin: 0em;font: 400 13.3333px Arial;padding: 1px 6px;border-width: 2px;border-style: outset;border-color: -internal-light-dark(rgb(118, 118, 118), rgb(133, 133, 133)); border-image: initial;-moz-border-radius: 3px;margin-right: 50px;margin-top: 0px;border: 1px solid #8b8b8b;background: #337ab7;width:50px;cursor:pointer;float:right;text-align: center;color: white;font-family: arial;' title='this.Print'  >Print</div> </div></div>";

												eighth = "<div  class='modal-content8'  style='width: 100%;left: 0;top: 0;margin-top: -7px;'><div ><div style='appearance: button;-webkit-writing-mode: horizontal-tb !important;text-rendering: auto;color: -internal-light-dark(black, white);letter-spacing: normal;word-spacing: normal;text-transform: none;text-indent: 0px;text-shadow: none;  display: inline-block;text-align: center;align-items: flex-start; cursor: default;background-color: -internal-light-dark(rgb(239, 239, 239), rgb(59, 59, 59)); box-sizing: border-box; margin: 0em;font: 400 13.3333px Arial;padding: 1px 6px;border-width: 2px;border-style: outset;border-color: -internal-light-dark(rgb(118, 118, 118), rgb(133, 133, 133)); border-image: initial;border: 1px solid #8b8b8b;background: #337ab7;cursor:pointer;float:right;text-align: center;color: white;font-family: arial;margin-top: -19px;border: 1px solid #8b8b8b;background: #337ab7;width:44px;cursor:pointer;float:right;text-align: center;color: white;font-family: arial;' > Close<span class='close'></span></button></div></div></div>";

												second = "<div  class='modal-content2' id= 'div1' style = '  width: 97%;margin-left : 12px;margin-top: 15px;'><table style=' width: 100%; border: 1px solid black; border-collapse: collapse;'><tr style = 'border: 1px solid;background-color: #f8e7a7;font-size: 14px;font-family: arial;font-weight: bold;height: 22px;'><td colspan='2' style = 'text-align: left;'>SOIL HEALTH CARD</td><td colspan='2' style = 'text-align: right;'> Card No : " + data.SHC_No + "</caption></td></tr><tr style= 'background-color: #89d5a7;'><th style = 'border-bottom: 1px solid black;font-family: arial; font-size: 14px;    border-right: 2px solid;'colspan='2'>Farmer's Details</th><th style = '  border-top: 1px solid black;border-bottom: 1px solid black;font-family: arial; font-size: 14px;'colspan='2'>Soil Sample Details</th></tr><tr style = 'border-bottom: 1px solid black;'><td style='  font-weight: bold;  width: 117px;padding-left: 10px;font-size: 13px;font-family: arial; border-right: 1px solid;'>Name</td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 2px solid black;'>" + data.Farmer_Name + "</td><td style='  font-weight: bold;  width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;'>Soil Sample No.</td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;'>" + data.Soil_Sample_No + "</td></tr><tr style = 'border-bottom: 1px solid black;'><td style=' width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;font-weight: bold;'>Mobile No.</td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 2px solid black;'>" + data.Mobile + "</td><td style='width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;font-weight: bold;'>Survey/Khasra No.</td><td style = ' padding-left: 10px;font-size: 13px;font-family: arial;'>" + data.SurvayNo + "" + data.KhasraNo + "</td></tr><tr style = 'border: 1px solid;'><td style=' width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;font-weight: bold;'> Village </td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 2px solid black;'>" + data.Village_Name + "</td><td style=' width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;font-weight: bold;'> Farm Size </td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;'>" + data.Farm_Size + "</td></tr><tr style = 'border-bottom: 1px solid black;'><td style=' width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;font-weight: bold;'>Tehsil</td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 2px solid black;'>" + data.BlockName + "</td><td style= ' width:129px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 1px solid black;font-weight: bold;width: 171px;'>GPS Location</td><td style = ' padding-left: 10px;font-size: 13px;font-family: arial;'>" + data.Latitude + "" + data.Longitute + "</td></tr><tr><td style=' width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;font-weight: bold;width: 171px;'>District</td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 2px solid black;'>" + data.District_Name + "</td><td style= ' width:129px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 1px solid black;font-weight: bold;width: 171px;'>Sample Collection Date</td><td style = ' padding-left: 10px;font-size: 13px;font-family: arial;'>" + data.Sample_Collection_Date + "</td></tr></table></div>";

												third = "<div class='modal-content3' id= 'div2' style = ' width: 97%;margin-left : 12px;margin-top: 15px;'><table style=' width: 100%; border: 1px solid black; border-collapse: collapse;'><tr style = 'border: 1px solid;background-color: #f8e7a7;font-size: 14px;font-family: arial;font-weight: bold;height: 22px;'><td colspan='3' style = 'text-align: left;'>SOIL TEST RESULT</td><td colspan='2' style = 'text-align: right;'>Laboratory Name: M/s. Nilawar Laboratories</td></tr><tr style= 'border-bottom:1px solid black; background-color: #89d5a7;'><td style = 'padding-left: 10px;font-size: 14px;font-weight: bold;font-family: arial;border-right: 1px solid black;width: 49px;'>Sr.No.</td><td style = 'padding-left: 10px;font-size: 14px;font-weight: bold;font-family: arial;border-right: 1px solid black;text-align: center;'>Parameter</td><td style = 'padding-left: 10px;font-size: 14px;font-weight: bold;font-family: arial;border-right: 1px solid black;text-align: center;'>Test Value</td><td style = 'padding-left: 10px;font-size: 14px;font-weight: bold;font-family: arial;border-right: 1px solid black;text-align: center;'>Unit</td><td style = 'padding-left: 10px;font-size: 14px;font-weight: bold;font-family: arial;border-right: 1px solid black;text-align: center;'>Rating</td></tr>";

												for (var i = 1; i <= testresult.length; i++) {

													for (var i = 1; i <= json.TestResult.length; i++) {
														//console.log(json.TestResult);
														console.log("---------if-----------");
														console.log(json.TestResult[i - 1].Test_Parameter_Name);

														third += "<tr style= 'border-bottom:1px solid black;'><td style= 'padding-left:21px;border-right:1px solid black;font-size:13px;font-family:arial;'>" + i + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:13px;font-family:arial;'>" + testresult[i - 1].Test_Parameter_Name + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:13px;font-family:arial; text-align: right;padding-right: 10px;'>" + testresult[i - 1].Test_Value + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:13px;font-family:arial;'>" + testresult[i - 1].Unit + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:13px;font-family:arial;'>" + json.TestResult[i - 1].Rating + "</td></tr>";
													}
												}
												third += "</table></div>";

												fourth = "<div class='modal-content4' id= 'div3' style = ' width: 97%;margin-left : 12px;margin-top: 15px;'><table style='height : 50%; width: 100%; border: 1px solid black; border-collapse: collapse;'><tr style= 'background-color: #f8e7a7;'><th style = 'border-bottom: 1px solid black;font-family: arial; font-size: 13px;'colspan='9'>NUTRIENT RECOMMENDATION</th></tr><tr style ='border-bottom:1px solid black; background-color: #89d5a7;'><td style = 'padding-left: 10px;font-size: 13px;font-weight: bold;font-family: arial;border-right: 1px solid black;width: 49px;'>Sr.No.</td><td style = 'font-size: 13px;font-family: arial;font-weight: bold;padding-left: 10px;border-right: 1px solid black;text-align: center;'>Crop/Variety</td><td style = 'padding-left: 10px;font-size: 13px;font-weight: bold;font-family: arial;border-right: 1px solid black;width: 49px;text-align: center;'>Reference Yield</td><td style = 'padding-left: 10px;font-size: 13px;font-weight: bold;font-family: arial;border-right: 1px solid black;width: 49px;text-align: center;'>Organic Fertilizer & Quantity</td><td style = 'padding-left: 10px;font-size: 13px;font-weight: bold;font-family: arial;border-right: 1px solid black;width: 49px;text-align: center;'>Bio Fertilizer & Quantity</td><td style = 'font-size: 13px;font-family: arial;font-weight: bold;padding-left: 10px;text-align: center;border-right: 1px solid black;'colspan='2'>Fertilizer Combination-1 (kg/ha)</td><td style = 'font-size: 13px;font-family: arial;font-weight: bold;padding-left: 10px;text-align: center;'colspan='2'>Fertilizer Combination-2 (kg/ha)</td></tr>";
												for (var i = 1; i <= cropvariety.length; i++) {
													for (var i = 1; i <= FertRecommandation.length; i++) {
														FertComOne = FertRecommandation[i - 1].FertComOne
														FertComTwo = FertRecommandation[i - 1].FertCombTwo
														// console.log(FertComOne);
														// console.log(FertComTwo);

														fourth += "<tr style= 'border-bottom:1px solid black;'><td style= 'padding-left:21px;border-right:1px solid black;font-size:11px;font-family:arial;'>" + i + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:11px;font-family:arial;'>" + cropvariety[i - 1].CropName + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:11px;font-family:arial;'>" + FertRecommandation[i - 1].RefrenceYield + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:11px;font-family:arial;'>" + FertRecommandation[i - 1].Organic_Fert_Quantity + "," + FertRecommandation[i - 1].Organic_Fert + " </td><td style= 'padding-left:10px;border-right:1px solid black;font-size:11px;font-family:arial;'>" + FertRecommandation[i - 1].Bio_Fert_Quantity + "," + FertRecommandation[i - 1].Bio_Fert + " </td>";

														fourth += "<td colspan='2' style = 'border-right : 1px solid black'><table style='width:100%;'>";

														for (var j = 1; j <= FertComOne.length; j++) {
															// console.log(FertComOne[j - 1].Furt_Comb_Name);
															fourth += " <tr style= 'border-bottom:1px solid black;'><td style= 'font-size:11px;font-family:arial; border-right : 1px solid black'>" + FertComOne[j - 1].Furt_Comb_Name + "</td><td style= 'font-size:11px;font-family:arial;'>" + FertComOne[j - 1].Furt_Comb_Quantity + "</td> </tr>";

														}

														fourth += "</table></td>";

														fourth += "<td colspan='2' style = 'border-right : 1px solid black'><table  style = 'width:100%;'>";
														//
														for (var j = 1; j <= FertComTwo.length; j++) {
															// console.log(FertComOne[j - 1].Furt_Comb_Name);
															fourth += "<tr style= 'border-bottom:1px solid black;'><td style= 'font-size:11px;font-family:arial; border-right : 1px solid black'>" + FertComTwo[j - 1].Furt_Comb_Name + "</td><td style= 'font-size:11px;font-family:arial;'>" + FertComTwo[j - 1].Furt_Comb_Quantity + "</td> </tr>";

														}

														fourth += "</table></td></tr>";

													}

												}

												fourth += "</table></div>";

												fifth = "<div class='modal-content5' style= 'margin-top: 30px;    margin-left: 350px; background-color: #f8e7a7;width: 13%;text-align: center;font-family: arial;font-size: 14px;    font-weight: bold;'>INDEX MAP</div>";

												seventh = "<div class='modal-content7' style= 'margin-top: 8px;      margin-bottom: -10px;   text-align: center;font-family: arial;font-size: 14px;    font-weight: bold;'><table style= 'width : 100%; margin-left: -20px; margin-bottom: -10px;'><tr><td style =' text-align: right;color: red;   ' >District : </td><td style= 'text-align : left'>" + data.District_Name + "</td><td style =' text-align: right;color: red;'>Taluka : </td><td style= 'text-align : left'>" + data.BlockName + "</td><td style =' text-align: right;color: red;'>Village : </td><td style= 'text-align : left'>" + data.Village_Name + "</td><td style =' text-align: right;color: red;'>Survey no. : </td><td >" + data.SurvayNo + "</td></tr></table></div>";

												ninth = "<div class='modal-content' style= 'margin-top: 80px;    margin-left: 15px; text-align: left; font-style: italic;font-size: 12px; '>Generated under MahaAgritech project, as per data received from Soil Health Portal, NIC Delhi</div>";

												view.takeScreenshot(options).then(function(screenshot) {

													var imageElement = document.getElementById("viewDiv");
													imageElement.src = screenshot.dataUrl;

													var pixelRatio = window.devicePixelRatio;
													view.takeScreenshot({
														width : view.width * pixelRatio,
														height : view.height * pixelRatio
													});
													image = new Image();
													image.src = imageElement.src;

													sixth += "<div class='modal-content6' id='image' style = '    border: 1px solid; margin-left: 188px;margin-top: 24px;margin-right: 166px;'>" + image.outerHTML + " </div>";
													var x6 = document.getElementsByClassName("modal-content6");
													x6[0].innerHTML = sixth;
												});

												view.takeScreenshot(options1).then(function(screenshot) {

													var imageElement = document.getElementById("viewDiv");
													imageElement.src = screenshot.dataUrl;

													var pixelRatio = window.devicePixelRatio;
													view.takeScreenshot({
														width : view.width * pixelRatio,
														height : view.height * pixelRatio
													});
													image = new Image();
													image.src = imageElement.src;

													sixth += "<div class='modal-content6' id='image' style = '     border: 1px solid;   margin-top: 24px;text-align-last: center;margin-left: 188px;margin-right: 166px;'>" + image.outerHTML + " </div>";
													var x6 = document.getElementsByClassName("modal-content6");
													x6[0].innerHTML = sixth;

												});

												var x1 = document.getElementsByClassName("modal-content1");
												var x8 = document.getElementsByClassName("modal-content8");
												var x2 = document.getElementsByClassName("modal-content2");
												var x3 = document.getElementsByClassName("modal-content3");
												var x4 = document.getElementsByClassName("modal-content4");
												var x5 = document.getElementsByClassName("modal-content5");
												var x7 = document.getElementsByClassName("modal-content7");

												var x9 = document.getElementsByClassName("modal-content9");

												x1[0].innerHTML = first;
												x8[0].innerHTML = eighth;
												x2[0].innerHTML = second;
												x3[0].innerHTML = third;
												x4[0].innerHTML = fourth;
												x5[0].innerHTML = fifth;
												x7[0].innerHTML = seventh;

												x9[0].innerHTML = ninth;

												var span = document.getElementsByClassName("close")[0];

												window.onclick = function(event) {
													// alert();
													modal.style.display = "none";
													map.basemap = "";
												};

											}

										}
									}, xmlhttp1.open("POST", url, true);
									xmlhttp1.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
									//xmlhttp1.send("StateCode=27&VillageCode=" + villageCode + "&CycleId=2&SurveyNo=" + pinno + "/1");
									xmlhttp1.send("StateCode=27&VillageCode=" + villageCode + "&Lang=13&CycleId=2&SurveyNo=" + pinno + "/1");

								} else {
									// console.log(json[0]);
									//console.log(json[0]);
									data = json[0];

									console.log("--------------data--------------------");
									console.log(data);

									if (pinno === data.SurvayNo) {
										//alert(pinno + "====pinno and surveyno=======" + data.SurvayNo + "/");
										this._soilHealthData = json[0];
										testresult = data.TestResult;
										cropvariety = data.CropVariety;
										 console.log(cropvariety);
										sampleID = data.Soil_Sample_No;
										//console.log(sampleID);
										var res = sampleID.substring(30, 17);
										console.log(res);
										url = "https://soilhealth.dac.gov.in/api/SHCParametersSamplesMH";
										var xmlhttp1;
										//*************Line *******************
										var json;
										if (window.XMLHttpRequest) {
											xmlhttp1 = new XMLHttpRequest();
										} else {
											xmlhttp1 = new ActiveXObject("Microsoft.XMLHTTP");
										}
										xmlhttp1.onreadystatechange = function() {
											if (xmlhttp1.readyState == 4 && xmlhttp1.status == 200) {

												json = JSON.parse(xmlhttp1.responseText.trim());
												FertRecommandation = json.FertRecommandation;

												console.log("---------else-----------");
												console.log(json);
												

												// if(cropvariety ===)

												var count = 0;

												//console.log(zF);

												var modal = document.getElementById("myModal");
												modal.style.display = "block";

												var x1 = event.screenPoint.x;
												var y1 = event.screenPoint.y;

												var second = "",
												    third = "",
												    fourth = "";
												fifth = "";
												sixth = "";
												seventh = "";
												eighth = "";
												image = " ";
												ninth = " ";

												var width = 400;
												var height = 250;

												var options = {
													width : 400,
													height : 250
												};

												var options1 = {

													area : {
														x : x1 - 200,
														y : y1 - 130,
														width : width,
														height : height
													}
												};

												if (data.KhasraNo == "-") {
													data.KhasraNo = " ";
												}

												var first = " ";
												first = "<div  class='modal-content1'  style='width: 100%;left: 0;top: 0;margin-top: -7px;'><div ><div  style='appearance: button;-webkit-writing-mode: horizontal-tb !important;text-rendering: auto;color: -internal-light-dark(black, white);letter-spacing: normal;word-spacing: normal;text-transform: none;text-indent: 0px;text-shadow: none;  display: inline-block;text-align: center;align-items: flex-start; cursor: default;background-color: -internal-light-dark(rgb(239, 239, 239), rgb(59, 59, 59)); box-sizing: border-box; margin: 0em;font: 400 13.3333px Arial;padding: 1px 6px;border-width: 2px;border-style: outset;border-color: -internal-light-dark(rgb(118, 118, 118), rgb(133, 133, 133)); border-image: initial;-moz-border-radius: 3px;margin-right: 50px;margin-top: 0px;border: 1px solid #8b8b8b;background: #337ab7;width:50px;cursor:pointer;float:right;text-align: center;color: white;font-family: arial;' title='this.Print'  >Print</div> </div></div>";

												eighth = "<div  class='modal-content8'  style='width: 100%;left: 0;top: 0;margin-top: -7px;'><div ><div style='appearance: button;-webkit-writing-mode: horizontal-tb !important;text-rendering: auto;color: -internal-light-dark(black, white);letter-spacing: normal;word-spacing: normal;text-transform: none;text-indent: 0px;text-shadow: none;  display: inline-block;text-align: center;align-items: flex-start; cursor: default;background-color: -internal-light-dark(rgb(239, 239, 239), rgb(59, 59, 59)); box-sizing: border-box; margin: 0em;font: 400 13.3333px Arial;padding: 1px 6px;border-width: 2px;border-style: outset;border-color: -internal-light-dark(rgb(118, 118, 118), rgb(133, 133, 133)); border-image: initial;border: 1px solid #8b8b8b;background: #337ab7;cursor:pointer;float:right;text-align: center;color: white;font-family: arial;margin-top: -19px;border: 1px solid #8b8b8b;background: #337ab7;width:44px;cursor:pointer;float:right;text-align: center;color: white;font-family: arial;' > Close<span class='close'></span></button></div></div></div>";

												second = "<div  class='modal-content2' id= 'div1' style = '  width: 97%;margin-left : 12px;margin-top: 15px;'><table style=' width: 100%; border: 1px solid black; border-collapse: collapse;'><tr style = 'border: 1px solid;background-color: #f8e7a7;font-size: 14px;font-family: arial;font-weight: bold;height: 22px;'><td colspan='2' style = 'text-align: left;'>SOIL HEALTH CARD</td><td colspan='2' style = 'text-align: right;'> Card No : " + data.SHC_No + "</caption></td></tr><tr style= 'background-color: #89d5a7;'><th style = 'border-bottom: 1px solid black;font-family: arial; font-size: 14px;    border-right: 2px solid;'colspan='2'>Farmer's Details</th><th style = '  border-top: 1px solid black;border-bottom: 1px solid black;font-family: arial; font-size: 14px;'colspan='2'>Soil Sample Details</th></tr><tr style = 'border-bottom: 1px solid black;'><td style='  font-weight: bold;  width: 117px;padding-left: 10px;font-size: 13px;font-family: arial; border-right: 1px solid;'>Name</td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 2px solid black;'>" + data.Farmer_Name + "</td><td style='  font-weight: bold;  width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;'>Soil Sample No.</td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;'>" + data.Soil_Sample_No + "</td></tr><tr style = 'border-bottom: 1px solid black;'><td style=' width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;font-weight: bold;'>Mobile No.</td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 2px solid black;'>" + data.Mobile + "</td><td style='width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;font-weight: bold;'>Survey/Khasra No.</td><td style = ' padding-left: 10px;font-size: 13px;font-family: arial;'>" + data.SurvayNo + "" + data.KhasraNo + "</td></tr><tr style = 'border: 1px solid;'><td style=' width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;font-weight: bold;'> Village </td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 2px solid black;'>" + data.Village_Name + "</td><td style=' width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;font-weight: bold;'> Farm Size </td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;'>" + data.Farm_Size + "</td></tr><tr style = 'border-bottom: 1px solid black;'><td style=' width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;font-weight: bold;'>Tehsil</td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 2px solid black;'>" + data.BlockName + "</td><td style= ' width:129px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 1px solid black;font-weight: bold;width: 171px;'>GPS Location</td><td style = ' padding-left: 10px;font-size: 13px;font-family: arial;'>" + data.Latitude + "" + data.Longitute + "</td></tr><tr><td style=' width: 117px;padding-left: 10px;font-size: 13px;border-right: 1px solid black;font-family: arial;font-weight: bold;width: 171px;'>District</td><td style= ' width: 215px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 2px solid black;'>" + data.District_Name + "</td><td style= ' width:129px;padding-left: 10px;font-size: 13px;font-family: arial;border-right: 1px solid black;font-weight: bold;width: 171px;'>Sample Collection Date</td><td style = ' padding-left: 10px;font-size: 13px;font-family: arial;'>" + data.Sample_Collection_Date + "</td></tr></table></div>";

												third = "<div class='modal-content3' id= 'div2' style = ' width: 97%;margin-left : 12px;margin-top: 15px;'><table style=' width: 100%; border: 1px solid black; border-collapse: collapse;'><tr style = 'border: 1px solid;background-color: #f8e7a7;font-size: 14px;font-family: arial;font-weight: bold;height: 22px;'><td colspan='3' style = 'text-align: left;'>SOIL TEST RESULT</td><td colspan='2' style = 'text-align: right;'>Laboratory Name: M/s. Nilawar Laboratories</td></tr><tr style= 'border-bottom:1px solid black; background-color: #89d5a7;'><td style = 'padding-left: 10px;font-size: 14px;font-weight: bold;font-family: arial;border-right: 1px solid black;width: 49px;'>Sr.No.</td><td style = 'padding-left: 10px;font-size: 14px;font-weight: bold;font-family: arial;border-right: 1px solid black;text-align: center;'>Parameter</td><td style = 'padding-left: 10px;font-size: 14px;font-weight: bold;font-family: arial;border-right: 1px solid black;text-align: center;'>Test Value</td><td style = 'padding-left: 10px;font-size: 14px;font-weight: bold;font-family: arial;border-right: 1px solid black;text-align: center;'>Unit</td><td style = 'padding-left: 10px;font-size: 14px;font-weight: bold;font-family: arial;border-right: 1px solid black;text-align: center;'>Rating</td></tr>";

												for (var i = 1; i <= testresult.length; i++) {

													for (var i = 1; i <= json.TestResult.length; i++) {
														//console.log(json.TestResult[i - 1].Test_Parameter_Name);
														//third += "<tr style= 'border-bottom:1px solid black;'><td style= 'padding-left:21px;border-right:1px solid black;font-size:13px;font-family:arial;'>" + i + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:13px;font-family:arial;'>" + testresult[i - 1].Test_Parameter_Name + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:13px;font-family:arial; text-align: right;padding-right: 10px;'>" + testresult[i - 1].Test_Value + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:13px;font-family:arial;'>" + testresult[i - 1].Unit + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:13px;font-family:arial;'>" + json.TestResult[i - 1].Rating + "</td></tr>";
														//console.log("Param :"+testresult[i - 1].Test_Parameter_Name);
														third += "<tr style= 'border-bottom:1px solid black;'><td style= 'padding-left:21px;border-right:1px solid black;font-size:13px;font-family:arial;'>" + i + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:13px;font-family:arial;'>" + json.TestResult[i - 1].Test_Parameter_Name.replace('Available','') + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:13px;font-family:arial; text-align: right;padding-right: 10px;'>" + testresult[i - 1].Test_Value + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:13px;font-family:arial;'>" + json.TestResult[i - 1].Unit + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:13px;font-family:arial;'>" + json.TestResult[i - 1].Rating + "</td></tr>";

													}
												}
												third += "</table></div>";

												fourth = "<div class='modal-content4' id= 'div3' style = ' width: 97%;margin-left : 12px;margin-top: 15px;'><table style='height : 50%; width: 100%; border: 1px solid black; border-collapse: collapse;'><tr style= 'background-color: #f8e7a7;'><th style = 'border-bottom: 1px solid black;font-family: arial; font-size: 13px;'colspan='9'>NUTRIENT RECOMMENDATION</th></tr><tr style ='border-bottom:1px solid black; background-color: #89d5a7;'><td style = 'padding-left: 10px;font-size: 13px;font-weight: bold;font-family: arial;border-right: 1px solid black;width: 49px;'>Sr.No.</td><td style = 'font-size: 13px;font-family: arial;font-weight: bold;padding-left: 10px;border-right: 1px solid black;text-align: center;'>Crop/Variety</td><td style = 'padding-left: 10px;font-size: 13px;font-weight: bold;font-family: arial;border-right: 1px solid black;width: 49px;text-align: center;'>Reference Yield</td><td style = 'padding-left: 10px;font-size: 13px;font-weight: bold;font-family: arial;border-right: 1px solid black;width: 49px;text-align: center;'>Organic Fertilizer & Quantity</td><td style = 'padding-left: 10px;font-size: 13px;font-weight: bold;font-family: arial;border-right: 1px solid black;width: 49px;text-align: center;'>Bio Fertilizer & Quantity</td><td style = 'font-size: 13px;font-family: arial;font-weight: bold;padding-left: 10px;text-align: center;border-right: 1px solid black;'colspan='2'>Fertilizer Combination-1 (kg/ha)</td><td style = 'font-size: 13px;font-family: arial;font-weight: bold;padding-left: 10px;text-align: center;'colspan='2'>Fertilizer Combination-2 (kg/ha)</td></tr>";
												for (var i = 1; i <= cropvariety.length; i++) {
													for (var i = 1; i <= FertRecommandation.length; i++) {
														FertComOne = FertRecommandation[i - 1].FertComOne
														FertComTwo = FertRecommandation[i - 1].FertCombTwo
														// console.log(FertComOne);
														// console.log(FertComTwo);

														fourth += "<tr style= 'border-bottom:1px solid black;'><td style= 'padding-left:21px;border-right:1px solid black;font-size:11px;font-family:arial;'>" + i + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:11px;font-family:arial;'>" + FertRecommandation[i - 1].Crop_Variety + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:11px;font-family:arial;'>" + FertRecommandation[i - 1].RefrenceYield + "</td><td style= 'padding-left:10px;border-right:1px solid black;font-size:11px;font-family:arial;'>" + FertRecommandation[i - 1].Organic_Fert_Quantity + "," + FertRecommandation[i - 1].Organic_Fert + " </td><td style= 'padding-left:10px;border-right:1px solid black;font-size:11px;font-family:arial;'>" + FertRecommandation[i - 1].Bio_Fert_Quantity + "," + FertRecommandation[i - 1].Bio_Fert + " </td>";

														fourth += "<td colspan='2' style = 'border-right : 1px solid black'><table style='width:100%;'>";

														for (var j = 1; j <= FertComOne.length; j++) {
															// console.log(FertComOne[j - 1].Furt_Comb_Name);
															fourth += " <tr style= 'border-bottom:1px solid black;'><td style= 'font-size:11px;font-family:arial; border-right : 1px solid black'>" + FertComOne[j - 1].Furt_Comb_Name + "</td><td style= 'font-size:11px;font-family:arial;'>" + FertComOne[j - 1].Furt_Comb_Quantity + "</td> </tr>";

														}

														fourth += "</table></td>";

														fourth += "<td colspan='2' style = 'border-right : 1px solid black'><table  style = 'width:100%;'>";
														//
														for (var j = 1; j <= FertComTwo.length; j++) {
															// console.log(FertComOne[j - 1].Furt_Comb_Name);
															fourth += "<tr style= 'border-bottom:1px solid black;'><td style= 'font-size:11px;font-family:arial; border-right : 1px solid black'>" + FertComTwo[j - 1].Furt_Comb_Name + "</td><td style= 'font-size:11px;font-family:arial;'>" + FertComTwo[j - 1].Furt_Comb_Quantity + "</td> </tr>";

														}

														fourth += "</table></td></tr>";

													}

												}

												fourth += "</table></div>";

												fifth = "<div class='modal-content5' style= 'margin-top: 30px;    margin-left: 350px; background-color: #f8e7a7;width: 13%;text-align: center;font-family: arial;font-size: 14px;    font-weight: bold;'>INDEX MAP</div>";

												seventh = "<div class='modal-content7' style= 'margin-top: 8px;      margin-bottom: -10px;   text-align: center;font-family: arial;font-size: 14px;    font-weight: bold;'><table style= 'width : 100%; margin-left: -20px; margin-bottom: -10px;'><tr><td style =' text-align: right;color: red;   ' >District : </td><td style= 'text-align : left'>" + data.District_Name + "</td><td style =' text-align: right;color: red;'>Taluka : </td><td style= 'text-align : left'>" + data.BlockName + "</td><td style =' text-align: right;color: red;'>Village : </td><td style= 'text-align : left'>" + data.Village_Name + "</td><td style =' text-align: right;color: red;'>Survey no. : </td><td >" + data.SurvayNo + "</td></tr></table></div>";

												ninth = "<div class='modal-content' style= 'margin-top: 80px;    margin-left: 15px; text-align: left; font-style: italic;font-size: 12px; '>Generated under MahaAgritech project, as per data received from Soil Health Portal, NIC Delhi</div>";

												view.takeScreenshot(options).then(function(screenshot) {

													var imageElement = document.getElementById("viewDiv");
													imageElement.src = screenshot.dataUrl;

													var pixelRatio = window.devicePixelRatio;
													view.takeScreenshot({
														width : view.width * pixelRatio,
														height : view.height * pixelRatio
													});
													image = new Image();
													image.src = imageElement.src;

													sixth += "<div class='modal-content6' id='image' style = '    border: 1px solid; margin-left: 188px;margin-top: 24px;margin-right: 166px;'>" + image.outerHTML + " </div>";
													var x6 = document.getElementsByClassName("modal-content6");
													x6[0].innerHTML = sixth;
												});

												view.takeScreenshot(options1).then(function(screenshot) {

													var imageElement = document.getElementById("viewDiv");
													imageElement.src = screenshot.dataUrl;

													var pixelRatio = window.devicePixelRatio;
													view.takeScreenshot({
														width : view.width * pixelRatio,
														height : view.height * pixelRatio
													});
													image = new Image();
													image.src = imageElement.src;

													sixth += "<div class='modal-content6' id='image' style = '     border: 1px solid;   margin-top: 24px;text-align-last: center;margin-left: 188px;margin-right: 166px;'>" + image.outerHTML + " </div>";
													var x6 = document.getElementsByClassName("modal-content6");
													x6[0].innerHTML = sixth;

												});

												var x1 = document.getElementsByClassName("modal-content1");
												var x8 = document.getElementsByClassName("modal-content8");
												var x2 = document.getElementsByClassName("modal-content2");
												var x3 = document.getElementsByClassName("modal-content3");
												var x4 = document.getElementsByClassName("modal-content4");
												var x5 = document.getElementsByClassName("modal-content5");
												var x7 = document.getElementsByClassName("modal-content7");

												var x9 = document.getElementsByClassName("modal-content9");

												x1[0].innerHTML = first;
												x8[0].innerHTML = eighth;
												x2[0].innerHTML = second;
												x3[0].innerHTML = third;
												x4[0].innerHTML = fourth;
												x5[0].innerHTML = fifth;
												x7[0].innerHTML = seventh;

												x9[0].innerHTML = ninth;

												var span = document.getElementsByClassName("close")[0];

												window.onclick = function(event) {
													// alert();
													modal.style.display = "none";
													map.basemap = "";
												};
												//----------------------------
											}
										}, xmlhttp1.open("POST", url, true);
										xmlhttp1.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
										xmlhttp1.send("StateCode=27&Lang=13&SampleId=" + res);

									}

								}

							}
						}, xmlhttp.open("POST", url, true);
						xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
						xmlhttp.send("StateCode=27&VillageCode=" + villageCode + "&Lang=13&CycleId=2&SurveyNo=" + pinno);
					}, 3000);

				});

				var el = document.getElementById('checkAllTopicCheckBoxes');
				if (el.clicked == true) {
					alert("button was clicked");
				}

				el.addEventListener('click', myFunction, {
					once : true
				});

				function myFunction() {
					//
					// alert("Hello! I am an alert box!!");
					this.removeEventListener("click", myFunction);
					printElement(document.getElementById("printThis"));
					function printElement(elem) {
						this.removeEventListener("click", printElement);
						var domClone = elem.cloneNode(true);

						var $printSection = document.getElementById("printSection");

						if (!$printSection) {

							var $printSection = document.createElement("div");
							$printSection.id = "printSection";
							document.body.appendChild($printSection);
						}

						$printSection.innerHTML = "";
						$printSection.appendChild(domClone);
						console.log($printSection.appendChild(domClone));
						window.document.close();
						// window.focus();
						window.print();
						window.focus = function() {
							window.close();
						};
						// window.clearInterval();
						// document.body.removeChild();

					}

				}

				//}

				//----------------end------------------------

			}

			//=================Print POPup for cadastral==============

			// document.getElementById("checkAllTopicCheckBoxes").addEventListener("click", function() {
			// alert();
			// // this.removeEventListener("click", myFunction);
			// printElement(document.getElementById("printThis"));
			// function printElement(elem) {
			// this.removeEventListener("click", printElement);
			// var domClone = elem.cloneNode(true);
			//
			// var $printSection = document.getElementById("printSection");
			//
			// if (!$printSection) {
			//
			// var $printSection = document.createElement("div");
			// $printSection.id = "printSection";
			// document.body.appendChild($printSection);
			// }
			//
			// $printSection.innerHTML = "";
			// $printSection.appendChild(domClone);
			// console.log($printSection.appendChild(domClone));
			// window.document.close();
			// // window.focus();
			// window.print();
			// window.focus = function() {
			// window.close();
			// };
			// // window.clearInterval();
			// // document.body.removeChild();
			//
			// }
			//
			// }, {
			// once : true
			// });

		},

		clear : function() {
			dom.byId("infoDiv").style.display = 'none';
			view.graphics.removeAll();
			graphicsLayer.graphics.removeAll();
			graphicsLayer1.graphics.removeAll();
			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.basemap = "topo";
			// map.remove(graphicsLayer);
			// map.remove(graphicsTextLayer);
			document.getElementById("divisionsoil").value = "";
			document.getElementById("districtsoil").value = "";
			document.getElementById("talukasoil").value = "";
			document.getElementById("villsoil").value = "";
			document.getElementById("surveyno").value = "";
			featureLayer = new MapImageLayer({
				url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
				outFields : ["*"],
				mode : FeatureLayer.MODE_ONDEMAND,
			});
			map.add(featureLayer);
			map.add(noncropmask);
		},
	});
});
