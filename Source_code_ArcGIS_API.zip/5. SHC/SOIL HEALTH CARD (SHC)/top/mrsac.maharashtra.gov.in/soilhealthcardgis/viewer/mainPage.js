/**
 * @author Shahana.sheikh
 */
define(["dojo/_base/declare", "dijit/registry", "dijit/_WidgetBase", "dijit/_OnDijitClickMixin", "dijit/_TemplatedMixin", "dojo/text!./templates/mainPage.html", "dojo/_base/window", "dijit/_WidgetsInTemplateMixin", "dijit/layout/AccordionContainer", "esri/Map", "esri/views/MapView", "esri/core/urlUtils", "esri/identity/OAuthInfo", "esri/identity/IdentityManager", "esri/widgets/Expand", "esri/layers/KMLLayer", "esri/geometry/geometryEngine", "esri/layers/Layer", "esri/widgets/LayerList", "esri/WebMap", "esri/widgets/Search", "esri/Basemap", "esri/widgets/Locate", "esri/widgets/Track", "esri/Graphic", "esri/widgets/Compass", "esri/layers/MapImageLayer", "esri/widgets/CoordinateConversion", "esri/tasks/Geoprocessor", "dijit/Tooltip", "esri/tasks/support/RelationshipQuery", "esri/tasks/Locator", "esri/widgets/Home", "esri/widgets/BasemapToggle", "esri/widgets/Swipe", "esri/widgets/ScaleBar", "esri/geometry/Extent", "dojo/_base/lang", "dojo/topic", "esri/config", "esri/identity/ServerInfo", "esri/identity/IdentityManager", "esri/layers/FeatureLayer", "esri/tasks/support/FeatureSet", "esri/layers/ImageryLayer", "esri/layers/MapImageLayer", "esri/tasks/ClosestFacilityTask", "esri/tasks/support/ClosestFacilityParameters", "dojo/_base/array", "dojo/on", "dojo/dom", "dojo/dom-construct", "dojo/dom-style", "dojo/dom-attr", "dojo/dom-class", "esri/symbols/PictureMarkerSymbol", "esri/renderers/SimpleRenderer", "esri/symbols/SimpleMarkerSymbol", "esri/Graphic", "esri/widgets/Popup", "esri/PopupTemplate", "dijit/TooltipDialog", "esri/core/lang", "esri/tasks/QueryTask", "esri/tasks/support/Query", "dojo/query", "dojo/store/Memory","esri/widgets/Print", "dijit/form/ComboBox", "dijit/form/DateTextBox", "dojo/data/ItemFileReadStore", "dijit/form/Select", "dijit/form/FilteringSelect", "esri/layers/GraphicsLayer", "esri/widgets/Sketch", "esri/geometry/Point", "esri/geometry/Circle", "esri/geometry/SpatialReference", "esri/symbols/SimpleLineSymbol", "esri/symbols/SimpleFillSymbol", "esri/Color", "esri/Graphic", "esri/request", "dojo/dom-style", "esri/widgets/Legend", "esri/tasks/FindTask", "dojo/request/xhr", 'dojo/data/ObjectStore', "dojo/request", "dojo/number", "dijit/layout/BorderContainer", "dijit/layout/TabContainer", "dijit/layout/ContentPane", "dijit/TitlePane", "dijit/form/Form", "esri/widgets/BasemapGallery", "dijit/form/TextBox", "dijit/Dialog", "dijit/form/CheckBox", "dijit/form/RadioButton", "dijit/Menu", "esri/layers/ImageryLayer", "esri/layers/support/RasterFunction", "esri/layers/support/DimensionalDefinition", "esri/layers/support/MosaicRule", "dijit/MenuItem", "dijit/layout/ContentPane", "dijit/Toolbar", "dijit/form/Button", "dojox/widget/TitleGroup", "dojo/_base/json", "dojo/domReady!"], function(declare, registry, _WidgetBase, _OnDijitClickMixin, _TemplatedMixin, template, win, _WidgetsInTemplateMixin, AccordionContainer, Map, MapView, urlUtils, OAuthInfo, esriId, Expand, KMLLayer, geometryEngine, Layer, LayerList, WebMap, Search, Basemap, Locate, Track, Graphic, Compass, MapImageLayer, CoordinateConversion, Geoprocessor, Tooltip, RelationshipQuery, Locator, Home, BasemapToggle, Swipe, ScaleBar, Extent, lang, topic, esriConfig, ServerInfo, esriId, FeatureLayer, FeatureSet, ImageryLayer, MapImageLayer, ClosestFacilityTask, ClosestFacilityParameters, array, on, dom, domConstruct, domStyle, domAttr, domClass, PictureMarkerSymbol, SimpleRenderer, SimpleMarkerSymbol, Graphic, Popup, PopupTemplate, TooltipDialog, esriLang, QueryTask, Query, query, Memory,Print, ComboBox, DateTextBox, ItemFileReadStore, FilteringSelect, Select, GraphicsLayer, Sketch, Point, Circle, SpatialReference, SimpleLineSymbol, SimpleFillSymbol, Color, Graphic, esriRequest, domStyle, Legend, FindTask, xhr, ObjectStore, request, number, BorderContainer, TabContainer, ContentPane, TitlePane, Form, BasemapGallery, TextBox, Dialog, CheckBox, RadioButton, Menu, ImageryLayer, RasterFunction, DimensionalDefinition, MosaicRule, MenuItem, json) {
	return declare("mrsac.viewer.mainPage", [_WidgetBase, _OnDijitClickMixin, _TemplatedMixin, _WidgetsInTemplateMixin], {

		constructor : function() {

		},
		templateString : template,
		postMixInProperties : function() {
			try {
				if (this.mapId === "") {
					this.mapId = "map";
				}

			} catch (err) {
				alert("err" + err);
				console.error(err);
			}
		},
		postCreate : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				console.error(err);
			}
		},
		startup : function() {

			if (this._started) {
				return;
			}
			try {
				// dom.byId("temp").style.display = 'none';
				this.securitycommangPortal();
				// this.manageSession();

				graphicsLayer = new GraphicsLayer();

				map = new Map({
					basemap : 'topo',
					layers : [graphicsLayer]
				});

				view = new MapView({
					container : "viewDiv",
					map : map,
					zoom : 7.5,
					center : [75.771240, 17.817910],
					constraints : {
						maxZoom : 16
					}

				});

				initExtent = new Extent({
					"xmin" : 70.9995834543952,
					"ymin" : 15.9995834301808,
					"xmax" : 83.0004167877285,
					"ymax" : 21.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});

				view.extent = initExtent;

				//---------------------------Swipe Tool-------------------------------------
				swipe = new Swipe({
					position : 90,
					view : view
				});
				view.ui.add(swipe, "top-left");

				//---------------Home button------------------
				var homeWidget = new Home({
					view : view
				});

				view.ui.add(homeWidget, "top-left");
				// //-----------------------------------Add Search widget----------------------------------
				// var search = new Search({
				// view : view,
				// });
				// view.ui.add(search, "top-right");
				// // -------------------------------Drawing-------------------------
				//
				var sketch = new Sketch({
					view : view,
					layer : graphicsLayer
				});
				var bgExpand = new Expand({
					view : view,
					content : sketch
				});

				view.ui.add(bgExpand, "top-left");
				//
				// //-----------------------------------Add Legend Dynamically on map---------------------------------
				var legend = new Legend({
					view : view
				});

				var bgExpand = new Expand({
					view : view,
					content : legend
				});

				view.ui.add(bgExpand, "bottom-left");

				//---------------------print------------------------
				const print = new Print({
					view : view,
					// specify your own print service
					printServiceUrl : "https://utility.arcgisonline.com/arcgis/rest/services/Utilities/PrintingTools/GPServer/Export%20Web%20Map%20Task"
				});
				
				const printex = new Expand({
					view : view,
					content : print,
					expanded : false
				});
				view.ui.add(printex, "top-left");

				//--------------------locate------------

				var locate = new Locate({
					view : view,
					useHeadingEnabled : false,
					goToOverride : function(view, options) {
						options.target.scale = 1500;
						return view.goTo(options.target);
					}
				});
				view.ui.add(locate, "top-left");

				//--------------track---------------

				var track = new Track({
					view : view,
					graphic : new Graphic({
						symbol : {
							type : "simple-marker",
							size : "12px",
							color : "green",
							outline : {
								color : "#efefef",
								width : "1.5px"
							}
						}
					}),
					useHeadingEnabled : false
				});
				view.ui.add(track, "top-left");
				var compass = new Compass({
					view : view
				});

				view.ui.add(compass, "top-left");
				//
				// //------------------------------------------------scale bar on map----------------------------------------
				var scaleBar = new ScaleBar({
					view : view,
					unit : "metric"
				});

				view.ui.add(scaleBar, {
					position : "bottom-left"
				});
				//

				//--------------------------------basemap gallary-----------------------

				var basemapGallery = new BasemapGallery({
					view : view
				});
				// Add widget to the top right corner of the view

				const bg = new Expand({
					view : view,
					content : basemapGallery,
					expanded : false
				});
				view.ui.add(bg, "top-left");

				//--------------------------------basemap toggling-----------------------

				//2D
				var basemapToggle = new BasemapToggle({
					view : view,
					nextBasemap : "hybrid"
				});
				view.ui.add(basemapToggle, "bottom-left");

				//----------------------- create a layerlist and expand widget and add to the view
				const layerList = new LayerList({
					view : view
				});
				const llExpand = new Expand({
					view : view,
					content : layerList,
					expanded : false
				});
				view.ui.add(llExpand, "top-left");
				// //----------------------------------------------------Add div element to show coordates---------------------------//
				//
				var coordsWidget = document.createElement("div");
				coordsWidget.id = "coordsWidget";
				coordsWidget.className = "esri-widget esri-component";
				coordsWidget.style.padding = "7px 15px 5px";
				view.ui.add(coordsWidget, "bottom-left");

				//*** Update lat, lon, zoom and scale ***//
				function showCoordinates(pt) {
					// Lat/Lon " + pt.latitude.toFixed(3) + " " + pt.longitude.toFixed(3) + " |
					var coords = "Lat/Lon " + pt.latitude.toFixed(3) + " " + pt.longitude.toFixed(3) + " | Scale 1:" + Math.round(view.scale * 1) / 1 + " | Zoom " + view.zoom;
					coordsWidget.innerHTML = coords;
				}

				//*** Add event and show center coordinates after the view is finished moving e.g. zoom, pan ***//
				view.watch(["stationary"], function() {
					showCoordinates(view.center);
				});

				//*** Add event to show mouse coordinates on click and move ***//
				view.on(["pointer-down", "pointer-move"], function(evt) {
					showCoordinates(view.toMap({
						x : evt.x,
						y : evt.y
					}));
				});

			} catch (err) {
				console.error("SearchWidget::startup", err);
			}

		},
		securitycommangPortal : function() {

			esriConfig.request.interceptors.push("https://portal.mrsac.org.in/webadpgis8/tokens/");
			esriConfig.request.trustedServers.push("https://portal.mrsac.org.in/webadpgis8/tokens/");
			esriConfig.request.proxyUrl = "/proxy/";
			var portalURL = "https://portal.mrsac.org.in";
			var serverInfo = new ServerInfo();
			serverInfo.adminTokenServiceUrl = portalURL + "/webadpgis8/tokens/generateToken";
			serverInfo.currentVersion = 10.3;
			serverInfo.hasServer = true;
			serverInfo.server = portalURL;
			serverInfo.shortLivedTokenValidity = 60;
			serverInfo.tokenServiceUrl = portalURL + "/webadpgis8/tokens/";
			esriId.registerServers([serverInfo]);
			var def = esriId.generateToken(serverInfo, {
				"username" : "mrsac_viewer",
				"password" : "@gsvieWer#2018",
			});
			def.then(function(tokenInfo) {
				var creationTime = (new Date).getTime();
				var expirationTime = creationTime + (serverInfo.shortLivedTokenValidity * 60000);
				var idObject = {};
				idObject.serverInfos = [serverInfo];
				var credentials = {};
				credentials.userId = "mrsac_viewer";
				credentials.server = portalURL + "/webadpgis8";
				credentials.token = tokenInfo.token;
				credentials.expires = expirationTime;
				credentials.ssl = false;
				credentials.scope = "server";
				credentials.validity = 720;
				credentials.creationTime = creationTime;
				idObject.credentials = [credentials];
				esriId.initialize(idObject);
			}, function(error) {
				console.error("error message" + error);
			});
		},

		manageSession : function() {
			// alert();
			debugger;

			var attempt = 3;
			// Variable to count number of attempts.
			// Below function Executes on click of login button.
			submit.addEventListener("click", (e) => {
				var username = document.getElementById("username").value;
				var password = document.getElementById("password").value;
				if (username == "mrsac" && password == "agritech@456"  || username == "guest" && password == "guest@123" || username == "mahait" && password == "agritech@mahait") {
					// alert("Login successfully");
					dom.byId("mySignModal").style.display = 'none';
					dom.byId("temp").style.display = 'block';
					// Redirecting to other page.
					return false;
				} else {
					attempt--;
					// Decrementing by one.
					alert("Wrong Password Now You have left " + attempt + " attempt;");
					// Disabling fields after 3 attempts.
					if (attempt == 0) {
						document.getElementById("username").disabled = true;
						document.getElementById("password").disabled = true;
						document.getElementById("submit").disabled = true;
						return false;
					}
				}
			})

		},
	});
});

