/**
 * @author shahana.sheikh
 */
define(["dojo/_base/declare", "dijit/registry", "dijit/_WidgetBase", "dijit/_TemplatedMixin", "dojo/text!./templates/horticulture.html", "dojo/_base/window", "dijit/_WidgetsInTemplateMixin", "dijit/layout/AccordionContainer", "esri/Map", "esri/request", "esri/views/MapView", "dojo/_base/lang", "dojo/dom-attr", "dojo/aspect", "dojo/store/Memory", "dijit/form/ComboBox", "dijit/TooltipDialog", "dijit/form/Select", "dijit/form/FilteringSelect", "dijit/TitlePane", "esri/widgets/Expand", "esri/layers/KMLLayer", "esri/geometry/geometryEngine", "esri/layers/Layer", "esri/WebMap", "esri/widgets/Search", "esri/Basemap", "esri/widgets/Locate", "esri/widgets/Track", "esri/Graphic", "esri/widgets/Compass", "esri/layers/MapImageLayer", "esri/widgets/CoordinateConversion", "esri/tasks/Geoprocessor", "dijit/Tooltip", "esri/tasks/support/RelationshipQuery", "esri/tasks/Locator", "esri/widgets/Home", "esri/widgets/BasemapToggle", "esri/widgets/Swipe", "esri/widgets/ScaleBar", "esri/geometry/Extent", "dojo/_base/lang", "dojo/topic", "esri/config", "esri/identity/ServerInfo", "esri/identity/IdentityManager", "esri/layers/FeatureLayer", "esri/tasks/support/FeatureSet", "esri/layers/ImageryLayer", "esri/layers/MapImageLayer", "esri/tasks/ClosestFacilityTask", "esri/tasks/support/ClosestFacilityParameters", "dojo/_base/array", "dojo/on", "dojo/dom", "dojo/dom-construct", "dojo/dom-style", "dojo/dom-attr", "dojo/dom-class", "esri/symbols/PictureMarkerSymbol", "esri/renderers/SimpleRenderer", "esri/symbols/SimpleMarkerSymbol", "esri/Graphic", "esri/widgets/Popup", "esri/PopupTemplate", "dijit/TooltipDialog", "esri/core/lang", "esri/tasks/QueryTask", "esri/tasks/support/Query", "dojo/query", "dojo/store/Memory", "dijit/form/ComboBox", "dijit/form/DateTextBox", "dojo/data/ItemFileReadStore", "dijit/form/Select", "dijit/form/FilteringSelect", "esri/layers/GraphicsLayer", "esri/widgets/Sketch", "esri/geometry/Point", "esri/geometry/Circle", "esri/geometry/SpatialReference", "esri/symbols/SimpleLineSymbol", "esri/symbols/SimpleFillSymbol", "esri/Color", "esri/Graphic", "esri/request", "dojo/dom-style", "esri/widgets/Legend", "esri/tasks/FindTask", "dojo/request/xhr", 'dojo/data/ObjectStore', "dojo/request", "dojo/number", "dijit/layout/BorderContainer", "dijit/layout/TabContainer", "dijit/layout/ContentPane", "dijit/TitlePane", "dijit/form/Form", "esri/widgets/BasemapGallery", "dijit/form/TextBox", "dijit/Dialog", "dijit/form/CheckBox", "dijit/form/RadioButton", "dijit/Menu", "esri/layers/ImageryLayer", "esri/layers/support/RasterFunction", "esri/layers/support/DimensionalDefinition", "esri/layers/support/MosaicRule", "dijit/MenuItem", "dijit/layout/ContentPane", "dijit/Toolbar", "dijit/form/Button", "dojox/widget/TitleGroup", "esri/core/urlUtils", "dojo/_base/json", "dojo/domReady!"], function(declare, registry, _WidgetBase, _TemplatedMixin, template, win, _WidgetsInTemplateMixin, AccordionContainer, Map, esriRequest, MapView, lang, domAttr, aspect, Memory, ComboBox, TooltipDialog, Select, FilteringSelect, TitlePane, Expand, KMLLayer, geometryEngine, Layer, WebMap, Search, Basemap, Locate, Track, Graphic, Compass, MapImageLayer, CoordinateConversion, Geoprocessor, Tooltip, RelationshipQuery, Locator, Home, BasemapToggle, Swipe, ScaleBar, Extent, lang, topic, esriConfig, ServerInfo, esriId, FeatureLayer, FeatureSet, ImageryLayer, MapImageLayer, ClosestFacilityTask, ClosestFacilityParameters, array, on, dom, domConstruct, domStyle, domAttr, domClass, PictureMarkerSymbol, SimpleRenderer, SimpleMarkerSymbol, Graphic, Popup, PopupTemplate, TooltipDialog, esriLang, QueryTask, Query, query, Memory, ComboBox, DateTextBox, ItemFileReadStore, FilteringSelect, Select, GraphicsLayer, Sketch, Point, Circle, SpatialReference, SimpleLineSymbol, SimpleFillSymbol, Color, Graphic, esriRequest, domStyle, Legend, FindTask, xhr, ObjectStore, request, number, BorderContainer, TabContainer, ContentPane, TitlePane, Form, BasemapGallery, TextBox, Dialog, CheckBox, RadioButton, Menu, ImageryLayer, RasterFunction, DimensionalDefinition, MosaicRule, urlUtils, MenuItem, json) {
	return declare("mrsac.viewer.horticulture", [_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {

		constructor : function() {
			valueOther = [];
			valuesRabi = [];
			getDist = [];
			circleCodeArray = [];
			zoneGetdivision = [];
			zoneGetdivchange = [];
			zoneGetdistchange = [];
			zoneGettalchange = [];
			zoneGetcirchange = [];
			zoneGetvilchange = [];
			graphTableArray = [];

			//-----------Kharif total sown---------
			zFKhdivchange = [];
			zFKhdistchange = [];
			agriArrayPrint = [];
			zF = [];
			tableIterationFlag = true;
			dataTableObj = null;
			tableIterationFlag2 = true;
			dataTableObj2 = null;

			totcirareacount = 0;
			totcountarearound = 0;
			graphTitle = "";
			finalData = [];

		},
		currentTab : "horticulture",
		agriarea : null,
		ringgeom : null,
		queryZm : null,
		contextMenu : null,
		queryUsedFurther : null,
		remapRFnoncrp : null,
		resultAgriLandUseArea : null,
		templateString : template,
		postMixInProperties : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				alert("err" + err);
				console.error(err);
			}
		},
		postCreate : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				console.error(err);
			}
		},
		startup : function() {
			if (this._started) {

				return;
			}
			try {

				//--------services  used-------------
				this.state = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/0";
				this.division = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/1";
				this.district = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/2";
				this.taluka = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/3";
				this.village = "https://portal.mrsac.org.in/webadpgis8/rest/services/admin2011/admin_village_16/MapServer/0";
				this.circle = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/4";
				this.sdtc = "https://portal.mrsac.org.in/webadpgis8/rest/services/admin2011/combined_admin_master/MapServer/0";

				this.orchardstats = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/acerage_statistics/MapServer/10";

				featureLayer = new MapImageLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
					outFields : ["*"],
					mode : FeatureLayer.MODE_ONDEMAND,
				});
				map.add(featureLayer);

				noncropmask = new ImageryLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/noncropmask_2019/ImageServer",
					opacity : 0.3,
					id : "noncropmaskId"

				});
				map.add(noncropmask);

				this.getDivision();

			} catch (err) {
				console.error("SearchWidget::startup", err);

			}

		},

		getDivision : function() {
			zoneGetdivision = [];
			var testVals = {};
			document.getElementById("villageh").value = " ";
			document.getElementById("districth").value = " ";
			document.getElementById("talukah").value = " ";
			//document.getElementById("circleh").value = " ";

			selectDivision = document.getElementById("divisionh");

			queryTaskYearSown = new QueryTask(this.division);
			var queryYear = new Query();
			queryYear.outFields = ["ADVENAME ", "ADVNCODE"];
			queryYear.returnGeometry = false;
			queryYear.returnDistinctValues = true;
			queryYear.where = "1=1";

			queryTaskYearSown.execute(queryYear).then(function(featureset) {

				var result = featureset.features;

				array.forEach(result, lang.hitch(this, function(value) {

					divname = value.attributes.ADVENAME;
					divcode = value.attributes.ADVNCODE;

					if (divname) {
						if (!testVals[divname]) {
							testVals[divname] = true;
							zoneGetdivision.push({
								name : divname,
								code : divcode
							});
						}
					}
				}));

				zoneGetdivision.sort(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});

				zoneGetdivision.reverse(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				// zoneGetdivision.push({
				// name : "All",
				// code : "All"
				// });

				testValsn = {};

				array.forEach(zoneGetdivision, lang.hitch(this, function(vals) {
					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;
							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectDivision.add(option, 0);
						}
					}
				}));
				document.getElementById("divisionh").value = "";
				dom.byId("divLoadingIndicator").style.display = 'none';

			});
		},

		getdivchange : function() {
			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.basemap = "topo";
			map.add(featureLayer);
			view.graphics.removeAll();

			document.getElementById("villageh").value = " ";
			document.getElementById("talukah").value = " ";
			document.getElementById("circleh").value = " ";
			document.getElementById("districth").value = " ";
			divi = document.getElementById("divisionh").value;
			for (var i = 0; i < zoneGetdivision.length; i++) {
				if (zoneGetdivision[i].name === divi) {
					divisionCode = zoneGetdivision[i].code;
				}
			}

			zoneGetdivchange = [];
			view.graphics.removeAll();
			var values = [];
			var testVals = {};

			if (divi == "All") {
				var queryTaskZm = new QueryTask({
					url : this.state
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "STENAME = 'Maharashtra'";

				stateLayer = new FeatureLayer({
					url : this.state,
					id : "stateLayerDisplay"
				});
				stateLayer.definitionExpression = queryZm.where;
				map.add(stateLayer);

			} else if (divi != "All") {
				var queryTaskZm = new QueryTask({
					url : this.division
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "ADVENAME  = '" + divi + "'";
				divisionLayer = new FeatureLayer({
					url : this.division,
					id : "diviLayerDisplay"
				});
				divisionLayer.definitionExpression = queryZm.where;
				map.add(divisionLayer);

			}

			queryTaskZm.execute(queryZm).then(function(results) {
				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {
					bufgeometry = value.geometry;
					zF.push(value);
					var symbol = {
						type : "simple-line",
						color : "black",
						width : "2px",
						style : "solid"
					};
					var districtGraphic = new Graphic(value.geometry, symbol);
					view.graphics.add(districtGraphic, 0);
					ringgeom = value.geometry.rings;
				}));

			});

			selectDist = document.getElementById("districth");
			while (selectDist.firstChild) {
				selectDist.removeChild(selectDist.firstChild);
			}
			queryTaskdist = new QueryTask(this.district);

			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["DTENAME", "DTNCODE"];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.returnDistinctValues = true;

			queryUsedFurther.where = "ADVNCODE = '" + divisionCode + "' and DTNCODE <> '' ";

			queryTaskdist.execute(queryUsedFurther).then(function(featureset) {

				var result = featureset.features;

				array.forEach(result, lang.hitch(this, function(value) {
					dis_name = value.attributes.DTENAME;
					dist_code = value.attributes.DTNCODE;
					if (dis_name) {
						if (!testVals[dis_name]) {
							testVals[dis_name] = true;
							zoneGetdivchange.push({
								name : dis_name,
								code : dist_code,
							});
						};
					}
				}));

				zoneGetdivchange.sort(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});

				zoneGetdivchange.reverse(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});

				testValsn = {};

				array.forEach(zoneGetdivchange, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectDist.add(option, 0);
						}
					}
				}));
				document.getElementById("districth").value = "";
			});
		},

		getdistchange : function() {
			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.basemap = "topo";
			map.add(featureLayer);
			view.graphics.removeAll();

			distname = document.getElementById("districth").value;
			talname = document.getElementById("talukah").value;
			document.getElementById("talukah").value = " ";
			document.getElementById("villageh").value = " ";
			document.getElementById("circleh").value = " ";

			//===========Division Name in Sentence Case================
			function upperCaseFirstLetter(string) {
				return string.charAt(0).toUpperCase() + string.slice(1);
			}

			function lowerCaseAllWordsExceptFirstLetters(string) {
				return string.replace(/\w\S*/g, function(word) {
					return word.charAt(0) + word.slice(1).toLowerCase();
				});
			}

			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					distrcitCode = zoneGetdivchange[i].code;
				}
			}
			view.graphics.removeAll();

			zoneGetdistchange = [];
			var testVals = {};
			zF = [];
			var district_LayerUrlZm = this.district;
			if ((distname == "All" && talname == "") || (distname == "" && talname == "")) {
				var queryTaskZm = new QueryTask({
					url : this.state
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "STENAME = 'Maharashtra'";

				stateLayer = new FeatureLayer({
					url : this.state,
					id : "stateLayerDisplay"
				});
				stateLayer.definitionExpression = queryZm.where;
				map.add(stateLayer);

			} else if ((distname != "All") || (distname != "All")) {
				var queryTaskZm = new QueryTask({
					url : district_LayerUrlZm
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "'";

				//----------------------Get Crop Layers All-----------
				distLayer = new FeatureLayer({
					url : this.district,
					id : "distLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);

			}

			queryTaskZm.execute(queryZm).then(function(results) {

				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {

					bufgeometry = value.geometry;
					zF.push(value);
					var symbol = {
						type : "simple-line", // autocasts as new SimpleLineSymbol()
						color : "black",
						width : "2px",
						style : "solid"
					};
					var districtGraphic = new Graphic(value.geometry, symbol);
					view.graphics.add(districtGraphic, 0);
					ringgeom = value.geometry.rings;
					areageom = value.geometry;
				}));

			});

			selecttal = document.getElementById("talukah");
			while (selecttal.firstChild) {
				selecttal.removeChild(selecttal.firstChild);
			}
			queryTasktal = new QueryTask(this.taluka);

			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["THENAME", "THNCODE"];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.outSpatialReference = {
				"wkid" : 102100
			};
			queryUsedFurther.returnDistinctValues = true;

			queryUsedFurther.where = "DTNCODE = '" + distrcitCode + "' ";
			// console.log(queryUsedFurther.where);
			queryTasktal.execute(queryUsedFurther).then(function(featureset) {

				var result = featureset.features;
				if (distname != "All") {
					array.forEach(result, lang.hitch(this, function(value) {

						tal_name = value.attributes.THENAME;
						tal_code = value.attributes.THNCODE;
						if (tal_name) {
							if (!testVals[tal_name]) {
								testVals[tal_name] = true;
								zoneGetdistchange.push({
									name : tal_name,
									code : tal_code
								});
							}
						}
					}));

					zoneGetdistchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.push({
						name : "All",
						code : "All"
					});
				} else if (distname == "All") {
					zoneGetdistchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.push({
						name : "All",
						code : "All"
					});
				}

				testValsn = {};

				array.forEach(zoneGetdistchange, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selecttal.add(option, 0);
						}
					}
				}));
				document.getElementById("talukah").value = "";

			});
		},

		getcircle : function() {

			var zone = [];
			var values = [];
			var testVals = {};
			zoneGetcirchange = [];
			zF = [];

			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.basemap = "topo";
			map.add(featureLayer);
			view.graphics.removeAll();
			document.getElementById("villageh").value = " ";
			talname = document.getElementById("talukah").value;
			distname = document.getElementById("districth").value;
			selectcircle = document.getElementById("circleh");
			while (selectcircle.firstChild) {
				selectcircle.removeChild(selectcircle.firstChild);
			}
			view.graphics.removeAll();

			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					districtCode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talukaCode = zoneGetdistchange[i].code;
				}
			}
			if ((distname != "All") && (talname == "All")) {
				var queryTaskZm = new QueryTask({
					url : this.district
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "'";

				//----------------------Get Crop Layers All-----------
				distLayer = new FeatureLayer({
					url : this.district,
					id : "distLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);

			} else if ((distname != "All") && (talname != "All")) {

				var taluka_LayerUrlZm = this.taluka;
				var queryTaskZm = new QueryTask({
					url : taluka_LayerUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";

				talLayer = new FeatureLayer({
					url : this.taluka,
					id : "talLayerDisplay"
				});
				talLayer.definitionExpression = queryZm.where;
				map.add(talLayer);

			}
			queryTaskZm.execute(queryZm).then(function(results) {
				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {
					bufgeometry = value.geometry;
					zF.push(value);
					var symbol = {
						type : "simple-line",
						color : "black",
						width : "2px",
						style : "solid"
					};
					slected_circle = zF[0].attributes.OBJECTID;
					var graphic = new Graphic(value.geometry, symbol);
					view.graphics.add(graphic, 0);
					ringgeom = value.geometry.rings;
					areageom = value.geometry;

				}));
			});

			queryTaskcir = new QueryTask(this.circle);
			//-------For Query--------
			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["CIRNAME ,CIRCODE "];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.outSpatialReference = {
				"wkid" : 102100
			};
			queryUsedFurther.returnDistinctValues = true;

			if (talname === "All") {
				queryUsedFurther.where = "DTNCODE = '" + distrcitCode + "' and  THNCODE <>'' and  CIRCODE <>'' ";
			} else if (talname !== "All") {
				queryUsedFurther.where = "DTNCODE = '" + distrcitCode + "' and  THNCODE ='" + talukaCode + "'  and  CIRCODE <>'' ";
			}
			// console.log(queryUsedFurther.where);
			queryTaskcir.execute(queryUsedFurther).then(function(featureset) {
				// alert();
				var result = featureset.features;
				if (talname != "All") {
					array.forEach(result, lang.hitch(this, function(value) {
						cirname = value.attributes.CIRNAME;
						circode = value.attributes.CIRCODE;
						if (cirname) {
							if (!testVals[cirname]) {
								testVals[cirname] = true;
								zoneGetcirchange.push({
									name : cirname,
									code : circode

								});
							}
						}
					}));
					zoneGetcirchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetcirchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetcirchange.push({
						name : "All",
						code : "All"
					});
				} else if (talname == "All") {

					zoneGetcirchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetcirchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetcirchange.push({
						name : "All",
						code : "All"
					});
				}

				// console.log(zoneGetvilchange);
				testValsn = {};
				array.forEach(zoneGetcirchange, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;
							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectcircle.add(option, 0);
						}
					}
				}));
				document.getElementById("circleh").value = "";
			});
		},

		getvillage : function() {

			var zone = [];
			var values = [];
			var testVals = {};
			zoneGetvilchange = [];
			zF = [];

			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.basemap = "topo";
			map.add(featureLayer);
			view.graphics.removeAll();
			cirname = document.getElementById("circleh").value;
			talname = document.getElementById("talukah").value;
			distname = document.getElementById("districth").value;
			selectvillage = document.getElementById("villageh");
			while (selectvillage.firstChild) {
				selectvillage.removeChild(selectvillage.firstChild);
			}
			view.graphics.removeAll();

			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					districtCode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talukaCode = zoneGetdistchange[i].code;
				}
			}

			for (var i = 0; i < zoneGetcirchange.length; i++) {
				if (zoneGetcirchange[i].name === cirname) {
					circleCode = zoneGetcirchange[i].code;
				}
			}

			if ((distname != "All") && (talname == "All") && (cirname == "All")) {
				var queryTaskZm = new QueryTask({
					url : this.district
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "'";

				//----------------------Get Crop Layers All-----------
				distLayer = new FeatureLayer({
					url : this.district,
					id : "distLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);

			} else if ((distname != "All") && (talname != "All") && (cirname == "All")) {
				// alert();
				var circleUrlZm = this.taluka;
				var queryTaskZm = new QueryTask({
					url : circleUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";
				circleLayer = new FeatureLayer({
					url : circleUrlZm,
					id : "cirLayerDisplay"
				});
				circleLayer.definitionExpression = queryZm.where;
				map.add(circleLayer);
			} else if ((distname != "All") && (talname != "All") && (cirname !== "All")) {
				// alert();
				var circleUrlZm = "https://portal.mrsac.org.in/webadpgis8/rest/services/baselayers/circle_boundary/MapServer/0";
				var queryTaskZm = new QueryTask({
					url : circleUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "THNCODE = '" + talukaCode + "' and CIRNCODE  = '" + circleCode + "'";
				circleLayer = new FeatureLayer({
					url : circleUrlZm,
					id : "cirLayerDisplay"
				});
				circleLayer.definitionExpression = queryZm.where;
				map.add(circleLayer);
			}
			queryTaskZm.execute(queryZm).then(function(results) {
				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {
					bufgeometry = value.geometry;
					zF.push(value);
					var symbol = {
						type : "simple-line",
						color : "black",
						width : "2px",
						style : "solid"
					};
					slected_circle = zF[0].attributes.OBJECTID;
					var graphic = new Graphic(value.geometry, symbol);
					view.graphics.add(graphic, 0);
					ringgeom = value.geometry.rings;
					areageom = value.geometry;

				}));
			});

			queryTaskcir = new QueryTask(this.village);
			//-------For Query--------
			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["VIL_NAME,VINCODE "];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.outSpatialReference = {
				"wkid" : 102100
			};
			queryUsedFurther.returnDistinctValues = true;

			if (cirname === "All") {
				queryUsedFurther.where = "DTNCODE = '" + distrcitCode + "' and  THNCODE ='" + talukaCode + "' and CRNCODE <> '' ";
			} else if (cirname !== "All") {
				queryUsedFurther.where = "DTNCODE = '" + distrcitCode + "' and  THNCODE ='" + talukaCode + "' and CRNCODE ='" + circleCode + "'";
			}
			// console.log(queryUsedFurther.where);
			queryTaskcir.execute(queryUsedFurther).then(function(featureset) {
				// alert();
				var result = featureset.features;
				if (cirname != "All") {
					array.forEach(result, lang.hitch(this, function(value) {
						villname = value.attributes.VIL_NAME;
						villcode = value.attributes.VINCODE;
						if (villname) {
							if (!testVals[villname]) {
								testVals[villname] = true;
								zoneGetvilchange.push({
									name : villname,
									code : villcode

								});
							}
						}
					}));
					zoneGetvilchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetvilchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetvilchange.push({
						name : "All",
						code : "All"
					});
				} else if (cirname == "All") {

					zoneGetvilchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetvilchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetvilchange.push({
						name : "All",
						code : "All"
					});
				}

				// console.log(zoneGetvilchange);
				testValsn = {};
				array.forEach(zoneGetvilchange, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;
							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectvillage.add(option, 0);
						}
					}
				}));
				document.getElementById("villageh").value = "";
			});
		},

		villagechange : function() {
			var zone = [];
			var values = [];
			var testVals = {};
			zF = [];
			talname = document.getElementById("talukah").value;
			distname = document.getElementById("districth").value;
			villname = document.getElementById("villageh").value;
			cirname = document.getElementById("circleh").value;
			view.graphics.removeAll();

			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					districtCode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talukaCode = zoneGetdistchange[i].code;
				}
			}
			for (var i = 0; i < zoneGettalchange.length; i++) {
				if (zoneGettalchange[i].name === cirname) {
					circleCode = zoneGettalchange[i].code;
				}
			}

			for (var i = 0; i < zoneGetvilchange.length; i++) {
				if (zoneGetvilchange[i].name === villname) {
					villageCode = zoneGetvilchange[i].code;
				}
			}
			if ((distname != "All") && (talname == "All") && (cirname == "All") && (villname == "All")) {
				var queryTaskZm = new QueryTask({
					url : this.district
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "'";

				//----------------------Get Crop Layers All-----------
				distLayer = new FeatureLayer({
					url : this.district,
					id : "distLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);

			} else if ((distname != "All") && (talname !== "All") && (cirname == "All") && (villname == "All")) {
				var queryTaskZm = new QueryTask({
					url : this.taluka
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";

				//----------------------Get Crop Layers All-----------
				talukaLayer = new FeatureLayer({
					url : this.taluka,
					id : "distLayerDisplay"
				});
				talukaLayer.definitionExpression = queryZm.where;
				map.add(talukaLayer);

			} else if ((distname != "All") && (talname != "All") && (cirname !== "All") && (villname == "All")) {

				var circleUrlZm = this.circle;
				var queryTaskZm = new QueryTask({
					url : circleUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "' and CIRNCODE    = '" + circleCode + "'";
				circleLayer = new FeatureLayer({
					url : circleUrlZm,
					id : "cirLayerDisplay"
				});
				circleLayer.definitionExpression = queryZm.where;
				map.add(circleLayer);
			} else if ((distname != "All") && (talname != "All") && (cirname !== "All") && (villname != "All")) {

				var circleUrlZm = "https://portal.mrsac.org.in/webadpgis8/rest/services/admin2011/admin_village_16/MapServer/0";
				var queryTaskZm = new QueryTask({
					url : circleUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'and CRNCODE  = '" + circleCode + "'  and VINCODE   = '" + villageCode + "'";
				circleLayer = new FeatureLayer({
					url : circleUrlZm,
					id : "cirLayerDisplay"
				});
				circleLayer.definitionExpression = queryZm.where;
				map.add(circleLayer);
			}
			queryTaskZm.execute(queryZm).then(function(results) {
				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {
					bufgeometry = value.geometry;
					zF.push(value);
					var symbol = {
						type : "simple-line",
						color : "black",
						width : "2px",
						style : "solid"
					};
					slected_circle = zF[0].attributes.OBJECTID;
					var graphic = new Graphic(value.geometry, symbol);
					view.graphics.add(graphic, 0);
					ringgeom = value.geometry.rings;
					areageom = value.geometry;

				}));
			});

			// console.log(queryZm.where);
			queryTaskcir = new QueryTask(this.village);
			//-------For Query--------
			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["*"];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.outSpatialReference = {
				"wkid" : 102100
			};
			queryUsedFurther.returnDistinctValues = true;

			if (talname == 'All' && villname == 'All') {
				queryUsedFurther.where = "DTNCODE = '" + distrcitCode + "' and  THNCODE <>'' and VINCODE <> '' ";
			} else if (talname != 'All' && villname == 'All') {
				queryUsedFurther.where = "DTNCODE = '" + distrcitCode + "' and  THNCODE ='" + talukaCode + "' and VINCODE <> '' ";
			} else if (talname != 'All' && villname != 'All') {
				queryUsedFurther.where = "DTNCODE = '" + distrcitCode + "' and  THNCODE ='" + talukaCode + "' and  VINCODE '" + villageCode + "' ";
			}

			// console.log(queryUsedFurther.where);
			queryTaskcir.execute(queryUsedFurther).then(function(featureset) {
				var result = featureset.features;
				array.forEach(result, lang.hitch(this, function(value) {
					villname = value.attributes.VIL_NAME;
					villcode = value.attributes.VINCODE;
					if (villname) {
						if (!testVals[villname]) {
							testVals[villname] = true;
							circleCodeArray.push({
								name : villname,
								code : villcode
							});
						}
					}
				}));
			});
		},
		clearbutton : function() {
			view.graphics.removeAll();
			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			dom.byId("divLoadingIndicator").style.display = 'none';
			map.remove(this.featureLayer);
			featureLayer = new MapImageLayer({
				url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
				outFields : ["*"],
				mode : FeatureLayer.MODE_ONDEMAND,
			});
			map.removeAll(this.featureLayer);
			map.basemap = "topo";
			map.add(featureLayer);
			map.add(noncropmask);
			document.getElementById("divisionh").value = "";
			document.getElementById("districth").value = "";
			document.getElementById("talukah").value = " ";
			document.getElementById("circleh").value = " ";
			document.getElementById("villageh").value = " ";
			dom.byId("print").style.display = 'none';
			dom.byId("legend").style.display = 'none';
			dom.byId("legend1").style.display = 'none';
			dom.byId("mainContent").style.display = 'none';
		},

		submitbtn : function() {

			divname = document.getElementById("divisionh").value;
			distname = document.getElementById("districth").value;
			talname = document.getElementById("talukah").value;
			villname = document.getElementById("villageh").value;
			cirname = document.getElementById("circleh").value;

			if (divname === "" || distname === "") {
				swal("Please select proper input");
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});
				map.basemap = "topo";
				view.graphics.removeAll();
				dom.byId("print").style.display = 'none';
				map.add(featureLayer);
				map.add(noncropmask);
				dom.byId("divLoadingIndicator").style.display = 'none';
			} else {
				document.getElementById("mainContent").style.display = "none";
				dom.byId("divLoadingIndicator").style.display = 'block';
				dom.byId("legend").style.display = 'block';
				dom.byId("legend1").style.display = 'block';

				map.removeAll(this.featureLayer);
				// map.basemap = "";
				view.goTo(zF);
				dom.byId("print").style.display = 'block';
				document.getElementById("sapota").style.display = "none";
				document.getElementById("citrus").style.display = "none";
				document.getElementById("coconut").style.display = "none";
				document.getElementById("grapes").style.display = "none";
				document.getElementById("guava").style.display = "none";
				document.getElementById("mango").style.display = "none";
				document.getElementById("pomegranate").style.display = "none";
				document.getElementById("unconfirmed").style.display = "none";

				if (document.getElementById("districth").value === "") {
					distname = "All";
				}
				if (document.getElementById("talukah").value === "") {
					talname = "All";
				}
				if (document.getElementById("circleh").value === "") {
					cirname = "All";
				}
				if (document.getElementById("villageh").value === "") {
					villname = "All";
				}

				for (var i = 0; i < zoneGetdivchange.length; i++) {
					if (zoneGetdivchange[i].name === distname) {
						districtCode = zoneGetdivchange[i].code;
					}
				}
				for (var i = 0; i < zoneGetdistchange.length; i++) {
					if (zoneGetdistchange[i].name === talname) {
						talukaCode = zoneGetdistchange[i].code;
					}
				}
				for (var i = 0; i < circleCodeArray.length; i++) {
					if (circleCodeArray[i].name === villname) {
						villageCode = circleCodeArray[i].code;
					}
				}

				for (var i = 0; i < zoneGettalchange.length; i++) {
					if (zoneGettalchange[i].name === cirname) {
						circleCode = zoneGettalchange[i].code;
					}
				}

				if (document.getElementById("villageh").value === "") {
					villname = "All";
				}

				//---------------------orchard--------------------
				var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/orchardvillage/MapServer?f=pjson";
				esriRequest(url, {
					responseType : "json"
				}).then(function(response) {
					// The requested data
					var geoJson = response.data;
					var layersArray = geoJson.layers;
					array.forEach(layersArray, lang.hitch(this, function(LayerAll) {

						if (distname === LayerAll.name) {
							idDistLyr = LayerAll.id;
							lyerURL = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/orchardvillage/MapServer/" + idDistLyr;
							this.featureLayer = new FeatureLayer(lyerURL, {
								mode : FeatureLayer.MODE_SNAPSHOT,
								outFields : ["*"],
							});

							if (distname != 'All' && talname == 'All' && cirname == 'All' && villname == 'All') {
								this.featureLayer.definitionExpression = "Crop_Code <> '' and DTNCODE ='" + districtCode + "' ";
							} else if (distname != 'All' && talname !== 'All' && cirname == 'All' && villname == 'All') {
								this.featureLayer.definitionExpression = "Crop_Code <> '' and DTNCODE ='" + districtCode + "' and  THNCODE = '" + talukaCode + "'  ";
							} else if (distname != 'All' && talname != 'All' && cirname !== 'All' && villname == 'All') {
								this.featureLayer.definitionExpression = "Crop_Code <> '' and DTNCODE ='" + districtCode + "' and  THNCODE = '" + talukaCode + "' and  CIRNCODE  = '" + circleCode + "' ";
							} else if (distname != 'All' && talname != 'All' && cirname !== 'All' && villname !== 'All') {
								this.featureLayer.definitionExpression = "Crop_Code <> '' and DTNCODE ='" + districtCode + "' and  THNCODE = '" + talukaCode + "' and  CIRNCODE  = '" + circleCode + "' and  VINCODE = '" + villageCode + "' ";
							}
							console.log(this.featureLayer.definitionExpression);
							map.add(this.featureLayer);

							swipe.leadingLayers.add(this.featureLayer);
							swipe.trailingLayers.add(noncropmask);

							//-------------------district boundary------------
							if (distname != 'All' && talname == 'All' && cirname == 'All' && villname == 'All') {
								var bikeTrailsRenderer = {
									type : "simple",
									symbol : {
										type : "simple-line",
										color : "#e0b353",
										width : "1px"
									}
								};
								this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/3", {
									mode : FeatureLayer.MODE_SNAPSHOT,
									outFields : ["*"],
									renderer : bikeTrailsRenderer,
								});

								if (distname != 'All' && villname == 'All') {
									this.featureLayer.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE  <>''";
								}

								map.add(this.featureLayer);
								dom.byId("divLoadingIndicator").style.display = 'none';
							}

							//-------------------taluka boundary------------
							if (distname != 'All' && talname !== 'All' && cirname == 'All' && villname == 'All') {

								this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/baselayers/circle_boundary/MapServer/0", {
									mode : FeatureLayer.MODE_SNAPSHOT,
									outFields : ["*"],
								});

								if (distname != 'All' && villname == 'All') {
									this.featureLayer.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";
								}

								map.add(this.featureLayer);
								dom.byId("divLoadingIndicator").style.display = 'none';
							}

							//-------------------circle boundary------------
							if (distname != 'All' && talname !== 'All' && cirname !== 'All' && villname == 'All') {

								this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/admin2011/admin_village_16/MapServer/0", {
									mode : FeatureLayer.MODE_SNAPSHOT,
									outFields : ["*"],
								});

								if (distname != 'All' && villname == 'All') {
									this.featureLayer.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "' and CRNCODE  = '" + circleCode + "'";
								}

								map.add(this.featureLayer);
								dom.byId("divLoadingIndicator").style.display = 'none';
							}

							//-------------------village boundary / cadastral------------
							if (distname != 'All' && talname != 'All' && cirname !== 'All' && villname !== 'All') {
								var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/baselayers/cadastral/MapServer?f=pjson";
								" /MapServer?f=pjson";
								esriRequest(url, {
									responseType : "json"
								}).then(function(response) {
									// The requested data
									var geoJson = response.data;
									var layersArray = geoJson.layers;
									array.forEach(layersArray, lang.hitch(this, function(LayerAll) {
										// console.log(LayerAll.name);
										// console.log(LayerAll.id);
										if (LayerAll.name) {
											idDistLyr = LayerAll.id;
											lyerURLc = "https://portal.mrsac.org.in/webadpgis8/rest/services/baselayers/cadastral/MapServer/" + idDistLyr;
											// console.log(lyerURL);
											if (distname === LayerAll.name) {
												var bikeTrailsRenderer = {
													type : "simple",
													symbol : {
														type : "simple-line",
														color : "#e0b353",
														width : "0.5px"
													}
												};
												this.featureLayer = new FeatureLayer(lyerURLc, {
													mode : FeatureLayer.MODE_SNAPSHOT,
													outFields : ["*"],
													renderer : bikeTrailsRenderer,
												});

												if (distname != 'All' && talname == 'All' && villname == 'All') {
													this.featureLayer.definitionExpression = "DTNCODE ='" + districtCode + "' ";
												} else if (distname != 'All' && talname !== 'All' && villname == 'All') {
													this.featureLayer.definitionExpression = "DTNCODE ='" + districtCode + "' and  THNCODE = '" + talukaCode + "'  ";
												} else if (distname != 'All' && talname != 'All' && villname !== 'All') {
													this.featureLayer.definitionExpression = "DTNCODE ='" + districtCode + "' and  THNCODE = '" + talukaCode + "' and  VINCODE = '" + villageCode + "' ";
												}
												map.add(this.featureLayer);
												dom.byId("divLoadingIndicator").style.display = 'none';
											}
										}
									}));
								});
							}

							//--------------------legend------------

							var queryTaskZm = new QueryTask({
								url : lyerURL
							});
							var queryZm = new Query();
							queryZm.returnGeometry = true;
							queryZm.outSpatialReference = {
								wkid : 102100
							};
							queryZm.outFields = ["*"];

							if (distname != 'All' && talname == 'All' && cirname == 'All' && villname == 'All') {
								queryZm.where = "Crop_Code <> '' and DTNCODE ='" + districtCode + "' ";
							} else if (distname != 'All' && talname !== 'All' && cirname == 'All' && villname == 'All') {
								queryZm.where = "Crop_Code <> '' and DTNCODE ='" + districtCode + "' and  THNCODE = '" + talukaCode + "'  ";
							} else if (distname != 'All' && talname != 'All' && cirname !== 'All' && villname == 'All') {
								queryZm.where = "Crop_Code <> '' and DTNCODE ='" + districtCode + "' and  THNCODE = '" + talukaCode + "' and  CIRNCODE = '" + circleCode + "' ";
							} else if (distname != 'All' && talname != 'All' && cirname !== 'All' && villname !== 'All') {
								queryZm.where = "Crop_Code <> '' and DTNCODE ='" + districtCode + "' and  THNCODE = '" + talukaCode + "' and  CIRNCODE = '" + circleCode + "' and  VINCODE = '" + villageCode + "' ";
							}

							queryTaskZm.execute(queryZm).then(function(results) {
								var result_features = results.features;

								if (result_features.length == 0) {
									swal("Data Not Available");
								} else {
									array.forEach(result_features, lang.hitch(this, function(value) {

										var cropname = value.attributes.Crop_Names;

										if (cropname == 'Sapota') {
											document.getElementById("sapota").style.display = "block";
										} else if (cropname == 'Citrus') {
											document.getElementById("citrus").style.display = "block";
										} else if (cropname == 'Coconut+Arecanut') {
											document.getElementById("coconut").style.display = "block";
										} else if (cropname == 'Grapes') {
											document.getElementById("grapes").style.display = "block";
										} else if (cropname == 'Guava') {
											document.getElementById("guava").style.display = "block";
										} else if (cropname == 'Mango') {
											document.getElementById("mango").style.display = "block";
										} else if (cropname == 'Pomegranate') {
											document.getElementById("pomegranate").style.display = "block";
										} else if (cropname == 'Unconfirmed Orchard') {
											document.getElementById("unconfirmed").style.display = "block";
										} else if (cropname == 'Unconfirmed orchard') {
											document.getElementById("unconfirmed").style.display = "block";
										}

									}));
								}
							});
						}
					}));
				});
			}
		},

		generatemap : function() {

			dom.byId("divLoadingIndicator").style.display = 'block';

			divname = document.getElementById("divisionh").value;
			distname = document.getElementById("districth").value;
			talname = document.getElementById("talukah").value;
			villname = document.getElementById("villageh").value;
			cirname = document.getElementById("circleh").value;

			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					districtCode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talukaCode = zoneGetdistchange[i].code;
				}
			}
			for (var i = 0; i < circleCodeArray.length; i++) {
				if (circleCodeArray[i].name === villname) {
					villageCode = circleCodeArray[i].code;
				}
			}

			for (var i = 0; i < zoneGettalchange.length; i++) {
				if (zoneGettalchange[i].name === cirname) {
					circleCode = zoneGettalchange[i].code;
				}
			}

			if (document.getElementById("districth").value === "") {
				distname = "All";
				districtCode = "All";
			}
			if (document.getElementById("talukah").value === "") {
				talname = "All";
				talukaCode = "All";
			}
			if (document.getElementById("circleh").value === "") {
				cirname = "All";
				circleCode = "All";
			}
			if (document.getElementById("villageh").value === "") {
				villname = "All";
				villageCode = "All";
			}

			var gpUrl = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/orchardstemp/GPServer/orchardstemp";
			var gp = new Geoprocessor(gpUrl);
			var parameters = {
				"district" : distname,
				"taluka" : talname,
				"circle" : cirname,
				"village" : villname,
				"dist_cd" : districtCode,
				"tal_cd" : talukaCode,
				"cir_cd" : circleCode,
				"vill_cd" : villageCode
			};

			// console.log(parameters);
			gp.execute(parameters).then(ShowResultData);

			function ShowResultData(result) {
				// alert(result);
				// console.log(result.results[0].value);
				var resultImg = result.results[0].value.url;
				var center_left = (screen.width / 2.5) - (400 / 2);
				var center_top = (screen.height / 2.5) - (400 / 2);
				window.open(resultImg, target = '_blank', 'width=1000,height=750, top=' + center_top + ', left=' + center_left);
				dom.byId("divLoadingIndicator").style.display = 'none';
			}

		},

		ViewReport : function() {
			debugger;
			
			dom.byId("divLoadingIndicator").style.display = 'block';
			divname = document.getElementById("divisionh").value;
			distname = document.getElementById("districth").value;
			talname = document.getElementById("talukah").value;
			villname = document.getElementById("villageh").value;
			cirname = document.getElementById("circleh").value;

			if (divname === "" || distname === "") {
				swal("Please select proper input");
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});
				map.basemap = "topo";
				view.graphics.removeAll();
				dom.byId("print").style.display = 'none';
				map.add(featureLayer);
				map.add(noncropmask);
				dom.byId("divLoadingIndicator").style.display = 'none';
			} else {

				for (var i = 0; i < zoneGetdivchange.length; i++) {
					if (zoneGetdivchange[i].name === distname) {
						districtCode = zoneGetdivchange[i].code;
					}
				}
				for (var i = 0; i < zoneGetdistchange.length; i++) {
					if (zoneGetdistchange[i].name === talname) {
						talukaCode = zoneGetdistchange[i].code;
					}
				}

				for (var i = 0; i < zoneGetcirchange.length; i++) {
					if (zoneGetcirchange[i].name === cirname) {
						circleCode = zoneGetcirchange[i].code;
					}
				}

				for (var i = 0; i < circleCodeArray.length; i++) {
					if (circleCodeArray[i].name === villname) {
						villageCode = circleCodeArray[i].code;
					}
				}

				if (document.getElementById("districth").value === "") {
					distname = "All";
					districtCode = "All";
				}
				if (document.getElementById("talukah").value === "") {
					talname = "All";
					talukaCode = "All";
				}
				if (document.getElementById("circleh").value === "") {
					cirname = "All";
					circleCode = "All";
				}
				if (document.getElementById("villageh").value === "") {
					villname = "All";
					villageCode = "All";
				}

				var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/orchardvillage/MapServer?f=pjson";
				esriRequest(url, {
					responseType : "json"
				}).then(function(response) {
					// The requested data
					var geoJson = response.data;
					var layersArray = geoJson.layers;
					array.forEach(layersArray, lang.hitch(this, function(LayerAll) {

						if (distname === LayerAll.name) {
							idDistLyr = LayerAll.id;

							document.getElementById("mainContent").style.display = "block";

							$("#mainContent").load("http://117.240.213.118:6080/cropacreagereport1/orchardstathtml?division=All&distName=" + distname + "&district=" + idDistLyr + "&dtncode=" + districtCode + "&taluka=" + talukaCode + "&circle=" + circleCode + "&division_n=" + divname + "&taluka_n=" + talname + "&circle_n=" + cirname + "&village_n=" + villname + "&village=" + villageCode, function() {								
								 
								//alert("Load was performed.");
								$('#datatable').DataTable();
								dom.byId("divLoadingIndicator").style.display = 'none';
							});

						}
					}));
				});
			}

			
		},
	});
});
