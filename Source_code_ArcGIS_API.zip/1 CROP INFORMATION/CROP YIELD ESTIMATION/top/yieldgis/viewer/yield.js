/**
 * @author Shahana.Sheikh
 */
define(["dojo/_base/declare", "dijit/registry", "dijit/_WidgetBase", "dijit/_TemplatedMixin", "dojo/text!./templates/yield.html", "dojo/_base/window", "dijit/_WidgetsInTemplateMixin", "dijit/layout/AccordionContainer", "esri/Map", "esri/request", "esri/views/MapView", "dojo/_base/lang", "dojo/dom-attr", "dojo/aspect", "dojo/store/Memory", "dijit/form/ComboBox", "dijit/TooltipDialog", "dijit/form/Select", "dijit/form/FilteringSelect", "dijit/TitlePane", "esri/widgets/Expand", "esri/layers/KMLLayer", "esri/geometry/geometryEngine", "esri/layers/Layer", "esri/WebMap", "esri/widgets/Search", "esri/Basemap", "esri/widgets/Locate", "esri/widgets/Track", "esri/Graphic", "esri/widgets/Compass", "esri/layers/MapImageLayer", "esri/widgets/CoordinateConversion", "esri/tasks/Geoprocessor", "dijit/Tooltip", "esri/tasks/support/RelationshipQuery", "esri/tasks/Locator", "esri/widgets/Home", "esri/widgets/BasemapToggle", "esri/widgets/Swipe", "esri/widgets/ScaleBar", "esri/geometry/Extent", "dojo/_base/lang", "dojo/topic", "esri/config", "esri/identity/ServerInfo", "esri/identity/IdentityManager", "esri/layers/FeatureLayer", "esri/tasks/support/FeatureSet", "esri/layers/ImageryLayer", "esri/layers/MapImageLayer", "esri/tasks/ClosestFacilityTask", "esri/tasks/support/ClosestFacilityParameters", "dojo/_base/array", "dojo/on", "dojo/dom", "dojo/dom-construct", "dojo/dom-style", "dojo/dom-attr", "dojo/dom-class", "esri/symbols/PictureMarkerSymbol", "esri/renderers/SimpleRenderer", "esri/symbols/SimpleMarkerSymbol", "esri/Graphic", "esri/widgets/Popup", "esri/PopupTemplate", "dijit/TooltipDialog", "esri/core/lang", "esri/tasks/QueryTask", "esri/tasks/support/Query", "dojo/query", "dojo/store/Memory", "dijit/form/ComboBox", "dijit/form/DateTextBox", "dojo/data/ItemFileReadStore", "dijit/form/Select", "dijit/form/FilteringSelect", "esri/layers/GraphicsLayer", "esri/widgets/Sketch", "esri/geometry/Point", "esri/geometry/Circle", "esri/geometry/SpatialReference", "esri/symbols/SimpleLineSymbol", "esri/symbols/SimpleFillSymbol", "esri/Color", "esri/Graphic", "esri/request", "dojo/dom-style", "esri/widgets/Legend", "esri/tasks/FindTask", "dojo/request/xhr", 'dojo/data/ObjectStore', "dojo/request", "dojo/number", "dijit/layout/BorderContainer", "dijit/layout/TabContainer", "dijit/layout/ContentPane", "dijit/TitlePane", "dijit/form/Form", "esri/widgets/BasemapGallery", "dijit/form/TextBox", "dijit/Dialog", "dijit/form/CheckBox", "dijit/form/RadioButton", "dijit/Menu", "esri/layers/ImageryLayer", "esri/layers/support/RasterFunction", "esri/layers/support/DimensionalDefinition", "esri/layers/support/MosaicRule", "dijit/MenuItem", "dijit/layout/ContentPane", "dijit/Toolbar", "dijit/form/Button", "dojox/widget/TitleGroup", "esri/core/urlUtils", "dojo/_base/json", "dojo/domReady!"], function(declare, registry, _WidgetBase, _TemplatedMixin, template, win, _WidgetsInTemplateMixin, AccordionContainer, Map, esriRequest, MapView, lang, domAttr, aspect, Memory, ComboBox, TooltipDialog, Select, FilteringSelect, TitlePane, Expand, KMLLayer, geometryEngine, Layer, WebMap, Search, Basemap, Locate, Track, Graphic, Compass, MapImageLayer, CoordinateConversion, Geoprocessor, Tooltip, RelationshipQuery, Locator, Home, BasemapToggle, Swipe, ScaleBar, Extent, lang, topic, esriConfig, ServerInfo, esriId, FeatureLayer, FeatureSet, ImageryLayer, MapImageLayer, ClosestFacilityTask, ClosestFacilityParameters, array, on, dom, domConstruct, domStyle, domAttr, domClass, PictureMarkerSymbol, SimpleRenderer, SimpleMarkerSymbol, Graphic, Popup, PopupTemplate, TooltipDialog, esriLang, QueryTask, Query, query, Memory, ComboBox, DateTextBox, ItemFileReadStore, FilteringSelect, Select, GraphicsLayer, Sketch, Point, Circle, SpatialReference, SimpleLineSymbol, SimpleFillSymbol, Color, Graphic, esriRequest, domStyle, Legend, FindTask, xhr, ObjectStore, request, number, BorderContainer, TabContainer, ContentPane, TitlePane, Form, BasemapGallery, TextBox, Dialog, CheckBox, RadioButton, Menu, ImageryLayer, RasterFunction, DimensionalDefinition, MosaicRule, urlUtils, MenuItem, json) {
	return declare("mrsac.viewer.horticulture", [_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {

		constructor : function() {
			valueKharif = [];
			valuesRabi = [];
			valuesOthers = [];
			zoneGetcropchange = [];
			zoneGetdivchange = [];
			zoneGetdistchange = [];
			zoneGettalchange = [];

			//-----------Kharif total sown---------
			zFKhdivchange = [];
			zFKhdistchange = [];
			agriArrayPrint = [];
			zF = [];
			tableIterationFlag = true;
			dataTableObj = null;
			tableIterationFlag2 = true;
			dataTableObj2 = null;

			totcirareacount = 0;
			totcountarearound = 0;
			graphTitle = "";
			finalData = [];

		},
		currentTab : "cropsown",
		agriarea : null,
		ringgeom : null,
		queryZm : null,
		contextMenu : null,
		queryUsedFurther : null,
		remapRFnoncrp : null,
		resultAgriLandUseArea : null,
		templateString : template,
		postMixInProperties : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				alert("err" + err);
				console.error(err);
			}
		},
		postCreate : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				console.error(err);
			}
		},
		startup : function() {
			if (this._started) {

				return;
			}
			try {

				featureLayer = new MapImageLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
					outFields : ["*"],
					mode : FeatureLayer.MODE_ONDEMAND,
				});
				map.add(featureLayer);

				var selectsea = document.getElementById("seasonSelect");
				while (selectsea.firstChild) {
					selectsea.removeChild(selectsea.firstChild);
				}

				var legend = new Legend({
					view : view
				});

				var zone = ['Kharif'];
				zone.sort();
				zone.reverse();
				var testValsn = {};

				array.forEach(zone, lang.hitch(this, function(vals) {

					if (vals) {
						if (!testValsn[vals]) {
							testValsn[vals] = true;

							var option = document.createElement('option');
							option.text = option.value = vals;
							selectsea.add(option, 0);
						}
					}
				}));
				document.getElementById("seasonSelect").value = "";

				noncropmask = new ImageryLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/noncropmask_2019/ImageServer",
					opacity : 0.3,
					id : "noncropmaskId"

				});
				map.add(noncropmask);

				//--------services  used-------------
				this.state = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/0";
				this.division = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/1";
				this.district = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/2";
				this.taluka = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/3";

				//-----------------------------new service----------------------------

				this.yield = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/Soybean_Yield_Map/MapServer/0";

				this.getSownYear();

			} catch (err) {
				console.error("SearchWidget::startup", err);

			}

		},

		getLegendMenu : function() {

			yearLeg = document.getElementById("year").value;
			cropsLeg = document.getElementById("cropSelect").value;
			seasonLeg = document.getElementById("seasonSelect").value;

			//------------Bind json crop wise------------
			if ( currentTab = "cropsown") {

			}
		},

		getSownYear : function() {
			debugger;
			document.getElementById("seasonSelect").value = "";
			var zone = [];
			var testVals = {};
			selectYear = document.getElementById("year");
			var zone = ['2020-21'];
			zone.sort();
			testValsn = {};
			array.forEach(zone, lang.hitch(this, function(vals) {
				if (vals) {
					if (!testValsn[vals]) {
						testValsn[vals] = true;

						var option = document.createElement('option');
						option.text = option.value = vals;
						selectYear.add(option, 0);
					}
				}
			}));
			document.getElementById("year").value = "";

		},
		getYearChange : function() {
			document.getElementById("seasonSelect").value = " ";
			document.getElementById("cropSelect").value = " ";
			document.getElementById("division").value = " ";
			document.getElementById("district").value = " ";
			document.getElementById("taluka").value = " ";
			// document.getElementById("circle").value = " ";
			//------------------------
			dom.byId("Stat").style.display = 'none';
			cropSapLayer = map.findLayerById("cropsapGraphichId");
			if (cropSapLayer) {
				map.remove(cropSapLayer);
			}
			// this.removeLayersWithId();
			view.graphics.removeAll();

		},
		getSeasonChange : function() {
			debugger;
			// document.getElementById("cropSelect").value = " ";
			document.getElementById("division").value = " ";
			document.getElementById("district").value = " ";
			document.getElementById("taluka").value = " ";
			// document.getElementById("circle").value = " ";
			dom.byId("Stat").style.display = 'none';
			// valuesRabi = [];
			var testVals = {};
			var valueKharif = [];
			// var valuesOthers = [];

			// year = document.getElementById("year").value;
			selectcrop = document.getElementById("cropSelect");
			while (selectcrop.firstChild) {
				selectcrop.removeChild(selectcrop.firstChild);
			}

			var valueKharif = ['Soybean'];

			testValsnc = {};

			array.forEach(valueKharif, lang.hitch(this, function(vals) {

				if (vals) {
					if (!testValsnc[vals]) {
						testValsnc[vals] = true;

						var option = document.createElement('option');
						option.text = option.value = vals;
						selectcrop.add(option, 0);
					}
				}
			}));
			document.getElementById("cropSelect").value = "";
		},
		cropchange : function() {
			// debugger;
			//******************Division Populate*****************
			cropyear = document.getElementById("year").value;
			cropname = document.getElementById("cropSelect").value;
			seasonName = document.getElementById("seasonSelect").value;
			// alert(cropname);
			document.getElementById("district").value = " ";
			document.getElementById("taluka").value = " ";
			// document.getElementById("circle").value = " ";
			dom.byId("Stat").style.display = 'none';
			//===========Division Name in Setence Case================

			zoneGetcropchange = [];
			var values = [];
			var testVals = {};

			selectDiv = document.getElementById("division");

			while (selectDiv.firstChild) {
				selectDiv.removeChild(selectDiv.firstChild);
			}

			queryTaskdiv = new QueryTask(this.yield);
			var query = new Query();
			query.outFields = ["ADVENAME ", "ADVNCODE"];
			query.returnGeometry = false;
			query.returnDistinctValues = true;
			query.where = "1=1";
			console.log(query.where);
			queryTaskdiv.execute(query).then(function(featureset) {

				var result = featureset.features;
				array.forEach(result, lang.hitch(this, function(value) {

					div_name = value.attributes.ADVENAME;
					div_code = value.attributes.ADVNCODE;
					//division_name = upperCaseFirstLetter(lowerCaseAllWordsExceptFirstLetters(div_name));
					if (div_name) {
						if (!testVals[div_name]) {
							testVals[div_name] = true;
							zoneGetcropchange.push({
								name : div_name,
								code : div_code
							});
						}
					}
				}));
				if (zoneGetcropchange.length == 0) {
					swal("Data not available");
				} else {
					zoneGetcropchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetcropchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetcropchange.push({
						name : "All",
						code : "All"
					});

					testValsn = {};

					array.forEach(zoneGetcropchange, lang.hitch(this, function(vals) {

						if (vals.name) {
							if (!testValsn[vals.name]) {
								testValsn[vals.name] = true;

								var option = document.createElement('option');
								option.text = option.value = vals.name;
								selectDiv.add(option, 0);
							}
						}
					}));
					document.getElementById("division").value = "";
				}

			});

		},
		getdivchange : function() {
			debugger;
			//******************District Populate*****************
			cropyear = document.getElementById("year").value;
			cropname = document.getElementById("cropSelect").value;
			divi = document.getElementById("division").value;

			for (var i = 0; i < zoneGetcropchange.length; i++) {
				if (zoneGetcropchange[i].name === divi) {
					divisionCode = zoneGetcropchange[i].code;
				}
			}

			document.getElementById("district").value = " ";
			document.getElementById("taluka").value = " ";
			// document.getElementById("circle").value = " ";
			dom.byId("Stat").style.display = 'none';
			//dvename = divi.toUpperCase();

			for (var i = 0; i < valueKharif.length; i++) {
				if (valueKharif[i].name === cropname) {
					cropCode = valueKharif[i].code;
				}
			}
			function upperCaseFirstLetter(string) {
				return string.charAt(0).toUpperCase() + string.slice(1);
			}

			function lowerCaseAllWordsExceptFirstLetters(string) {
				return string.replace(/\w\S*/g, function(word) {
					return word.charAt(0) + word.slice(1).toLowerCase();
				});
			}

			dvename = upperCaseFirstLetter(lowerCaseAllWordsExceptFirstLetters(divi));
			zoneGetdivchange = [];
			// this.removeLayersWithId();
			view.graphics.removeAll();
			var values = [];
			var testVals = {};

			if (divi == "All") {
				var queryTaskZm = new QueryTask({
					url : this.state
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "STENAME = 'Maharashtra'";

				stateLayer = new FeatureLayer({
					url : this.state,
					id : "stateLayerDisplay"
				});
				stateLayer.definitionExpression = queryZm.where;
				map.add(stateLayer);

			} else if (divi != "All") {
				var queryTaskZm = new QueryTask({
					url : this.division
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "ADVENAME  = '" + dvename + "'";
				divisionLayer = new FeatureLayer({
					url : this.division,
					id : "diviLayerDisplay"
				});
				divisionLayer.definitionExpression = queryZm.where;
				map.add(divisionLayer);

			}
			console.log(queryZm.where);

			queryTaskZm.execute(queryZm).then(function(results) {
				console.log(results);
				var result_features = results.features;
				console.log(result_features);
				array.forEach(result_features, lang.hitch(this, function(value) {

					bufgeometry = value.geometry;
					console.log(value);
					zF.push(value);

					var symbol = {
						type : "simple-line",
						color : "black",
						width : "2px",
						style : "solid"
					};
					var districtGraphic = new Graphic(value.geometry, symbol);
					view.graphics.add(districtGraphic, 0);
					ringgeom = value.geometry.rings;

				}));

			});

			selectDist = document.getElementById("district");
			while (selectDist.firstChild) {
				selectDist.removeChild(selectDist.firstChild);
			}
			queryTaskdist = new QueryTask(this.yield);

			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["DTENAME ,DTNCODE"];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.returnDistinctValues = true;
			queryUsedFurther.where = "ADVNCODE = '" + divisionCode + "' and DTNCODE <> ''";
			console.log(queryUsedFurther.where);
			queryTaskdist.execute(queryUsedFurther).then(function(featureset) {

				var result = featureset.features;
				if (divi != "All") {
					array.forEach(result, lang.hitch(this, function(value) {
						dis_name = value.attributes.DTENAME;
						dist_code = value.attributes.DTNCODE;
						if (dis_name) {
							if (!testVals[dis_name]) {
								testVals[dis_name] = true;
								zoneGetdivchange.push({
									name : dis_name,
									code : dist_code,
								});
							};
						}
					}));

					zoneGetdivchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});

					zoneGetdivchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdivchange.push({
						name : "All",
						code : "All"
					});
				} else if (divi == "All") {
					zoneGetdivchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});

					zoneGetdivchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdivchange.push({
						name : "All",
						code : "All"
					});
				}

				testValsn = {};

				array.forEach(zoneGetdivchange, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectDist.add(option, 0);
						}
					}
				}));
				document.getElementById("district").value = "";
			});
			// map.basemap = "";
		},
		getdistchange : function() {
			distname = document.getElementById("district").value;
			talname = document.getElementById("taluka").value;
			cropyear = document.getElementById("year").value;
			divi = document.getElementById("division").value;
			cropname = document.getElementById("cropSelect").value;
			document.getElementById("taluka").value = " ";
			// document.getElementById("circle").value = " ";
			//dvename = divi.toUpperCase();
			dom.byId("Stat").style.display = 'none';
			for (var i = 0; i < valueKharif.length; i++) {
				if (valueKharif[i].name === cropname) {
					cropCode = valueKharif[i].code;
				}
			}

			//===========Division Name in Sentence Case================
			function upperCaseFirstLetter(string) {
				return string.charAt(0).toUpperCase() + string.slice(1);
			}

			function lowerCaseAllWordsExceptFirstLetters(string) {
				return string.replace(/\w\S*/g, function(word) {
					return word.charAt(0) + word.slice(1).toLowerCase();
				});
			}

			division = upperCaseFirstLetter(lowerCaseAllWordsExceptFirstLetters(divi));
			//========================================================
			// this.removeLayersWithId();
			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					distrcitCode = zoneGetdivchange[i].code;
				}
			}
			view.graphics.removeAll();

			zoneGetdistchange = [];
			var testVals = {};
			zF = [];
			var district_LayerUrlZm = this.district;
			if ((division == "All" && distname == "All" && talname == "") || (division == "All" && distname == "" && talname == "")) {
				var queryTaskZm = new QueryTask({
					url : this.state
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "STENAME = 'Maharashtra'";

				stateLayer = new FeatureLayer({
					url : this.state,
					id : "stateLayerDisplay"
				});
				stateLayer.definitionExpression = queryZm.where;
				map.add(stateLayer);

			} else if ((division == "All" && distname != "All") || (division != "All" && distname != "All")) {
				var queryTaskZm = new QueryTask({
					url : district_LayerUrlZm
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "'";

				//----------------------Get Crop Layers All-----------
				distLayer = new FeatureLayer({
					url : this.district,
					id : "distLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);

			} else if (division != "All" && distname == "All") {
				var queryTaskZm = new QueryTask({
					url : this.division
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "ADVENAME = '" + divi + "'";

				divisionLayer = new FeatureLayer({
					url : this.division,
					id : "diviLayerDisplay"
				});
				divisionLayer.definitionExpression = queryZm.where;
				map.add(divisionLayer);
			}
			console.log(queryZm.where);
			queryTaskZm.execute(queryZm).then(function(results) {

				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {

					bufgeometry = value.geometry;
					zF.push(value);
					var symbol = {
						type : "simple-line", // autocasts as new SimpleLineSymbol()
						color : "black",
						width : "2px",
						style : "solid"
					};
					var districtGraphic = new Graphic(value.geometry, symbol);
					view.graphics.add(districtGraphic, 0);
					// view.goTo(zF);
					geomextent = value.geometry.extent;

					ringgeom = value.geometry.rings;
					areageom = value.geometry;
					// this.noncropMaskClip();
				}));

			});

			debugger;

			selecttal = document.getElementById("taluka");

			while (selecttal.firstChild) {
				selecttal.removeChild(selecttal.firstChild);
			}
			queryTasktal = new QueryTask(this.yield);

			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["THENAME", "THNCODE"];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.outSpatialReference = {
				"wkid" : 102100
			};
			queryUsedFurther.returnDistinctValues = true;

			queryUsedFurther.where = "DTNCODE = '" + distrcitCode + "'";
			console.log(queryUsedFurther.where);
			queryTasktal.execute(queryUsedFurther).then(function(featureset) {

				var result = featureset.features;
				if (distname != "All") {
					array.forEach(result, lang.hitch(this, function(value) {

						tal_name = value.attributes.THENAME;
						tal_code = value.attributes.THNCODE;
						if (tal_name) {
							if (!testVals[tal_name]) {
								testVals[tal_name] = true;
								zoneGetdistchange.push({
									name : tal_name,
									code : tal_code
								});
							}
						}
					}));

					zoneGetdistchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.push({
						name : "All",
						code : "All"
					});
				} else if (distname == "All") {
					zoneGetdistchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.push({
						name : "All",
						code : "All"
					});
				}

				testValsn = {};

				array.forEach(zoneGetdistchange, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selecttal.add(option, 0);
						}
					}
				}));
				document.getElementById("taluka").value = "";

			});
			// map.basemap = "";

		},

		gettalchange : function() {
			divi = document.getElementById("division").value;
			distname = document.getElementById("district").value;
			talname = document.getElementById("taluka").value;
			cropyear = document.getElementById("year").value;
			cropname = document.getElementById("cropSelect").value;
			// document.getElementById("circle").value = " ";
			//divname = divi.toUpperCase();
			dom.byId("Stat").style.display = 'none';
			var values = [];
			zoneGettalchange = [];
			var testVals = {};
			zF = [];
			view.graphics.removeAll();

			// this.removeLayersWithId();

			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					distrcitCode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talukaCode = zoneGetdistchange[i].code;
				}
			}

			console.log(distrcitCode);

			if (divi == "All" && distname == "All" && talname == "All") {
				var queryTaskZm = new QueryTask({
					url : this.state
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "STENAME = 'Maharashtra'";
				stateLayer = new FeatureLayer({
					url : this.state,
					id : "stateLayerDisplay"
				});
				stateLayer.definitionExpression = queryZm.where;
				map.add(stateLayer);
			} else if ((divi != "All" && distname == "All" && talname == "All")) {
				var queryTaskZm = new QueryTask({
					url : this.division
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "ADVENAME = '" + divi + "'";
				distLayer = new FeatureLayer({
					url : this.district,
					id : "distalLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);

			} else if ((divi != "All" && distname != "All" && talname == "All")) {
				var district_LayerUrlZm = this.district;

				var queryTaskZm = new QueryTask({
					url : district_LayerUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "'";

				distLayer = new FeatureLayer({
					url : this.district,
					id : "distalLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);
			} else if ((divi != "All" && distname != "All" && talname != "All")) {
				var taluka_LayerUrlZm = this.taluka;
				var queryTaskZm = new QueryTask({
					url : taluka_LayerUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";

				talLayer = new FeatureLayer({
					url : this.taluka,
					id : "talLayerDisplay"
				});
				talLayer.definitionExpression = queryZm.where;
				map.add(talLayer);

			}
			console.log(queryZm.where);
			queryTaskZm.execute(queryZm).then(function(results) {
				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {
					bufgeometry = value.geometry;
					zF.push(value);
					var symbol = {
						type : "simple-line", // autocasts as new SimpleLineSymbol()
						color : "black",
						width : "2px",
						style : "solid"
					};
					var districtGraphic = new Graphic(value.geometry, symbol);
					view.graphics.add(districtGraphic, 0);
					// view.goTo(zF);
					geomextent = value.geometry.extent;
					ringgeom = value.geometry.rings;
					areageom = value.geometry;

				}));

			});

		},

		clearbutton : function() {

			view.graphics.removeAll();
			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.add(noncropmask);
			map.remove(this.featureLayer);
			map.add(featureLayer);
			document.getElementById("division").value = "";
			document.getElementById("district").value = "";
			document.getElementById("taluka").value = " ";
			// document.getElementById("circle").value = " ";
			document.getElementById("cropSelect").value = " ";
			document.getElementById("seasonSelect").value = "";
			document.getElementById("year").value = " ";
			// dom.byId("viewDiv").style.height = '95%';
			// dom.byId("floatingmenu").style.display = 'none';
			dom.byId("print").style.display = 'none';
			dom.byId("legend").style.display = 'none';
			dom.byId("legend1").style.display = 'none';
		},
		submitbtn : function() {

			dom.byId("divLoadingIndicator").style.display = 'block';

			dom.byId("tablinks").classList.add("active");
			// dom.byId("tablinks1").classList.remove("active");
			// dom.byId("tablinks2").classList.remove("active");

			div = document.getElementById("division").value;
			distname = document.getElementById("district").value;
			talname = document.getElementById("taluka").value;
			// cirname = document.getElementById("circle").value;
			cropnaame = document.getElementById("cropSelect").value;
			seasonName = document.getElementById("seasonSelect").value;
			cropyear = document.getElementById("year").value;
			dom.byId("print").style.display = 'block';

			for (var i = 0; i < zoneGetcropchange.length; i++) {
				if (zoneGetcropchange[i].name === div) {
					divisionCode = zoneGetcropchange[i].code;
				}
			}

			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					districtCode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talukaCode = zoneGetdistchange[i].code;
				}
			}

			if (document.getElementById("district").value === "") {
				distname = "All";
			}
			if (document.getElementById("taluka").value === "") {
				talname = "All";
			}

			if (cropyear === "" || seasonName === "" || cropnaame === "" || div === "") {
				swal("Please select proper input");
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});
				map.basemap = "topo";
				view.graphics.removeAll();
				dom.byId("print").style.display = 'none';
				map.add(featureLayer);
				map.add(noncropmask);
				dom.byId("divLoadingIndicator").style.display = 'none';
			} else {
				// dom.byId("temp").style.marginBottom = '0px';
				// dom.byId("cropSownCharts").style.display = 'block';
				dom.byId("mainContent").style.display = 'none';
				dom.byId("legend1").style.display = 'block';
				dom.byId("legend").style.display = 'block';
				document.getElementById("print").style.display = 'block';
				// map.basemap = "";
				map.removeAll(featureLayer);
				view.goTo(zF);
				currentTab = "cropsown";
				this.getLegendMenu();

				// ----------------------Raster Layer display with geometry----------------------

				this.featureLayer = new FeatureLayer(this.yield, {
					mode : FeatureLayer.MODE_SNAPSHOT,
					outFields : ["*"],
				});
				if (div == 'All' && distname == 'All' && talname == 'All') {
					this.featureLayer.definitionExpression = "1=1";
				} else if (div != 'All' && distname == 'All' && talname == 'All') {
					this.featureLayer.definitionExpression = "ADVNCODE ='" + divisionCode + "'";
				} else if (div != 'All' && distname !== 'All' && talname == 'All') {
					this.featureLayer.definitionExpression = "ADVNCODE ='" + divisionCode + "' and DTNCODE ='" + districtCode + "' ";
				} else if (div != 'All' && distname != 'All' && talname !== 'All') {
					this.featureLayer.definitionExpression = "ADVNCODE ='" + divisionCode + "' and DTNCODE ='" + districtCode + "' and  THNCODE = '" + talukaCode + "'  ";
				}

				console.log(this.featureLayer.definitionExpression);

				map.add(this.featureLayer);
				dom.byId("divLoadingIndicator").style.display = 'none';

				// this.getLegend();
				// this.getBarGraph();
				// this.getpieChartAgri();

			}
		},

		generatemap : function() {
			debugger;
			dom.byId("divLoadingIndicator").style.display = 'block';

			div = document.getElementById("division").value;
			distname = document.getElementById("district").value;
			talname = document.getElementById("taluka").value;
			cropnaame = document.getElementById("cropSelect").value;
			seasonName = document.getElementById("seasonSelect").value;
			cropyear = document.getElementById("year").value;

			for (var i = 0; i < zoneGetcropchange.length; i++) {
				if (zoneGetcropchange[i].name === div) {
					divisionCode = zoneGetcropchange[i].code;
				}
			}

			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					districtCode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talukaCode = zoneGetdistchange[i].code;
				}
			}

			if (document.getElementById("district").value === "") {
				distname = "All";
			}
			if (document.getElementById("taluka").value === "") {
				talname = "All";
			}

			var gpUrl = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/cropyeild/GPServer/cropyeild";
			var gp = new Geoprocessor(gpUrl);
			var parameters = {
				"division" : div,
				"district" : distname,
				"taluka" : talname,
				"div_cd" : divisionCode,
				"dist_cd" : districtCode,
				"tal_cd" : talukaCode
			};

			// console.log(parameters);
			gp.execute(parameters).then(ShowResultData);

			function ShowResultData(result) {
				// alert(result);
				// console.log(result.results[0].value);
				var resultImg = result.results[0].value.url;
				var center_left = (screen.width / 2.5) - (400 / 2);
				var center_top = (screen.height / 2.5) - (400 / 2);
				window.open(resultImg, target = '_blank', 'width=1000,height=750, top=' + center_top + ', left=' + center_left);
				dom.byId("divLoadingIndicator").style.display = 'none';
			}

		},

		ViewReport : function() {
			debugger;

			div = document.getElementById("division").value;
			distname = document.getElementById("district").value;
			talname = document.getElementById("taluka").value;
			cropnaame = document.getElementById("cropSelect").value;
			seasonName = document.getElementById("seasonSelect").value;
			cropyear = document.getElementById("year").value;

			console.log(div);

			if (cropyear === "" || seasonName === "" || div === "") {
				swal("Please select proper input");
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});
				map.basemap = "topo";
				view.graphics.removeAll();
				dom.byId("print").style.display = 'none';
				map.add(featureLayer);
				map.add(noncropmask);
				dom.byId("divLoadingIndicator").style.display = 'none';
			} else {

				for (var i = 0; i < zoneGetcropchange.length; i++) {
					if (zoneGetcropchange[i].name === div) {
						divisionCode = zoneGetcropchange[i].code;
					}
				}

				for (var i = 0; i < zoneGetdivchange.length; i++) {
					if (zoneGetdivchange[i].name === distname) {
						districtCode = zoneGetdivchange[i].code;
					}
				}
				for (var i = 0; i < zoneGetdistchange.length; i++) {
					if (zoneGetdistchange[i].name === talname) {
						talukaCode = zoneGetdistchange[i].code;
					}
				}

				if (document.getElementById("division").value === "") {
					div = "All";
					divisionCode = "All";
				}

				if (document.getElementById("district").value === "") {
					distname = "All";
					districtCode = "All";
				}
				if (document.getElementById("taluka").value === "") {
					talname = "All";
					talukaCode = "All";
				}

				document.getElementById("mainContent").style.display = "block";
				$("#mainContent").load("http://117.240.213.118:6080/cropacreagereport1/yieldstataverage?division=" + divisionCode + "&circle=All&district=" + districtCode + "&taluka=" + talukaCode + "&division_n=" + div + "&district_n=" + distname + "&circle_n=All&taluka_n=" + talname, function() {
					// document.getElementById("lblDivisionID").innerHTML = div;
					//alert("Load was performed.");
					$('#datatable').DataTable();

				});

			}

		},
	});
});
