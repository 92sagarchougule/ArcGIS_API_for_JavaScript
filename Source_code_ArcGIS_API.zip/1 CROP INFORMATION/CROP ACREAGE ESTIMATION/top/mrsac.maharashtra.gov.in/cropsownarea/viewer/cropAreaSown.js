/**
 * @author Shahana.Sheikh
 */
define(["dojo/_base/declare", "dijit/registry", "dijit/_WidgetBase", "dijit/_TemplatedMixin", "dojo/text!./templates/cropAreaSown.html", "dojo/_base/window", "dijit/_WidgetsInTemplateMixin", "dijit/layout/AccordionContainer", "esri/Map", "esri/views/MapView", "esri/widgets/Expand", "esri/layers/KMLLayer", "esri/geometry/geometryEngine", "esri/layers/Layer", "esri/WebMap", "esri/widgets/Search", "esri/Basemap", "esri/widgets/Locate", "esri/widgets/Track", "esri/Graphic", "esri/widgets/Compass", "esri/layers/MapImageLayer", "esri/widgets/CoordinateConversion", "esri/tasks/Geoprocessor", "dijit/Tooltip", "esri/tasks/support/RelationshipQuery", "esri/tasks/Locator", "esri/widgets/Home", "esri/widgets/BasemapToggle", "esri/widgets/Swipe", "esri/widgets/ScaleBar", "esri/geometry/Extent", "dojo/_base/lang", "dojo/topic", "esri/config", "esri/identity/ServerInfo", "esri/identity/IdentityManager", "esri/layers/FeatureLayer", "esri/tasks/support/FeatureSet", "esri/layers/ImageryLayer", "esri/layers/MapImageLayer", "esri/tasks/ClosestFacilityTask", "esri/tasks/support/ClosestFacilityParameters", "dojo/_base/array", "dojo/on", "dojo/dom", "dojo/dom-construct", "dojo/dom-style", "dojo/dom-attr", "dojo/dom-class", "esri/symbols/PictureMarkerSymbol", "esri/renderers/SimpleRenderer", "esri/symbols/SimpleMarkerSymbol", "esri/Graphic", "esri/widgets/Popup", "esri/PopupTemplate", "dijit/TooltipDialog", "esri/core/lang", "esri/tasks/QueryTask", "esri/tasks/support/Query", "dojo/query", "dojo/store/Memory", "dijit/form/ComboBox", "dijit/form/DateTextBox", "dojo/data/ItemFileReadStore", "dijit/form/Select", "dijit/form/FilteringSelect", "esri/layers/GraphicsLayer", "esri/widgets/Sketch", "esri/geometry/Point", "esri/geometry/Circle", "esri/geometry/SpatialReference", "esri/symbols/SimpleLineSymbol", "esri/symbols/SimpleFillSymbol", "esri/Color", "esri/Graphic", "esri/request", "dojo/dom-style", "esri/widgets/Legend", "esri/widgets/Print", "esri/tasks/FindTask", "dojo/request/xhr", 'dojo/data/ObjectStore', "dojo/request", "dojo/number", "dijit/layout/BorderContainer", "dijit/layout/TabContainer", "dijit/layout/ContentPane", "dijit/TitlePane", "dijit/form/Form", "esri/widgets/BasemapGallery", "dijit/form/TextBox", "dijit/Dialog", "dijit/form/CheckBox", "dijit/form/RadioButton", "dijit/Menu", "esri/layers/ImageryLayer", "esri/layers/support/RasterFunction", "esri/layers/support/DimensionalDefinition", "esri/layers/support/MosaicRule", "dijit/MenuItem", "dijit/layout/ContentPane", "dijit/Toolbar", "dijit/form/Button", "dojox/widget/TitleGroup", "esri/core/urlUtils", "dojo/_base/json", "dojo/domReady!"], function(declare, registry, _WidgetBase, _TemplatedMixin, template, win, _WidgetsInTemplateMixin, AccordionContainer, Map, MapView, Expand, KMLLayer, geometryEngine, Layer, WebMap, Search, Basemap, Locate, Track, Graphic, Compass, MapImageLayer, CoordinateConversion, Geoprocessor, Tooltip, RelationshipQuery, Locator, Home, BasemapToggle, Swipe, ScaleBar, Extent, lang, topic, esriConfig, ServerInfo, esriId, FeatureLayer, FeatureSet, ImageryLayer, MapImageLayer, ClosestFacilityTask, ClosestFacilityParameters, array, on, dom, domConstruct, domStyle, domAttr, domClass, PictureMarkerSymbol, SimpleRenderer, SimpleMarkerSymbol, Graphic, Popup, PopupTemplate, TooltipDialog, esriLang, QueryTask, Query, query, Memory, ComboBox, DateTextBox, ItemFileReadStore, FilteringSelect, Select, GraphicsLayer, Sketch, Point, Circle, SpatialReference, SimpleLineSymbol, SimpleFillSymbol, Color, Graphic, esriRequest, domStyle, Legend, Print, FindTask, xhr, ObjectStore, request, number, BorderContainer, TabContainer, ContentPane, TitlePane, Form, BasemapGallery, TextBox, Dialog, CheckBox, RadioButton, Menu, ImageryLayer, RasterFunction, DimensionalDefinition, MosaicRule, urlUtils, MenuItem, json) {
	return declare("mrsac.viewer.cropAreaSown", [_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {

		constructor : function() {
			valueKharif = [];
			valuesRabi = [];
			valuesOthers = [];
			zoneGetcropchange = [];
			zoneGetdivchange = [];
			zoneGetdistchange = [];
			zoneGettalchange = [];

			//-----------Kharif total sown---------
			zFKhdivchange = [];
			zFKhdistchange = [];
			agriArrayPrint = [];
			zF = [];
			tableIterationFlag = true;
			dataTableObj = null;
			tableIterationFlag2 = true;
			dataTableObj2 = null;

			totcirareacount = 0;
			totcountarearound = 0;
			graphTitle = "";
			finalData = [];

		},
		currentTab : "cropsown",
		agriarea : null,
		ringgeom : null,
		queryZm : null,
		contextMenu : null,
		queryUsedFurther : null,
		remapRFnoncrp : null,
		resultAgriLandUseArea : null,
		templateString : template,
		postMixInProperties : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				alert("err" + err);
				console.error(err);
			}
		},
		postCreate : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				console.error(err);
			}
		},
		startup : function() {
			if (this._started) {

				return;
			}
			try {
				//debugger;
				featureLayer = new MapImageLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
					outFields : ["*"],
					mode : FeatureLayer.MODE_ONDEMAND,
				});
				map.add(featureLayer);

				var selectsea = document.getElementById("seasonSelect");
				while (selectsea.firstChild) {
					selectsea.removeChild(selectsea.firstChild);
				}

				var legend = new Legend({
					view : view
				});

				var zone = ['Kharif', 'Rabi'];
				zone.sort();
				zone.reverse();
				var testValsn = {};

				array.forEach(zone, lang.hitch(this, function(vals) {

					if (vals) {
						if (!testValsn[vals]) {
							testValsn[vals] = true;

							var option = document.createElement('option');
							option.text = option.value = vals;
							selectsea.add(option, 0);
						}
					}
				}));

				document.getElementById("seasonSelect").value = "";

				noncropmask = new ImageryLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/noncropmask_2019/ImageServer",
					opacity : 0.3,
					id : "noncropmaskId"
				});
				map.add(noncropmask);

				//--------services  used-------------
				this.state = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/0";
				this.division = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/1";
				this.district = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/2";
				this.taluka = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/3";

				//-----------------------------new service----------------------------
				this.cropYearSown = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/acerage_statistics/MapServer/4";

				//-----------------year_master---------------

				var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/acerage_statistics/MapServer?f=pjson";
				" /MapServer?f=pjson";
				esriRequest(url, {
					responseType : "json"
				}).then(function(response) {
					// The requested data
					var geoJson = response.data;
					var layersArray = geoJson.tables;
					array.forEach(layersArray, lang.hitch(this, function(LayerAll) {
						if (LayerAll.name == "year_master") {
							idDistLyr = LayerAll.id;
							this.cropYearSown = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/acerage_statistics/MapServer/" + idDistLyr;
						}
					}));
				});

				this.kharifjson18_19 = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/KH_201819_cropwise/ImageServer/rasterAttributeTable?f=pjson";
				this.kharifjson19_20 = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/KH_201920_cropwise/ImageServer/rasterAttributeTable?f=pjson";
				this.kharifjson20_21 = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/KH_202021_cropwise/ImageServer/rasterAttributeTable?f=pjson";
				//this.kharifjson21_22 = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/KH_202122_cropwise/ImageServer/rasterAttributeTable?f=pjson";

				this.rabijson18_19 = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/RB_201819_cropwise/ImageServer/rasterAttributeTable?f=pjson";
				this.rabijson19_20 = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/RB_201920_cropwise/ImageServer/rasterAttributeTable?f=pjson";

				 this.kharifstats = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/acerage_statistics/MapServer/1";
				 this.rabistats = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/acerage_statistics/MapServer/2";
				
				//-----------------kharif_master---------------

				var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/acerage_statistics/MapServer?f=pjson";
				" /MapServer?f=pjson";
				esriRequest(url, {
					responseType : "json"
				}).then(function(response) {
					// The requested data
					var geoJson = response.data;
					var layersArray = geoJson.tables;
					array.forEach(layersArray, lang.hitch(this, function(LayerAll) {
						if (LayerAll.name == "kh_cropwise") {
							idDistLyr = LayerAll.id;
							this.kharifstats = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/acerage_statistics/MapServer/" + idDistLyr;
						}
					}));
				});
				
				//-----------------rabi_master---------------

				var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/acerage_statistics/MapServer?f=pjson";
				" /MapServer?f=pjson";
				esriRequest(url, {
					responseType : "json"
				}).then(function(response) {
					// The requested data
					var geoJson = response.data;
					var layersArray = geoJson.tables;
					array.forEach(layersArray, lang.hitch(this, function(LayerAll) {
						if (LayerAll.name == "rb_cropwise") {
							idDistLyr = LayerAll.id;
							this.rabistats = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/acerage_statistics/MapServer/" + idDistLyr;
						}
					}));
				});

				this.getSownYear();

			} catch (err) {
				console.error("SearchWidget::startup", err);

			}

		},

		getLegendMenu : function() {

			yearLeg = document.getElementById("year").value;
			cropsLeg = document.getElementById("cropSelect").value;
			seasonLeg = document.getElementById("seasonSelect").value;

			//------------Bind json crop wise------------
			if ( currentTab = "cropsown") {

			}
		},

		getSownYear : function() {
			//debugger;
			document.getElementById("seasonSelect").value = "";
			var zone = [];
			var testVals = {};
			selectYear = document.getElementById("year");

			queryTaskYearSown = new QueryTask(this.cropYearSown);
			var queryYear = new Query();
			queryYear.outFields = ["year"];
			queryYear.returnGeometry = false;
			queryYear.returnDistinctValues = true;
			queryYear.where = "1=1";

			queryTaskYearSown.execute(queryYear).then(function(featureset) {

				var result = featureset.features;

				array.forEach(result, lang.hitch(this, function(value) {

					crpyear = value.attributes.year;

					if (crpyear) {
						if (!testVals[crpyear]) {
							testVals[crpyear] = true;
							zone.push(crpyear);
						}
					}
				}));

				zone.sort();
				// zone.reverse();

				testValsn = {};

				array.forEach(zone, lang.hitch(this, function(vals) {
					if (vals) {
						if (!testValsn[vals]) {
							testValsn[vals] = true;

							var option = document.createElement('option');
							option.text = option.value = vals;
							selectYear.add(option, 0);
						}
					}
				}));
				document.getElementById("year").value = "";

			});
		},
		getYearChange : function() {
			document.getElementById("seasonSelect").value = " ";
			// document.getElementById("cropSelect").value = " ";
			document.getElementById("division").value = " ";
			document.getElementById("district").value = " ";
			document.getElementById("taluka").value = " ";
			document.getElementById("circle").value = " ";
			//------------------------
			// dom.byId("Stat").style.display = 'none';
			cropSapLayer = map.findLayerById("cropsapGraphichId");
			if (cropSapLayer) {
				map.remove(cropSapLayer);
			}
			view.graphics.removeAll();

		},
		getSeasonChange : function() {
			debugger;
			document.getElementById("cropSelect").value = " ";
			document.getElementById("division").value = " ";
			document.getElementById("district").value = " ";
			document.getElementById("taluka").value = " ";
			document.getElementById("circle").value = " ";

			year = document.getElementById("year").value;
			seasonName = document.getElementById("seasonSelect").value;
			selectcrop = document.getElementById("cropSelect");
			selectseason = document.getElementById("seasonSelect");
			// dom.byId("Stat").style.display = 'none';
			valuesRabi = [];
			var testVals = {};
			valueKharif = [];
			var valuesOthers = [];

			if (seasonName === 'Kharif') {
				while (selectcrop.firstChild) {
					selectcrop.removeChild(selectcrop.firstChild);
				}

				if (year === '2018-19') {
					var url = this.kharifjson18_19;
				} else if (year === '2019-20') {
					var url = this.kharifjson19_20;
				} else if (year === '2020-21') {
					var url = this.kharifjson20_21;
				}else if (year === '2021-22') {
					var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/KH_202122_cropwise/ImageServer/rasterAttributeTable?f=pjson";
				}

				var CropAreaQueryTask = new QueryTask(url);
				var CropAreaQuery = new Query();
				CropAreaQuery.returnGeometry = true;
				CropAreaQuery.outFields = ["*"];
				CropAreaQuery.where = "1=1";
				CropAreaQuery.outSpatialReference = {
					"wkid" : 102100

				};

				CropAreaQueryTask.execute(CropAreaQuery).then(function(results) {
					var resultfeature = results.features;

					array.forEach(resultfeature, lang.hitch(function(feature2) {
						//console.log(feature2);
						zone = feature2.attributes.Class_Names;
						cropcode = feature2.attributes.CROP_CODE;
						if (zone) {
							if (!testVals[zone]) {
								testVals[zone] = true;
								valueKharif.push({
									name : zone,
									code : cropcode
								});
							}
						}

					}));

					valueKharif.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					valueKharif.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					valueKharif.push({
						name : "All",
						code : "All"
					});

					testValsn = {};

					array.forEach(valueKharif, lang.hitch(this, function(vals) {

						if (vals.name) {
							if (!testValsn[vals.name]) {
								testValsn[vals.name] = true;

								var option = document.createElement('option');
								option.text = option.value = vals.name;
								selectcrop.add(option, 0);

							}
						}
					}));
					document.getElementById("cropSelect").value = "";
				});

			} else if (seasonName === 'Rabi') {

				while (selectcrop.firstChild) {
					selectcrop.removeChild(selectcrop.firstChild);
				}

				if (year === '2018-19') {
					var url = this.rabijson18_19;
				} else if (year === '2019-20') {
					var url = this.rabijson19_20;
				} else if (year === '2020-21') {
					var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/RB_202021_cropwise/ImageServer/rasterAttributeTable?f=pjson";
				}else if (year === '2021-22') {
					var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/RB_202122_cropwise/ImageServer/rasterAttributeTable?f=pjson";
				}
				

				var CropAreaQueryTask = new QueryTask(url);
				//==========MIDC_Info Table
				var CropAreaQuery = new Query();
				CropAreaQuery.returnGeometry = true;
				CropAreaQuery.outFields = ["*"];
				CropAreaQuery.where = "1=1";
				CropAreaQuery.outSpatialReference = {
					"wkid" : 102100

				};

				CropAreaQueryTask.execute(CropAreaQuery).then(function(results) {
					var resultfeature = results.features;
					array.forEach(resultfeature, lang.hitch(function(feature2) {

						zone = feature2.attributes.Class_Names;
						cropcode = feature2.attributes.CROP_CODE;
						if (zone) {
							if (!testVals[zone]) {
								testVals[zone] = true;
								valuesRabi.push({
									name : zone,
									code : cropcode
								});
							}
						}

					}));

					valuesRabi.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					valuesRabi.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					valuesRabi.push({
						name : "All",
						code : "All"
					});

					testValsn = {};

					array.forEach(valuesRabi, lang.hitch(this, function(vals) {

						if (vals.name) {
							if (!testValsn[vals.name]) {
								testValsn[vals.name] = true;

								var option = document.createElement('option');
								option.text = option.value = vals.name;
								selectcrop.add(option, 0);

							}
						}
					}));
					document.getElementById("cropSelect").value = "";
				});

			}
		},
		cropchange : function() {
			//debugger;
			//******************Division Populate*****************
			cropyear = document.getElementById("year").value;
			cropname = document.getElementById("cropSelect").value;
			seasonName = document.getElementById("seasonSelect").value;
			// alert(cropname);
			document.getElementById("district").value = " ";
			document.getElementById("taluka").value = " ";
			document.getElementById("circle").value = " ";
			// dom.byId("Stat").style.display = 'none';
			//===========Division Name in Setence Case================
			function upperCaseFirstLetter(string) {
				return string.charAt(0).toUpperCase() + string.slice(1);
			}

			function lowerCaseAllWordsExceptFirstLetters(string) {
				return string.replace(/\w\S*/g, function(word) {
					return word.charAt(0) + word.slice(1).toLowerCase();
				});
			}

			if (seasonName === 'Kharif') {
				for (var i = 0; i < valueKharif.length; i++) {
					if (valueKharif[i].name === cropname) {
						cropCode = valueKharif[i].code;
					}
				}
			}

			if (seasonName === 'Rabi') {
				for (var i = 0; i < valuesRabi.length; i++) {
					if (valuesRabi[i].name === cropname) {
						cropCode = valuesRabi[i].code;
					}
				}
			}

			zoneGetcropchange = [];
			var values = [];
			var testVals = {};

			selectDiv = document.getElementById("division");
			if (seasonName === 'Kharif') {
				while (selectDiv.firstChild) {
					selectDiv.removeChild(selectDiv.firstChild);
				}
				queryTaskdiv = new QueryTask(this.kharifstats);
			} else if (seasonName === 'Rabi') {
				while (selectDiv.firstChild) {
					selectDiv.removeChild(selectDiv.firstChild);
				}

				queryTaskdiv = new QueryTask(this.rabistats);

			}
			var query = new Query();
			query.outFields = ["advename", "advncode"];
			query.returnGeometry = false;
			query.returnDistinctValues = true;
			if (cropname === "All") {
				query.where = "crop_year = '" + cropyear + "' and crop_code <> ''";
			} else {
				query.where = "crop_year = '" + cropyear + "' and crop_code = '" + cropCode + "'";
			}
			console.log(query.where);
			queryTaskdiv.execute(query).then(function(featureset) {

				var result = featureset.features;
				array.forEach(result, lang.hitch(this, function(value) {

					div_name = value.attributes.advename;
					div_code = value.attributes.advncode;
					//division_name = upperCaseFirstLetter(lowerCaseAllWordsExceptFirstLetters(div_name));
					if (div_name) {
						if (!testVals[div_name]) {
							testVals[div_name] = true;
							zoneGetcropchange.push({
								name : div_name,
								code : div_code
							});
						}
					}
				}));
				if (zoneGetcropchange.length == 0) {
					swal("Data not available");
				} else {
					zoneGetcropchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetcropchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetcropchange.push({
						name : "All",
						code : "All"
					});

					testValsn = {};

					array.forEach(zoneGetcropchange, lang.hitch(this, function(vals) {

						if (vals.name) {
							if (!testValsn[vals.name]) {
								testValsn[vals.name] = true;

								var option = document.createElement('option');
								option.text = option.value = vals.name;
								selectDiv.add(option, 0);
							}
						}
					}));
					document.getElementById("division").value = "";
				}

			});

		},
		getdivchange : function() {
			debugger;
			//******************District Populate*****************
			cropyear = document.getElementById("year").value;
			cropname = document.getElementById("cropSelect").value;
			divi = document.getElementById("division").value;

			document.getElementById("district").value = " ";
			document.getElementById("taluka").value = " ";
			document.getElementById("circle").value = " ";
			// dom.byId("Stat").style.display = 'none';
			//dvename = divi.toUpperCase();

			for (var i = 0; i < valueKharif.length; i++) {
				if (valueKharif[i].name === cropname) {
					cropCode = valueKharif[i].code;
				}
			}
			function upperCaseFirstLetter(string) {
				return string.charAt(0).toUpperCase() + string.slice(1);
			}

			function lowerCaseAllWordsExceptFirstLetters(string) {
				return string.replace(/\w\S*/g, function(word) {
					return word.charAt(0) + word.slice(1).toLowerCase();
				});
			}

			dvename = upperCaseFirstLetter(lowerCaseAllWordsExceptFirstLetters(divi));
			zoneGetdivchange = [];
			view.graphics.removeAll();
			var values = [];
			var testVals = {};

			if (divi == "All") {
				var queryTaskZm = new QueryTask({
					url : this.state
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "STENAME = 'Maharashtra'";

				stateLayer = new FeatureLayer({
					url : this.state,
					id : "stateLayerDisplay"
				});
				stateLayer.definitionExpression = queryZm.where;
				map.add(stateLayer);

			} else if (divi != "All") {
				var queryTaskZm = new QueryTask({
					url : this.division
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "ADVENAME  = '" + dvename + "'";
				divisionLayer = new FeatureLayer({
					url : this.division,
					id : "diviLayerDisplay"
				});
				divisionLayer.definitionExpression = queryZm.where;
				map.add(divisionLayer);

			}
			// console.log(queryZm.where);

			queryTaskZm.execute(queryZm).then(function(results) {
				// console.log(results);
				var result_features = results.features;
				// console.log(result_features);
				array.forEach(result_features, lang.hitch(this, function(value) {

					bufgeometry = value.geometry;
					// console.log(value);
					zF.push(value);

					var symbol = {
						type : "simple-line",
						color : "black",
						width : "2px",
						style : "solid"
					};
					var districtGraphic = new Graphic(value.geometry, symbol);
					view.graphics.add(districtGraphic, 0);
					ringgeom = value.geometry.rings;

				}));

			});

			selectDist = document.getElementById("district");
			if (seasonName === 'Kharif') {
				while (selectDist.firstChild) {
					selectDist.removeChild(selectDist.firstChild);
				}
				queryTaskdist = new QueryTask(this.kharifstats);
			} else if (seasonName === 'Rabi') {
				while (selectDist.firstChild) {
					selectDist.removeChild(selectDist.firstChild);
				}
				queryTaskdist = new QueryTask(this.rabistats);

			}

			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["dtename", "dtncode"];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.returnDistinctValues = true;
			if (cropname == "All" && divi == "All") {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename <> '' ";
			} else if (cropname == "All" && divi != "All") {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename = '" + divi + "'";
			} else if (cropname != "All" && divi == "All") {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code = '" + cropCode + "' and advename <> ''";
			} else if (cropname != "All" && divi != "All") {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code = '" + cropCode + "' and advename = '" + divi + "' ";
			}
			// console.log(queryUsedFurther.where);
			queryTaskdist.execute(queryUsedFurther).then(function(featureset) {

				var result = featureset.features;
				if (divi != "All") {
					array.forEach(result, lang.hitch(this, function(value) {
						dis_name = value.attributes.dtename;
						dist_code = value.attributes.dtncode;
						if (dis_name) {
							if (!testVals[dis_name]) {
								testVals[dis_name] = true;
								zoneGetdivchange.push({
									name : dis_name,
									code : dist_code,
								});
							};
						}
					}));

					zoneGetdivchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});

					zoneGetdivchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdivchange.push({
						name : "All",
						code : "All"
					});
				} else if (divi == "All") {
					zoneGetdivchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});

					zoneGetdivchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdivchange.push({
						name : "All",
						code : "All"
					});
				}

				testValsn = {};

				array.forEach(zoneGetdivchange, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectDist.add(option, 0);
						}
					}
				}));
				document.getElementById("district").value = "";
			});
			// map.basemap = "";
		},
		getdistchange : function() {
			distname = document.getElementById("district").value;
			talname = document.getElementById("taluka").value;
			cropyear = document.getElementById("year").value;
			divi = document.getElementById("division").value;
			cropname = document.getElementById("cropSelect").value;
			document.getElementById("taluka").value = " ";
			document.getElementById("circle").value = " ";
			//dvename = divi.toUpperCase();
			// dom.byId("Stat").style.display = 'none';
			for (var i = 0; i < valueKharif.length; i++) {
				if (valueKharif[i].name === cropname) {
					cropCode = valueKharif[i].code;
				}
			}

			//===========Division Name in Sentence Case================
			function upperCaseFirstLetter(string) {
				return string.charAt(0).toUpperCase() + string.slice(1);
			}

			function lowerCaseAllWordsExceptFirstLetters(string) {
				return string.replace(/\w\S*/g, function(word) {
					return word.charAt(0) + word.slice(1).toLowerCase();
				});
			}

			division = upperCaseFirstLetter(lowerCaseAllWordsExceptFirstLetters(divi));
			//========================================================

			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					distrcitCode = zoneGetdivchange[i].code;
				}
			}
			view.graphics.removeAll();

			zoneGetdistchange = [];
			var testVals = {};
			zF = [];
			var district_LayerUrlZm = this.district;
			if ((division == "All" && distname == "All" && talname == "") || (division == "All" && distname == "" && talname == "")) {
				var queryTaskZm = new QueryTask({
					url : this.state
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "STENAME = 'Maharashtra'";

				stateLayer = new FeatureLayer({
					url : this.state,
					id : "stateLayerDisplay"
				});
				stateLayer.definitionExpression = queryZm.where;
				map.add(stateLayer);

			} else if ((division == "All" && distname != "All") || (division != "All" && distname != "All")) {
				var queryTaskZm = new QueryTask({
					url : district_LayerUrlZm
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "'";

				//----------------------Get Crop Layers All-----------
				distLayer = new FeatureLayer({
					url : this.district,
					id : "distLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);

			} else if (division != "All" && distname == "All") {
				var queryTaskZm = new QueryTask({
					url : this.division
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "ADVENAME = '" + divi + "'";

				divisionLayer = new FeatureLayer({
					url : this.division,
					id : "diviLayerDisplay"
				});
				divisionLayer.definitionExpression = queryZm.where;
				map.add(divisionLayer);
			}
			// console.log(queryZm.where);
			queryTaskZm.execute(queryZm).then(function(results) {

				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {

					bufgeometry = value.geometry;
					zF.push(value);
					var symbol = {
						type : "simple-line", // autocasts as new SimpleLineSymbol()
						color : "black",
						width : "2px",
						style : "solid"
					};
					var districtGraphic = new Graphic(value.geometry, symbol);
					view.graphics.add(districtGraphic, 0);
					// view.goTo(zF);
					geomextent = value.geometry.extent;

					ringgeom = value.geometry.rings;
					areageom = value.geometry;
					// this.noncropMaskClip();
				}));

			});

			debugger;

			selecttal = document.getElementById("taluka");

			if (seasonName === 'Kharif') {
				while (selecttal.firstChild) {
					selecttal.removeChild(selecttal.firstChild);
				}
				queryTasktal = new QueryTask(this.kharifstats);
			} else if (seasonName === 'Rabi') {
				while (selecttal.firstChild) {
					selecttal.removeChild(selecttal.firstChild);
				}
				queryTasktal = new QueryTask(this.rabistats);

			}

			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["thename", "thncode"];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.outSpatialReference = {
				"wkid" : 102100
			};
			queryUsedFurther.returnDistinctValues = true;

			if (cropname == 'All' && divi == 'All' && distname == 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename <> '' ";
			} else if (cropname == 'All' && divi != 'All' && distname != 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename = '" + divi + "' and dtename = '" + distname + "' ";
			} else if (cropname == 'All' && divi != 'All' && distname == 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename = '" + divi + "' and dtename <> '' ";
			} else if (cropname != 'All' && divi == 'All' && distname == 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code = '" + cropCode + "' and advename <> '' ";
			} else if (cropname != 'All' && divi != 'All' && distname == 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code = '" + cropCode + "' and advename = '" + divi + "' and dtename <> '' ";
			} else if (cropname != 'All' && divi != 'All' && distname != 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code = '" + cropCode + "' and advename = '" + divi + "' and dtename = '" + distname + "' ";
			}
			// console.log(queryUsedFurther.where);
			queryTasktal.execute(queryUsedFurther).then(function(featureset) {

				var result = featureset.features;
				if (distname != "All") {
					array.forEach(result, lang.hitch(this, function(value) {

						tal_name = value.attributes.thename;
						tal_code = value.attributes.thncode;
						if (tal_name) {
							if (!testVals[tal_name]) {
								testVals[tal_name] = true;
								zoneGetdistchange.push({
									name : tal_name,
									code : tal_code
								});
							}
						}
					}));

					zoneGetdistchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.push({
						name : "All",
						code : "All"
					});
				} else if (distname == "All") {
					zoneGetdistchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.push({
						name : "All",
						code : "All"
					});
				}

				testValsn = {};

				array.forEach(zoneGetdistchange, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selecttal.add(option, 0);
						}
					}
				}));
				document.getElementById("taluka").value = "";

			});
			// map.basemap = "";

		},
		gettalchange : function() {
			divi = document.getElementById("division").value;
			distname = document.getElementById("district").value;
			talname = document.getElementById("taluka").value;
			cropyear = document.getElementById("year").value;
			cropname = document.getElementById("cropSelect").value;
			document.getElementById("circle").value = " ";
			//divname = divi.toUpperCase();
			// dom.byId("Stat").style.display = 'none';
			var values = [];
			zoneGettalchange = [];
			var testVals = {};
			zF = [];
			view.graphics.removeAll();

			for (var i = 0; i < valueKharif.length; i++) {
				if (valueKharif[i].name === cropname) {
					cropCode = valueKharif[i].code;
				}
			}
			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					distrcitCode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talukaCode = zoneGetdistchange[i].code;
				}
			}

			// console.log(distrcitCode);

			if (divi == "All" && distname == "All" && talname == "All") {
				var queryTaskZm = new QueryTask({
					url : this.state
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "STENAME = 'Maharashtra'";
				stateLayer = new FeatureLayer({
					url : this.state,
					id : "stateLayerDisplay"
				});
				stateLayer.definitionExpression = queryZm.where;
				map.add(stateLayer);
			} else if ((divi != "All" && distname == "All" && talname == "All")) {
				var queryTaskZm = new QueryTask({
					url : this.division
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "ADVENAME = '" + divi + "'";
				distLayer = new FeatureLayer({
					url : this.district,
					id : "distalLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);

			} else if ((divi != "All" && distname != "All" && talname == "All")) {
				var district_LayerUrlZm = this.district;

				var queryTaskZm = new QueryTask({
					url : district_LayerUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "'";

				distLayer = new FeatureLayer({
					url : this.district,
					id : "distalLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);
			} else if ((divi != "All" && distname != "All" && talname != "All")) {
				var taluka_LayerUrlZm = this.taluka;
				var queryTaskZm = new QueryTask({
					url : taluka_LayerUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";

				talLayer = new FeatureLayer({
					url : this.taluka,
					id : "talLayerDisplay"
				});
				talLayer.definitionExpression = queryZm.where;
				map.add(talLayer);

			}
			// console.log(queryZm.where);
			queryTaskZm.execute(queryZm).then(function(results) {
				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {
					bufgeometry = value.geometry;
					zF.push(value);
					var symbol = {
						type : "simple-line", // autocasts as new SimpleLineSymbol()
						color : "black",
						width : "2px",
						style : "solid"
					};
					var districtGraphic = new Graphic(value.geometry, symbol);
					view.graphics.add(districtGraphic, 0);
					// view.goTo(zF);
					geomextent = value.geometry.extent;
					ringgeom = value.geometry.rings;
					areageom = value.geometry;

				}));

			});

			// this.pixelfilter()

			//-----------------------circle poppulate----------------------
			selectcir = document.getElementById("circle");

			if (seasonName === 'Kharif') {
				while (selectcir.firstChild) {
					selectcir.removeChild(selectcir.firstChild);
				}
				queryTaskcir = new QueryTask(this.kharifstats);
			} else if (seasonName === 'Rabi') {
				while (selectcir.firstChild) {
					selectcir.removeChild(selectcir.firstChild);
				}
				queryTaskcir = new QueryTask(this.rabistats);
			}

			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["cirname", "acreage_area ", "circode"];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.outSpatialReference = {
				"wkid" : 102100
			};
			queryUsedFurther.returnDistinctValues = true;

			if (cropname == 'All' && divi == 'All' && distname == 'All' && talname == 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename <> '' ";
			} else if (cropname == 'All' && divi != 'All' && distname == 'All' && talname == 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename ='" + divi + "' ";
			} else if (cropname == 'All' && divi != 'All' && distname != 'All' && talname == 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename ='" + divi + "' and dtename = '" + distname + "'";
			} else if (cropname == 'All' && divi != 'All' && distname != 'All' && talname != 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename ='" + divi + "' and dtename = '" + distname + "' and  thename ='" + talname + "' ";
			} else if (cropname != 'All' && divi == 'All' && distname == 'All' && talname == 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code ='" + cropCode + "' and advename <> ''";
			} else if (cropname != 'All' && divi != 'All' && distname == 'All' && talname == 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code ='" + cropCode + "' and advename ='" + divi + "' ";
			} else if (cropname != 'All' && divi != 'All' && distname != 'All' && talname == 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code ='" + cropCode + "' and advename ='" + divi + "' and dtename = '" + distname + "' ";
			} else if (cropname != 'All' && divi != 'All' && distname != 'All' && talname != 'All') {
				queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code ='" + cropCode + "' and advename ='" + divi + "' and dtename = '" + distname + "' and  thename ='" + talname + "' ";
			}
			// console.log(queryUsedFurther.where);
			queryTaskcir.execute(queryUsedFurther).then(function(featureset) {

				var result = featureset.features;
				if (talname != "All") {
					array.forEach(result, lang.hitch(this, function(value) {
						// console.log(value);
						circle = value.attributes.cirname;
						circlecode = value.attributes.circode;
						areaha = value.attributes.acreage_area;
						if (circle) {
							if (!testVals[circle]) {
								testVals[circle] = true;
								zoneGettalchange.push({
									name : circle,
									code : circlecode,
									area : areaha
								});
							}
						}
					}));
					zoneGettalchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGettalchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGettalchange.push({
						name : "All",
						code : "All",
						area : "All"
					});
				} else if (talname == "All") {
					zoneGettalchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGettalchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGettalchange.push({
						name : "All",
						code : "All",
						area : "All"
					});
				}

				testValsn = {};
				array.forEach(zoneGettalchange, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectcir.add(option, 0);
						}
					}
				}));
				document.getElementById("circle").value = "";

			});
			// map.basemap = "";

		},
		circlechange : function() {

			var zone = [];
			var values = [];
			var testVals = {};

			zF = [];
			cirname = document.getElementById("circle").value;
			talname = document.getElementById("taluka").value;
			distname = document.getElementById("district").value;
			divi = document.getElementById("division").value;
			cropnaame = document.getElementById("cropSelect").value;
			cropyear = document.getElementById("year").value;
			//divname = divi.toUpperCase();
			// dom.byId("Stat").style.display = 'none';
			view.graphics.removeAll();

			for (var i = 0; i < valueKharif.length; i++) {
				if (valueKharif[i].name === cropnaame) {
					cropCode = valueKharif[i].code;
				}
			}
			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					districtCode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talukaCode = zoneGetdistchange[i].code;
				}
			}
			for (var i = 0; i < zoneGettalchange.length; i++) {
				if (zoneGettalchange[i].name === cirname) {
					circleCode = zoneGettalchange[i].code;
				}
			}
			if ((divi == "All") && (distname == "All") && (talname == "All") && (cirname == "All")) {
				// alert("");
				var queryTaskZm = new QueryTask({
					url : this.state
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "STENAME = 'Maharashtra'";

				stateLayer = new FeatureLayer({
					url : this.state,
					id : "stateLayerDisplay"
				});
				stateLayer.definitionExpression = queryZm.where;
				map.add(stateLayer);
			} else if ((divi != "All") && (distname == "All") && (talname == "All") && (cirname == "All")) {
				var queryTaskZm = new QueryTask({
					url : this.division
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "ADVENAME  = '" + divi + "'";
				divisionLayer = new FeatureLayer({
					url : this.division,
					id : "diviLayerDisplay"
				});
				divisionLayer.definitionExpression = queryZm.where;
				map.add(divisionLayer);

			} else if ((divi != "All") && (distname != "All") && (talname == "All") && (cirname == "All")) {
				var queryTaskZm = new QueryTask({
					url : this.district
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "'";

				//----------------------Get Crop Layers All-----------
				distLayer = new FeatureLayer({
					url : this.district,
					id : "distLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);

			} else if ((divi != "All") && (distname != "All") && (talname != "All") && (cirname == "All")) {

				var taluka_LayerUrlZm = this.taluka;
				var queryTaskZm = new QueryTask({
					url : taluka_LayerUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";

				talLayer = new FeatureLayer({
					url : this.taluka,
					id : "talLayerDisplay"
				});
				talLayer.definitionExpression = queryZm.where;
				map.add(talLayer);

			} else if ((divi != "All") && (distname != "All") && (talname != "All") && (cirname != "All")) {
				var circleUrlZm = "https://portal.mrsac.org.in/webadpgis8/rest/services/baselayers/circle_boundary/MapServer/0";
				var queryTaskZm = new QueryTask({
					url : circleUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "THNCODE = '" + talukaCode + "' and CIRNCODE  = '" + circleCode + "'";
				circleLayer = new FeatureLayer({
					url : circleUrlZm,
					id : "cirLayerDisplay"
				});
				circleLayer.definitionExpression = queryZm.where;
				map.add(circleLayer);
			}
			queryTaskZm.execute(queryZm).then(function(results) {
				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {
					bufgeometry = value.geometry;
					zF.push(value);
					var symbol = {
						type : "simple-line",
						color : "black",
						width : "2px",
						style : "solid"
					};
					slected_circle = zF[0].attributes.OBJECTID;
					var graphic = new Graphic(value.geometry, symbol);
					view.graphics.add(graphic, 0);
					// view.goTo(zF);
					geomextent = value.geometry.extent;

					ringgeom = value.geometry.rings;
					areageom = value.geometry;

				}));
			});

			// console.log(queryZm.where);

			//-------For Query--------
			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["*"];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.outSpatialReference = {
				"wkid" : 102100
			};
			queryUsedFurther.returnDistinctValues = true;
			if (cropnaame === "All") {
				if (divi == 'All' && distname == 'All' && talname == 'All' && cirname == 'All') {
					queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename <> '' ";
				} else if (divi != 'All' && distname == 'All' && talname == 'All' && cirname == 'All') {
					queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename ='" + divi + "' ";
				} else if (divi != 'All' && distname != 'All' && talname == 'All' && cirname == 'All') {
					queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename ='" + divi + "' and dtename ='" + distname + "' ";
				} else if (divi != 'All' && distname != 'All' && talname != 'All' && cirname == 'All') {
					queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename ='" + divi + "' and dtename ='" + distname + "' and  thename = '" + talname + "' ";
				} else if (divi != 'All' && distname != 'All' && talname != 'All' && cirname != 'All') {
					queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code <> '' and advename ='" + divi + "' and dtename ='" + distname + "' and  thename = '" + talname + "' and  cirname = '" + cirname + "' ";
				}
			} else if (cropnaame != 'All') {
				if (divi == 'All' && distname == 'All' && talname == 'All' && cirname == 'All') {
					queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code ='" + cropCode + "' and advename <> '' ";
				} else if (divi != 'All' && distname == 'All' && talname == 'All' && cirname == 'All') {
					queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code ='" + cropCode + "' and advename ='" + divi + "' ";
				} else if (divi != 'All' && distname != 'All' && talname == 'All' && cirname == 'All') {
					queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code ='" + cropCode + "' and advename ='" + divi + "' and dtename ='" + distname + "' ";
				} else if (divi != 'All' && distname != 'All' && talname != 'All' && cirname == 'All') {
					queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code ='" + cropCode + "' and advename ='" + divi + "' and dtename ='" + distname + "' and  thename = '" + talname + "' ";
				} else if (divi != 'All' && distname != 'All' && talname != 'All' && cirname != 'All') {
					queryUsedFurther.where = "crop_year = '" + cropyear + "' and crop_code ='" + cropCode + "' and advename ='" + divi + "' and dtename ='" + distname + "' and  thename = '" + talname + "' and  cirname = '" + cirname + "' ";
				}
			}

			// console.log(queryUsedFurther.where);
			queryTaskcir.execute(queryUsedFurther).then(function(featureset) {

				var result = featureset.features;

			});

		},
		clearbutton : function() {

			view.graphics.removeAll();
			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.remove(noncropmask);
			map.remove(layer);
			document.getElementById("division").value = "";
			document.getElementById("district").value = "";
			document.getElementById("taluka").value = " ";
			document.getElementById("circle").value = " ";
			map.removeAll(this.featureLayer);
			map.basemap = "topo";
			map.add(noncropmask);
			map.add(featureLayer);
			// document.getElementById("cropSelect").value = " ";
			document.getElementById("seasonSelect").value = "";
			document.getElementById("year").value = " ";
			// dom.byId("viewDiv").style.height = '95%';
			// dom.byId("floatingmenu").style.display = 'none';
			dom.byId("cropSownCharts").style.display = 'none';
			dom.byId("legend").style.display = 'none';
			dom.byId("legend1").style.display = 'none';
			dom.byId("mainContent").style.display = 'none';
		},
		submitbtn : function() {
			//alert();
			//debugger;
			dom.byId("divLoadingIndicator").style.display = 'block';
			document.getElementById("mainContent").style.display = "none";
			dom.byId("tablinks").classList.add("active");
			// dom.byId("tablinks1").classList.remove("active");
			// dom.byId("tablinks2").classList.remove("active");
			debugger;
			divi = document.getElementById("division").value;
			distname = document.getElementById("district").value;
			talname = document.getElementById("taluka").value;
			cirname = document.getElementById("circle").value;
			cropnaame = document.getElementById("cropSelect").value;
			seasonName = document.getElementById("seasonSelect").value;
			cropyear = document.getElementById("year").value;
			// dom.byId("floatingmenu").style.type = 'active';

			// var myDiv = document.getElementById('floatingmenu');
			// myDiv.classList.add('floatingmenu');
			// myDiv.classList.toogle('myCustomActive');

			if (cropyear === "" || seasonName === "" || cropnaame === "" || divi === "") {
				swal("Please select proper input");
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});
				map.basemap = "topo";
				view.graphics.removeAll();
				dom.byId("print").style.display = 'none';
				map.add(featureLayer);
				map.add(noncropmask);
				dom.byId("divLoadingIndicator").style.display = 'none';
			} else {
				// dom.byId("temp").style.marginBottom = '0px';
				dom.byId("cropSownCharts").style.display = 'block';
				dom.byId("print").style.display = 'block';
				dom.byId("legend1").style.display = 'block';
				dom.byId("legend").style.display = 'block';
				// document.getElementById("printReport").style.display = 'block';
				// map.basemap = "";
				map.removeAll(featureLayer);
				view.goTo(zF);
				currentTab = "cropsown";
				this.getLegendMenu();

				for (var i = 0; i < zoneGetcropchange.length; i++) {
					if (zoneGetcropchange[i].name === divi) {
						dvncode = zoneGetcropchange[i].code;
					}
				}

				for (var i = 0; i < zoneGetdivchange.length; i++) {
					if (zoneGetdivchange[i].name === distname) {
						districtCode = zoneGetdivchange[i].code;
					}
				}
				for (var i = 0; i < zoneGetdistchange.length; i++) {
					if (zoneGetdistchange[i].name === talname) {
						talukaCode = zoneGetdistchange[i].code;
					}
				}
				for (var i = 0; i < zoneGettalchange.length; i++) {
					if (zoneGettalchange[i].name === cirname) {
						circleCode = zoneGettalchange[i].code;
					}
				}

				// ----------------------Raster Layer display with geometry----------------------

				// map.remove(featureLayer);
				if ( currentTab = "cropsown") {
					remapRF = new RasterFunction();
					remapRF.functionName = "Clip";
					remapRF.functionArguments = {
						"ClippingGeometry" : {
							"rings" : ringgeom,
							"ClippingType" : 1
						}
					};
					this.pixelfilter();
					//debugger;
					//map.add(layer);
					layer.renderingRule = remapRF;
					map.add(layer);
					// map.add(featureLayer);

					if (document.getElementById("district").value === "") {
						distname = "All";
					}
					if (document.getElementById("taluka").value === "") {
						talname = "All";
					}
					if (document.getElementById("circle").value === "") {
						cirname = "All";
					}

					//-------------------maha boundary------------
					if (divi == 'All' && distname == 'All' && talname == 'All' && cirname == 'All') {
						// alert();
						var bikeTrailsRenderer = {
							type : "simple",
							symbol : {
								type : "simple-line",
								color : "#666869",
								width : "1px"
							}
						};
						featureLayer = new MapImageLayer({
							url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
							renderer : bikeTrailsRenderer,
							outFields : ["*"],
							mode : FeatureLayer.MODE_ONDEMAND,
						});
						map.add(featureLayer);
					}

					//-------------------division boundary------------
					if (divi != 'All' && distname == 'All' && talname == 'All' && cirname == 'All') {
						// alert();
						var bikeTrailsRenderer = {
							type : "simple",
							symbol : {
								type : "simple-line",
								color : "#666869",
								width : "1px"
							}
						};
						this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/2", {
							mode : FeatureLayer.MODE_SNAPSHOT,
							outFields : ["*"],
							renderer : bikeTrailsRenderer,
						});

						this.featureLayer.definitionExpression = "ADVNCODE = '" + dvncode + "' and DTNCODE  <>''";

						map.add(this.featureLayer);
					}

					//-------------------district boundary------------
					if (divi != 'All' && distname != 'All' && talname == 'All' && cirname == 'All') {
						var bikeTrailsRenderer = {
							type : "simple",
							symbol : {
								type : "simple-line",
								color : "#666869",
								width : "1px"
							}
						};
						this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/3", {
							mode : FeatureLayer.MODE_SNAPSHOT,
							outFields : ["*"],
							renderer : bikeTrailsRenderer,
						});

						this.featureLayer.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE  <>''";

						map.add(this.featureLayer);
					}

					//-------------------taluka boundary------------
					if (divi != 'All' && distname != 'All' && talname != 'All' && cirname == 'All') {
						var bikeTrailsRenderer = {
							type : "simple",
							symbol : {
								type : "simple-line",
								color : "#666869",
								width : "1px"
							}
						};
						this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/baselayers/circle_boundary/MapServer/0", {
							mode : FeatureLayer.MODE_SNAPSHOT,
							outFields : ["*"],
							renderer : bikeTrailsRenderer,
						});

						this.featureLayer.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";

						map.add(this.featureLayer);
					}

					//-------------------village boundary------------
					if (divi != 'All' && distname != 'All' && talname != 'All' && cirname !== 'All') {
						var bikeTrailsRenderer = {
							type : "simple",
							symbol : {
								type : "simple-line",
								color : "#666869",
								width : "1px"
							}
						};
						this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/admin2011/admin_village_16/MapServer/0", {
							mode : FeatureLayer.MODE_SNAPSHOT,
							outFields : ["*"],
							renderer : bikeTrailsRenderer,
						});

						this.featureLayer.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "' and CRNCODE = '" + circleCode + "'";

						map.add(this.featureLayer);
						//alert("circle before imagery");
					}

					//----------------------Swipe Tool------------------------
					noncropmask = new ImageryLayer({
						url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/noncropmask_2019/ImageServer",
						opacity : 0.8
					});

					swipe.leadingLayers.add(layer);
					swipe.trailingLayers.add(noncropmask);
					// map.add(featureLayer);
					
					//alert("after imagery");

					featureLayer1 = new MapImageLayer({
						url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/basemap_cropacreage/MapServer",
						outFields : ["*"],
						mode : FeatureLayer.MODE_ONDEMAND,
					});
					map.add(featureLayer1);

					this.getLegend();
					this.getBarGraph();
					// this.getpieChartAgri();

				}
			}
		},
		noncropMaskClip : function() {
			remapRFnoncrp = new RasterFunction();
			remapRFnoncrp.functionName = "Clip";
			remapRFnoncrp.functionArguments = {
				"ClippingGeometry" : {
					"rings" : ringgeom,
					"ClippingType" : 1
				}
			};
			this.pixelfilterCrop();
			layerimage.renderingRule = remapRFnoncrp;
			map.add(layerimage);

		},
		pixelfilterCrop : function() {
			layerimage = new ImageryLayer({
				url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/noncropmask_2019/ImageServer",
				pixelFilter : colorizenoncrop,
				id : "imageLayerCrop",
				// opacity : 0.5

			});

			layerimage.when(function() {
				rasterAttributes = layerimage.rasterAttributeTable.features;
				fields = rasterAttributes.filter(function(item, i) {
					className = item.attributes.Class_Names;
					//console.log(className);
					return className === "Builtup" || className === "Forestland" || className === "Wasteland" || className === "Waterbodies";

				});
				debugger;
				console.log("---------------------------------------------------------------");
				console.log(fields);

			});
			function colorizenoncrop(pixelData) {

				if (pixelData === null || pixelData.pixelBlock === null || pixelData.pixelBlock.pixels === null) {
					return;
				}
				var pixelBlock = pixelData.pixelBlock;

				var pixels = pixelBlock.pixels;

				var band1 = pixels[0];

				var rBand = [];
				var gBand = [];
				var bBand = [];

				var mask = [];

				var numPixels = pixelBlock.width * pixelBlock.height;

				for (var i = 0; i < numPixels; i++) {
					var val = band1[i];

					if (val === fields[0].attributes.Value) {

						mask[i] = 1;
						rBand[i] = fields[0].attributes.Red;
						gBand[i] = fields[0].attributes.Green;
						bBand[i] = fields[0].attributes.Blue;

					} else if (val === fields[1].attributes.Value) {

						mask[i] = 2;
						rBand[i] = fields[1].attributes.Red;
						gBand[i] = fields[1].attributes.Green;
						bBand[i] = fields[1].attributes.Blue;

					} else if (val === fields[2].attributes.Value) {

						mask[i] = 3;
						rBand[i] = fields[2].attributes.Red;
						gBand[i] = fields[2].attributes.Green;
						bBand[i] = fields[2].attributes.Blue;

					} else if (val === fields[3].attributes.Value) {

						mask[i] = 4;
						rBand[i] = fields[3].attributes.Red;
						gBand[i] = fields[3].attributes.Green;
						bBand[i] = fields[3].attributes.Blue;

					} else {
						mask[i] = 0;
						rBand[i] = 0;
						gBand[i] = 0;
						bBand[i] = 0;
					}

					// }
				}

				pixelData.pixelBlock.pixels = [rBand, gBand, bBand];
				pixelData.pixelBlock.statistics = null;
				pixelData.pixelBlock.pixelType = "U8";

				pixelData.pixelBlock.mask = mask;
			}

		},
		pixelfilter : function() {
			distname = document.getElementById("district").value;
			talname = document.getElementById("taluka").value;
			cropnaame = document.getElementById("cropSelect").value;
			seasonName = document.getElementById("seasonSelect").value;
			cropyear = document.getElementById("year").value;

			departmentarray = [];

			if (cropnaame === "All") {
				if (seasonName == 'Kharif') {
					if (cropyear === "2018-19") {
						layer = new ImageryLayer({
							url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/KH_201819_cropwise/ImageServer",
							pixelFilter : colorize1,
							id : "imageLayer"
						});
						layer.when(function() {
							rasterAttributes = layer.rasterAttributeTable.features;
							
							console.log("raster attr features:---------------------------------------");
							console.log(rasterAttributes);

							fields = rasterAttributes.filter(function(item, i) {
								className = item.attributes.Class_Names;
								return className === 'Cotton+Tur';
							});
						});
					} else if (cropyear === "2019-20") {

						layer = new ImageryLayer({
							url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/KH_201920_cropwise/ImageServer",
							pixelFilter : colorize21,
							id : "imageLayer"

						});
						layer.when(function() {
							rasterAttributes = layer.rasterAttributeTable.features;
							fields = rasterAttributes.filter(function(item, i) {
								className = item.attributes.Class_Names;
								return className === 'Cotton+Tur' || className === 'Soybean+Short Duration Pulses' || className === 'Paddy' || className === 'Sugarcane' || className === 'Other Kharif Crops' || className === 'Soybean+Tur';
							});
						});
					} else if (cropyear === "2020-21") {

						layer = new ImageryLayer({
							url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/KH_202021_cropwise/ImageServer",
							pixelFilter : colorize2,
							id : "imageLayer"

						});
						layer.when(function() {
							rasterAttributes = layer.rasterAttributeTable.features;
							fields = rasterAttributes.filter(function(item, i) {
								className = item.attributes.Class_Names;
								return className === 'Maize+Bajra+Jowar' || className === 'Cotton+Tur' || className === 'Soybean+Short Duration Pulses' || className === 'Paddy' || className === 'Sugarcane' || className === 'Other Kharif Crops' || className === 'Soybean + Tur';
							});
						});
					}
					else if (cropyear === "2021-22") {

						layer = new ImageryLayer({
							url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/KH_202122_cropwise/ImageServer",
							pixelFilter : colorize21,
							//pixelFilter : colorize2122,
							id : "imageLayer"

						});
						layer.when(function() {
							rasterAttributes = layer.rasterAttributeTable.features;
							//console.log("raster attr features:---------------------------------------");
							//console.log(rasterAttributes);
							fields = rasterAttributes.filter(function(item, i) {
								className = item.attributes.Class_Name;
								//return className === 'Maize+Bajra+Jowar' || className === 'Cotton+Tur' || className === 'Soybean+Short Duration Pulses' || className === 'Paddy' || className === 'Sugarcane' || className === 'Other Kharif Crops' || className === 'Soybean + Tur';
								return className === 'Paddy' || className === 'Cotton+Tur' || className === 'Soybean+Tur' || className === 'Soybean+Short Duration Pulses' || className === 'Maize+Bajara+Jowar' || className === 'Other Kharif Crops';
								//return className === 'Cotton+Tur';
							});
						});
					}

				} else if (seasonName == 'Rabi') {
					if (cropyear === "2018-19") {
						layer = new ImageryLayer({
							url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/RB_201819_cropwise/ImageServer",
							pixelFilter : colorize3,
							id : "imageLayer"

						});
						layer.when(function() {
							rasterAttributes = layer.rasterAttributeTable.features;
							fields = rasterAttributes.filter(function(item, i) {
								className = item.attributes.Class_Names;
								return className === 'Rabi Jowar' || className === 'Wheat' || className === 'Gram' || className === 'Maize' || className === 'Other Rabi Crops';
							});
						});
					} else if (cropyear === "2019-20") {
						layer = new ImageryLayer({
							url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/RB_201920_cropwise/ImageServer",
							pixelFilter : colorize3,
							id : "imageLayer"

						});
						layer.when(function() {
							rasterAttributes = layer.rasterAttributeTable.features;
							fields = rasterAttributes.filter(function(item, i) {
								className = item.attributes.Class_Names;
								return className === 'Rabi Jowar' || className === 'Wheat' || className === 'Gram' || className === 'Total Rabi Crops' || className === 'Other Rabi Crops';
							});
						});
					} else if (cropyear === "2020-21") {
						layer = new ImageryLayer({
							url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/RB_202021_cropwise/ImageServer",
							pixelFilter : colorize8,
							id : "imageLayer"

						});
						layer.when(function() {
							rasterAttributes = layer.rasterAttributeTable.features;
							fields = rasterAttributes.filter(function(item, i) {
								className = item.attributes.Class_Names;
								return className === 'Rabi Jowar' || className === 'Wheat' || className === 'Gram' || className === 'Total Rabi Crops' || className === 'Other Rabi Crops';
							});
						});
					}
					else if (cropyear === "2021-22") {
						layer = new ImageryLayer({
							url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/RB_202122_cropwise/ImageServer",
							pixelFilter : colorize8,
							id : "imageLayer"

						});
						layer.when(function() {
							rasterAttributes = layer.rasterAttributeTable.features;
							fields = rasterAttributes.filter(function(item, i) {
								className = item.attributes.Class_Names;
								return className === 'Rabi Jowar' || className === 'Wheat' || className === 'Gram' || className === 'Total Rabi Crops' || className === 'Other Rabi Crops';
							});
						});
					}

				}

			}

			function colorize1(pixelData) {
				if (pixelData === null || pixelData.pixelBlock === null || pixelData.pixelBlock.pixels === null) {
					return;
				}
				var pixelBlock = pixelData.pixelBlock;

				var pixels = pixelBlock.pixels;

				var band1 = pixels[0];

				var rBand = [];
				var gBand = [];
				var bBand = [];

				var mask = [];

				var numPixels = pixelBlock.width * pixelBlock.height;

				for (var i = 0; i < numPixels; i++) {
					var val = band1[i];

					if (val === fields[0].attributes.Value) {
						mask[i] = 1;
						rBand[i] = fields[0].attributes.Red;
						gBand[i] = fields[0].attributes.Green;
						bBand[i] = fields[0].attributes.Blue;

					} else {
						mask[i] = 0;
						rBand[i] = 0;
						gBand[i] = 0;
						bBand[i] = 0;
					}

				}
				// Set the new pixel values on the pixelBlock
				pixelData.pixelBlock.pixels = [rBand, gBand, bBand];
				pixelData.pixelBlock.statistics = null;
				pixelData.pixelBlock.pixelType = "U4";
				// U8 is used for color
				pixelData.pixelBlock.mask = mask;
			}

			function colorize21(pixelData) {
				//debugger;
				if (pixelData === null || pixelData.pixelBlock === null || pixelData.pixelBlock.pixels === null) {
					return;
				}
				var pixelBlock = pixelData.pixelBlock;

				var pixels = pixelBlock.pixels;

				var band1 = pixels[0];

				var rBand = [];
				var gBand = [];
				var bBand = [];

				var mask = [];

				var numPixels = pixelBlock.width * pixelBlock.height;

				for (var i = 0; i < numPixels; i++) {
					var val = band1[i];
					//debugger;
					//console.log("----------------");
					//console.log(fields[0]);

					if (val === fields[0].attributes.Value) {
						mask[i] = 1;
						rBand[i] = fields[0].attributes.Red;
						gBand[i] = fields[0].attributes.Green;
						bBand[i] = fields[0].attributes.Blue;

					} else if (val === fields[1].attributes.Value) {

						mask[i] = 2;
						rBand[i] = fields[1].attributes.Red;
						gBand[i] = fields[1].attributes.Green;
						bBand[i] = fields[1].attributes.Blue;

					} else if (val === fields[2].attributes.Value) {

						mask[i] = 3;
						rBand[i] = fields[2].attributes.Red;
						gBand[i] = fields[2].attributes.Green;
						bBand[i] = fields[2].attributes.Blue;

					} else if (val === fields[3].attributes.Value) {

						mask[i] = 4;
						rBand[i] = fields[3].attributes.Red;
						gBand[i] = fields[3].attributes.Green;
						bBand[i] = fields[3].attributes.Blue;

					} else if (val === fields[4].attributes.Value) {
						mask[i] = 5;
						rBand[i] = fields[4].attributes.Red;
						gBand[i] = fields[4].attributes.Green;
						bBand[i] = fields[4].attributes.Blue;

					} else if (val === fields[5].attributes.Value) {
						mask[i] = 6;
						rBand[i] = fields[5].attributes.Red;
						gBand[i] = fields[5].attributes.Green;
						bBand[i] = fields[5].attributes.Blue;

					} else {
						mask[i] = 0;
						rBand[i] = 0;
						gBand[i] = 0;
						bBand[i] = 0;
					}

				}

				// Set the new pixel values on the pixelBlock
				pixelData.pixelBlock.pixels = [rBand, gBand, bBand];
				pixelData.pixelBlock.statistics = null;
				pixelData.pixelBlock.pixelType = "U4";
				// U8 is used for color
				pixelData.pixelBlock.mask = mask;
			}

			function colorize2(pixelData) {

				if (pixelData === null || pixelData.pixelBlock === null || pixelData.pixelBlock.pixels === null) {
					return;
				}
				var pixelBlock = pixelData.pixelBlock;

				var pixels = pixelBlock.pixels;

				var band1 = pixels[0];

				var rBand = [];
				var gBand = [];
				var bBand = [];

				var mask = [];

				var numPixels = pixelBlock.width * pixelBlock.height;

				for (var i = 0; i < numPixels; i++) {
					var val = band1[i];

					if (val === fields[0].attributes.Value) {
						mask[i] = 1;
						rBand[i] = fields[0].attributes.Red;
						gBand[i] = fields[0].attributes.Green;
						bBand[i] = fields[0].attributes.Blue;

					} else if (val === fields[1].attributes.Value) {

						mask[i] = 2;
						rBand[i] = fields[1].attributes.Red;
						gBand[i] = fields[1].attributes.Green;
						bBand[i] = fields[1].attributes.Blue;

					} else if (val === fields[2].attributes.Value) {

						mask[i] = 3;
						rBand[i] = fields[2].attributes.Red;
						gBand[i] = fields[2].attributes.Green;
						bBand[i] = fields[2].attributes.Blue;

					} else if (val === fields[3].attributes.Value) {

						mask[i] = 4;
						rBand[i] = fields[3].attributes.Red;
						gBand[i] = fields[3].attributes.Green;
						bBand[i] = fields[3].attributes.Blue;

					} else if (val === fields[4].attributes.Value) {
						mask[i] = 5;
						rBand[i] = fields[4].attributes.Red;
						gBand[i] = fields[4].attributes.Green;
						bBand[i] = fields[4].attributes.Blue;

					} else if (val === fields[5].attributes.Value) {

						mask[i] = 6;
						rBand[i] = fields[5].attributes.Red;
						gBand[i] = fields[5].attributes.Green;
						bBand[i] = fields[5].attributes.Blue;

					} else if (val === fields[6].attributes.Value) {

						mask[i] = 7;
						rBand[i] = fields[6].attributes.Red;
						gBand[i] = fields[6].attributes.Green;
						bBand[i] = fields[6].attributes.Blue;

					} else {
						mask[i] = 0;
						rBand[i] = 0;
						gBand[i] = 0;
						bBand[i] = 0;
					}

				}

				// Set the new pixel values on the pixelBlock
				pixelData.pixelBlock.pixels = [rBand, gBand, bBand];
				pixelData.pixelBlock.statistics = null;
				pixelData.pixelBlock.pixelType = "U4";
				// U8 is used for color
				pixelData.pixelBlock.mask = mask;
			}

			function colorize3(pixelData) {

				if (pixelData === null || pixelData.pixelBlock === null || pixelData.pixelBlock.pixels === null) {
					return;
				}
				var pixelBlock = pixelData.pixelBlock;

				var pixels = pixelBlock.pixels;

				var band1 = pixels[0];

				var rBand = [];
				var gBand = [];
				var bBand = [];

				var mask = [];

				var numPixels = pixelBlock.width * pixelBlock.height;

				for (var i = 0; i < numPixels; i++) {
					var val = band1[i];

					if (val === fields[0].attributes.Value) {
						mask[i] = 1;
						rBand[i] = fields[0].attributes.Red;
						gBand[i] = fields[0].attributes.Green;
						bBand[i] = fields[0].attributes.Blue;

					} else if (val === fields[1].attributes.Value) {

						mask[i] = 2;
						rBand[i] = fields[1].attributes.Red;
						gBand[i] = fields[1].attributes.Green;
						bBand[i] = fields[1].attributes.Blue;

					} else if (val === fields[2].attributes.Value) {

						mask[i] = 3;
						rBand[i] = fields[2].attributes.Red;
						gBand[i] = fields[2].attributes.Green;
						bBand[i] = fields[2].attributes.Blue;

					} else if (val === fields[3].attributes.Value) {

						mask[i] = 4;
						rBand[i] = fields[3].attributes.Red;
						gBand[i] = fields[3].attributes.Green;
						bBand[i] = fields[3].attributes.Blue;

					} else if (val === fields[4].attributes.Value) {

						mask[i] = 5;
						rBand[i] = fields[4].attributes.Red;
						gBand[i] = fields[4].attributes.Green;
						bBand[i] = fields[4].attributes.Blue;

					} else {
						mask[i] = 0;
						rBand[i] = 0;
						gBand[i] = 0;
						bBand[i] = 0;
					}

				}

				// Set the new pixel values on the pixelBlock
				pixelData.pixelBlock.pixels = [rBand, gBand, bBand];
				pixelData.pixelBlock.statistics = null;
				pixelData.pixelBlock.pixelType = "U4";
				// U8 is used for color
				pixelData.pixelBlock.mask = mask;
			}

			function colorize8(pixelData) {

				if (pixelData === null || pixelData.pixelBlock === null || pixelData.pixelBlock.pixels === null) {
					return;
				}
				var pixelBlock = pixelData.pixelBlock;

				var pixels = pixelBlock.pixels;

				var band1 = pixels[0];

				var rBand = [];
				var gBand = [];
				var bBand = [];

				var mask = [];

				var numPixels = pixelBlock.width * pixelBlock.height;

				for (var i = 0; i < numPixels; i++) {
					var val = band1[i];

					if (val === fields[0].attributes.Value) {
						mask[i] = 1;
						rBand[i] = fields[0].attributes.Red;
						gBand[i] = fields[0].attributes.Green;
						bBand[i] = fields[0].attributes.Blue;

					} else if (val === fields[1].attributes.Value) {

						mask[i] = 2;
						rBand[i] = fields[1].attributes.Red;
						gBand[i] = fields[1].attributes.Green;
						bBand[i] = fields[1].attributes.Blue;

					} else if (val === fields[2].attributes.Value) {

						mask[i] = 3;
						rBand[i] = fields[2].attributes.Red;
						gBand[i] = fields[2].attributes.Green;
						bBand[i] = fields[2].attributes.Blue;

					} else if (val === fields[3].attributes.Value) {

						mask[i] = 4;
						rBand[i] = fields[3].attributes.Red;
						gBand[i] = fields[3].attributes.Green;
						bBand[i] = fields[3].attributes.Blue;

					} else if (val === fields[4].attributes.Value) {

						mask[i] = 5;
						rBand[i] = fields[4].attributes.Red;
						gBand[i] = fields[4].attributes.Green;
						bBand[i] = fields[4].attributes.Blue;

					} else {
						mask[i] = 0;
						rBand[i] = 0;
						gBand[i] = 0;
						bBand[i] = 0;
					}

				}

				// Set the new pixel values on the pixelBlock
				pixelData.pixelBlock.pixels = [rBand, gBand, bBand];
				pixelData.pixelBlock.statistics = null;
				pixelData.pixelBlock.pixelType = "U4";
				// U8 is used for color
				pixelData.pixelBlock.mask = mask;
			}
			function colorize7(pixelData) {
				debugger;
				if (pixelData === null || pixelData.pixelBlock === null || pixelData.pixelBlock.pixels === null) {
					return;
				}
				var pixelBlock = pixelData.pixelBlock;

				var pixels = pixelBlock.pixels;

				var band1 = pixels[0];

				var rBand = [];
				var gBand = [];
				var bBand = [];

				var mask = [];

				var numPixels = pixelBlock.width * pixelBlock.height;

				for (var i = 0; i < numPixels; i++) {
					var val = band1[i];

					if (val === fields[0].attributes.Value) {
						mask[i] = 1;
						rBand[i] = fields[0].attributes.Red;
						gBand[i] = fields[0].attributes.Green;
						bBand[i] = fields[0].attributes.Blue;

					} else if (val === fields[1].attributes.Value) {

						mask[i] = 2;
						rBand[i] = fields[1].attributes.Red;
						gBand[i] = fields[1].attributes.Green;
						bBand[i] = fields[1].attributes.Blue;

					} else if (val === fields[2].attributes.Value) {

						mask[i] = 3;
						rBand[i] = fields[2].attributes.Red;
						gBand[i] = fields[2].attributes.Green;
						bBand[i] = fields[2].attributes.Blue;

					} else if (val === fields[3].attributes.Value) {

						mask[i] = 4;
						rBand[i] = fields[3].attributes.Red;
						gBand[i] = fields[3].attributes.Green;
						bBand[i] = fields[3].attributes.Blue;

					} else if (val === fields[4].attributes.Value) {

						mask[i] = 5;
						rBand[i] = fields[4].attributes.Red;
						gBand[i] = fields[4].attributes.Green;
						bBand[i] = fields[4].attributes.Blue;

					} else {
						mask[i] = 0;
						rBand[i] = 0;
						gBand[i] = 0;
						bBand[i] = 0;
					}

				}

				// Set the new pixel values on the pixelBlock
				pixelData.pixelBlock.pixels = [rBand, gBand, bBand];
				pixelData.pixelBlock.statistics = null;
				pixelData.pixelBlock.pixelType = "U4";
				// U8 is used for color
				pixelData.pixelBlock.mask = mask;
			}
			/*------------------------------------------------------------------------------------------------------*/
			function colorize2122(pixelData) {
				debugger;
				if (pixelData === null || pixelData.pixelBlock === null || pixelData.pixelBlock.pixels === null) {
					return;
				}
				var pixelBlock = pixelData.pixelBlock;

				var pixels = pixelBlock.pixels;

				var band1 = pixels[0];

				var rBand = [];
				var gBand = [];
				var bBand = [];

				var mask = [];

				var numPixels = pixelBlock.width * pixelBlock.height;

				for (var i = 0; i < numPixels; i++) {
					var val = band1[i];

					if (val === fields[0].attributes.Value) {
						mask[i] = 1;
						rBand[i] = fields[0].attributes.Red;
						gBand[i] = fields[0].attributes.Green;
						bBand[i] = fields[0].attributes.Blue;

					} else if (val === fields[1].attributes.Value) {

						mask[i] = 2;
						rBand[i] = fields[1].attributes.Red;
						gBand[i] = fields[1].attributes.Green;
						bBand[i] = fields[1].attributes.Blue;

					} else if (val === fields[2].attributes.Value) {

						mask[i] = 3;
						rBand[i] = fields[2].attributes.Red;
						gBand[i] = fields[2].attributes.Green;
						bBand[i] = fields[2].attributes.Blue;

					} else if (val === fields[3].attributes.Value) {

						mask[i] = 4;
						rBand[i] = fields[3].attributes.Red;
						gBand[i] = fields[3].attributes.Green;
						bBand[i] = fields[3].attributes.Blue;

					} else if (val === fields[4].attributes.Value) {
						mask[i] = 5;
						rBand[i] = fields[4].attributes.Red;
						gBand[i] = fields[4].attributes.Green;
						bBand[i] = fields[4].attributes.Blue;

					} else if (val === fields[5].attributes.Value) {
						mask[i] = 6;
						rBand[i] = fields[5].attributes.Red;
						gBand[i] = fields[5].attributes.Green;
						bBand[i] = fields[5].attributes.Blue;

					} else {
						mask[i] = 0;
						rBand[i] = 0;
						gBand[i] = 0;
						bBand[i] = 0;
					}

				}

				// Set the new pixel values on the pixelBlock
				pixelData.pixelBlock.pixels = [rBand, gBand, bBand];
				pixelData.pixelBlock.statistics = null;
				pixelData.pixelBlock.pixelType = "U4";
				// U8 is used for color
				pixelData.pixelBlock.mask = mask;
			}
			/*------------------------------------------------------------------------------------------------------*/
			
			function colorize(pixelData) {

				if (pixelData === null || pixelData.pixelBlock === null || pixelData.pixelBlock.pixels === null) {
					return;
				}
				var pixelBlock = pixelData.pixelBlock;

				var pixels = pixelBlock.pixels;

				var band1 = pixels[0];

				var rBand = [];
				var gBand = [];
				var bBand = [];

				var mask = [];
				var numPixels = pixelBlock.width * pixelBlock.height;

				for (var i = 0; i < numPixels; i++) {
					var val = band1[i];

					if (val === fields[0].attributes.Value) {
						mask[i] = 1;
						rBand[i] = fields[0].attributes.Red;
						gBand[i] = fields[0].attributes.Green;
						bBand[i] = fields[0].attributes.Blue;

					} else {
						mask[i] = 0;
						rBand[i] = 0;
						gBand[i] = 0;
						bBand[i] = 0;
					}

				}

				pixelData.pixelBlock.pixels = [rBand, gBand, bBand];
				pixelData.pixelBlock.statistics = null;
				pixelData.pixelBlock.pixelType = "U4";
				pixelData.pixelBlock.mask = mask;
			}

		},

		getLegend : function() {
			debugger;
			cirname = document.getElementById("circle").value;
			talname = document.getElementById("taluka").value;
			distname = document.getElementById("district").value;
			divi = document.getElementById("division").value;
			cropnaame = document.getElementById("cropSelect").value;
			cropyear = document.getElementById("year").value;
			seasonName = document.getElementById("seasonSelect").value;

			// console.log(document.getElementById("circle").value);

			document.getElementById("legpaddy").style.display = "none";

			document.getElementById("legctntur").style.display = "none";

			document.getElementById("legsoytur").style.display = "none";

			document.getElementById("legsoyshor").style.display = "none";

			document.getElementById("legothkh").style.display = "none";

			document.getElementById("legsug").style.display = "none";

			document.getElementById("legmbj").style.display = "none";

			document.getElementById("legjowar").style.display = "none";

			document.getElementById("legwheat").style.display = "none";

			document.getElementById("leggram").style.display = "none";

			document.getElementById("legmaiz").style.display = "none";

			document.getElementById("legothrabi").style.display = "none";

			document.getElementById("legTotRb").style.display = "none";

			if (document.getElementById("district").value === "") {
				distname = "All";
			}

			if (document.getElementById("taluka").value === "") {
				talname = "All";
			}

			if (document.getElementById("circle").value === "") {
				cirname = "All";
			}

			if (seasonName == 'Kharif') {
				legendtask = new QueryTask(this.kharifstats);
			} else if (seasonName == 'Rabi') {
				legendtask = new QueryTask(this.rabistats);
			}

			//-------For Query--------
			queryUsed = new Query();
			queryUsed.outFields = ["*"];
			queryUsed.returnGeometry = false;
			queryUsed.outSpatialReference = {
				"wkid" : 102100
			};
			queryUsed.returnDistinctValues = true;

			if (divi == 'All' && distname == 'All' && talname == 'All' && cirname == 'All') {
				queryUsed.where = "crop_year = '" + cropyear + "' and   advename <> '' ";
			} else if (divi != 'All' && distname == 'All' && talname == 'All' && cirname == 'All') {
				queryUsed.where = "crop_year = '" + cropyear + "' and  advename ='" + divi + "' ";
			} else if (divi != 'All' && distname != 'All' && talname == 'All' && cirname == 'All') {
				queryUsed.where = "crop_year = '" + cropyear + "' and  advename ='" + divi + "' and dtename ='" + distname + "' ";
			} else if (divi != 'All' && distname != 'All' && talname != 'All' && cirname == 'All') {
				queryUsed.where = "crop_year = '" + cropyear + "' and  advename ='" + divi + "' and dtename ='" + distname + "' and  thename = '" + talname + "' ";
			} else if (divi != 'All' && distname != 'All' && talname != 'All' && cirname != 'All') {
				queryUsed.where = "crop_year = '" + cropyear + "' and  advename ='" + divi + "' and dtename ='" + distname + "' and  thename = '" + talname + "' and  cirname = '" + cirname + "' ";
			}

			// console.log(queryUsed.where);
			legendtask.execute(queryUsed).then(function(featureset) {
				// alert();
				var result = featureset.features;

				if (result.length == 0) {
					swal("Data Not Available");
				} else {
					array.forEach(result, lang.hitch(this, function(value) {

						cropname = value.attributes.crop_name;
						croparea = value.attributes.acreage_area;
						// console.log(croparea);

						//---------------------------------legend------------------------

						if (croparea !== 0) {
							if (cropname == 'Paddy') {
								document.getElementById("legpaddy").style.display = "block";
							} else if (cropname == 'Cotton+Tur') {
								document.getElementById("legctntur").style.display = "block";
							} else if (cropname == 'Soybean+Tur') {
								document.getElementById("legsoytur").style.display = "block";
							} else if (cropname == 'Soybean+Short Duration Pulses') {
								document.getElementById("legsoyshor").style.display = "block";
							} else if (cropname == 'Sugarcane') {
								document.getElementById("legsug").style.display = "block";
							} else if (cropname == 'Maize+Bajra+Jowar') {
								document.getElementById("legmbj").style.display = "block";
							} else if (cropname == 'Rabi Jowar') {
								document.getElementById("legjowar").style.display = "block";
							} else if (cropname == 'Wheat') {
								document.getElementById("legwheat").style.display = "block";
							} else if (cropname == 'Gram') {
								document.getElementById("leggram").style.display = "block";
							} else if (cropname == 'Maize') {
								document.getElementById("legmaiz").style.display = "block";
							} else if (cropname == 'Other Kharif Crops') {
								document.getElementById("legothkh").style.display = "block";
							} else if (cropname == 'Other Rabi Crops') {
								document.getElementById("legothrabi").style.display = "block";
							} else if (cropname == 'Total Rabi Crops') {
								document.getElementById("legTotRb").style.display = "block";
							}

							dom.byId("divLoadingIndicator").style.display = 'none';
						}
					}));
				}
			});
		},
		getBarGraph : function() {
			debugger;
			cropyear = document.getElementById("year").value;
			divi = document.getElementById("division").value;
			distname = document.getElementById("district").value;
			talname = document.getElementById("taluka").value;
			circlename = document.getElementById("circle").value;
			cropnaame = document.getElementById("cropSelect").value;
			seasonName = document.getElementById("seasonSelect").value;

			//divname = divi.toUpperCase();

			var circleArea;
			for (var i = 0; i < valueKharif.length; i++) {
				if (valueKharif[i].name === cropnaame) {
					cropCode = valueKharif[i].code;
				}
			}
			for (var i = 0; i < zoneGetcropchange.length; i++) {
				if (zoneGetcropchange[i].name === divi) {
					dvncode = zoneGetcropchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					dtncode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talcode = zoneGetdistchange[i].code;
				}
			}
			for (var i = 0; i < zoneGettalchange.length; i++) {
				if (zoneGettalchange[i].name === circlename) {
					circleArea = zoneGettalchange[i].area;
				}
				if (zoneGettalchange[i].name === circlename) {
					circode = zoneGettalchange[i].code;
				}
			}
			dom.byId("divLoadingIndicator").style.display = 'block';
			roundareaha = Math.round(circleArea * 100) / 100;
			totcirareacount = 0;

			arrgraph = [];
			catarr = [];
			totcountarearound = 0;
			var zone = [];
			var values = [];
			var testVals = {};

			divisiondata = [];
			strdivi = "";
			districtdata = [];
			strdist = "";
			talukadata = [];
			strtal = "";
			circledata = [];
			strcir = "";
			seperator = "";

			divisiondataTga = [];
			strdiviTga = "";
			districtdataTga = [];
			strdistTga = "";
			talukadataTga = [];
			strtalTga = "";
			circledataTga = [];
			strcirTga = "";

			divisiondataAgri = [];
			strdiviAgri = [];
			districtdataAgri = [];
			strdistAgri = "";
			talukadataAgri = [];
			strtalAgri = "";
			circledataAgri = [];
			strcirAgri = "";

			graphTitle = "";

			//---------for all Crops---------
			strdivicrp = "";
			strdistcrp = "";
			strtalcrp = "";
			strcircrp = "";
			cropdata = [];
			//----------for all crops----------

			if (seasonName == 'Kharif') {
				stastask = new QueryTask(this.kharifstats);
			} else if (seasonName == 'Rabi') {
				stastask = new QueryTask(this.rabistats);
			}

			//------------------- Bar Graph  Table-----------------------------
			var gramE = [];
			statsquery = new Query();
			statsquery.outFields = ["*"];
			// statsquery.returnDistinctValues = true;
			statsquery.returnGeometry = true;
			statsquery.outSpatialReference = {
				"wkid" : 102100
			};

			queryStatistic = queryUsedFurther.where;
			statsquery.where = queryStatistic;
			// console.log(queryStatistic);

			finalData = [];
			stastask.execute(statsquery).then(function(results2) {

				var features = results2.features;
				if (features.length < 1) {
					swal("Crop statistics not available for this Region");
				} else {
					array.forEach(features, lang.hitch(this, function(feature2, index) {
						gramE.push(feature2);

						advename = feature2.attributes.advename;
						dtename = feature2.attributes.dtename;
						cirname = feature2.attributes.cirname;
						circode = feature2.attributes.circode;
						areahanotround = feature2.attributes.acreage_area;

						areaha = Math.round(areahanotround * 100) / 100;
						// console.log(areaha);
						totcirareacount += areaha;

						thename = feature2.attributes.thename;
						thecode = feature2.attributes.thecode;
						cropname = feature2.attributes.crop_name;

						cirtga = feature2.attributes.cir_tga;
						cirtgaround = Math.round(cirtga * 100) / 100;
						ciragricultural = feature2.attributes.cir_agricultural;
						ciragriculturalround = Math.round(ciragricultural * 100) / 100;

						cirbuiltup = feature2.attributes.cir_builtup;
						cirforest = feature2.attributes.cir_forest;
						cirwasteland = feature2.attributes.cir_wasteland;
						cirwaterbodies = feature2.attributes.cir_waterbodies;

						totcountarearound = Math.round(totcirareacount * 100) / 100;
						roundareaha = Math.round(areaha * 100) / 100;

						// console.log(totcirareacount);
						//console.log(" Dist Name : " + distname + " Tal Name : " + talname + " Circle Name: " + circlename);

						if (cropnaame == "All") {
							if ((divi == "All" && distname == "" && talname == "" && circlename == "") || (divi == "All" && distname == "All" && talname == "" && circlename == "") || (divi == "All" && distname == "All" && talname == "All" && circlename == "") || (divi == "All" && distname == "All" && talname == "All" && circlename == "All")) {
								// alert("");
								graphTitle = "Division Wise " + seasonName + " Sown Area (Ha)";
								dom.byId("statwise").innerHTML = "Division Wise " + seasonName + " Sown Area (Ha)";
								var n = strdivi.includes(advename);
								var n1 = strdivicrp.includes(cropname);
								if (n) {
									divisiondata[advename] = divisiondata[advename] + areaha;
									strdivi += seperator + advename;
									seperator = ", ";

								} else {
									var jsonData = {
										cropname : areaha
									};
									//console.log(cropname);
									divisiondata[advename] = areaha;
									strdivi += seperator + advename;
									seperator = ", ";
								}
								if ( advename in finalData === true) {

									var existData = finalData[advename];
									if ( cropname in existData === true) {

										var cropArea = finalData[advename][cropname];
										finalData[advename][cropname] = areaha + cropArea;
									} else {
										finalData[advename][cropname] = areaha;
									}

								} else {
									var obj = {};
									obj[cropname] = areaha;
									finalData[advename] = obj;
								}
								//******************TGA and agriculture area*******************
								var nagri = strdiviAgri.includes(advename);
								var ntga = strdiviTga.includes(advename);
								if (nagri) {
									divisiondataAgri[advename] = divisiondataAgri[advename] + ciragriculturalround;
									strdiviAgri += seperator + advename;
									seperator = ", ";
								} else {
									divisiondataAgri[advename] = ciragriculturalround;
									strdiviAgri += seperator + advename;
									seperator = ", ";
								}

								if (ntga) {
									divisiondataTga[advename] = divisiondataTga[advename] + cirtgaround;
									strdiviTga += seperator + advename;
									seperator = ", ";
								} else {
									divisiondataTga[advename] = cirtgaround;
									strdiviTga += seperator + advename;
									seperator = ", ";
								}
							} else if ((divi != "All" && distname == "" && talname == "" && circlename == "") || (divi != "All" && distname == "All" && talname == "" && circlename == "") || (divi != "All" && distname == "All" && talname == "All" && circlename == "") || (divi != "All" && distname == "All" && talname == "All" && circlename == "All")) {
								graphTitle = "District Wise " + seasonName + " Sown Area (Ha)";

								dom.byId("statwise").innerHTML = "Division Wise " + seasonName + " Sown Area (Ha)";
								var n = strdist.includes(dtename);
								var n1 = strdistcrp.includes(cropname);
								if (n) {
									districtdata[dtename] = districtdata[dtename] + areaha;
									strdist += seperator + dtename;
									seperator = ", ";

								} else {
									var jsonData = {
										cropname : areaha
									};
									//console.log(cropname);
									districtdata[dtename] = areaha;
									strdist += seperator + dtename;
									seperator = ", ";
								}

								if ( dtename in finalData === true) {

									var existData = finalData[dtename];
									if ( cropname in existData === true) {

										var cropArea = finalData[dtename][cropname];
										finalData[dtename][cropname] = areaha + cropArea;

									} else {

										finalData[dtename][cropname] = areaha;
									}

								} else {
									var obj = {};
									obj[cropname] = areaha;
									finalData[dtename] = obj;
								}

								//******************TGA and agriculture area*******************
								var nagri = strdistAgri.includes(dtename);
								var ntga = strdistTga.includes(dtename);
								if (nagri) {
									districtdataAgri[dtename] = districtdataAgri[dtename] + ciragriculturalround;
									strdistAgri += seperator + dtename;
									seperator = ", ";
								} else {
									districtdataAgri[dtename] = ciragriculturalround;
									strdistAgri += seperator + dtename;
									seperator = ", ";
								}

								if (ntga) {
									districtdataTga[dtename] = districtdataTga[dtename] + cirtgaround;
									strdistTga += seperator + dtename;
									seperator = ", ";
								} else {
									districtdataTga[dtename] = cirtgaround;
									strdistTga += seperator + dtename;
									seperator = ", ";
								}
							} else if ((divi != "All" && distname != "All" && talname == "" && circlename == "") || (divi != "All" && distname != "All" && talname == "All" && circlename == "") || (divi != "All" && distname != "All" && talname == "All" && circlename == "All")) {

								graphTitle = "Taluka Wise " + seasonName + " Sown Area (Ha)";
								dom.byId("statwise").innerHTML = "District Wise " + seasonName + " Sown Area (Ha)";
								var n = strtal.includes(thename);
								var n1 = strtalcrp.includes(cropname);
								if (n) {
									talukadata[thename] = talukadata[thename] + areaha;
									strtal += seperator + thename;
									seperator = ", ";

								} else {
									var jsonData = {
										cropname : areaha
									};
									//console.log(cropname);
									talukadata[thename] = areaha;
									strtal += seperator + thename;
									seperator = ", ";
								}

								if ( thename in finalData === true) {

									var existData = finalData[thename];
									if ( cropname in existData === true) {

										var cropArea = finalData[thename][cropname];
										finalData[thename][cropname] = areaha + cropArea;

									} else {

										finalData[thename][cropname] = areaha;
									}

								} else {
									var obj = {};
									obj[cropname] = areaha;
									finalData[thename] = obj;
								}
								//******************TGA and agriculture area*******************
								var nagri = strtalAgri.includes(thename);
								var ntga = strtalTga.includes(thename);
								if (nagri) {
									talukadataAgri[thename] = talukadataAgri[thename] + ciragriculturalround;
									strtalAgri += seperator + thename;
									seperator = ", ";
								} else {
									talukadataAgri[thename] = ciragriculturalround;
									strtalAgri += seperator + thename;
									seperator = ", ";
								}

								if (ntga) {
									talukadataTga[thename] = talukadataTga[thename] + cirtgaround;
									strtalTga += seperator + thename;
									seperator = ", ";
								} else {
									talukadataTga[thename] = cirtgaround;
									strtalTga += seperator + thename;
									seperator = ", ";
								}
							} else if ((divi != "All" && distname != "All" && talname != "All" && circlename == "") || (divi != "All" && distname != "All" && talname != "All" && circlename == "All") || (divi != "All" && distname != "All" && talname == "All" && circlename == "All")) {

								graphTitle = "Revenue Circle Wise " + seasonName + " Sown Area (Ha)";
								dom.byId("statwise").innerHTML = "Taluka Wise " + seasonName + " Sown Area (Ha)";
								var n = strcir.includes(cirname);
								var n1 = strcircrp.includes(cropname);
								if (n) {
									circledata[cirname] = circledata[cirname] + areaha;
									strcir += seperator + cirname;
									seperator = ", ";

								} else {
									var jsonData = {
										cropname : areaha
									};
									//console.log(cropname);
									circledata[cirname] = areaha;
									strcir += seperator + cirname;
									seperator = ", ";
								}

								if ( cirname in finalData === true) {
									var existData = finalData[cirname];
									if ( cropname in existData === true) {

										var cropArea = finalData[cirname][cropname];
										finalData[cirname][cropname] = areaha + cropArea;

									} else {
										finalData[cirname][cropname] = areaha;
									}

								} else {
									var obj = {};
									obj[cropname] = areaha;
									finalData[cirname] = obj;
								}

								//******************TGA and agriculture area*******************
								var nagri = strcirAgri.includes(cirname);
								var ntga = strcirTga.includes(cirname);
								if (nagri) {
									circledataAgri[cirname] = circledataAgri[cirname] + ciragriculturalround;
									strcirAgri += seperator + cirname;
									seperator = ", ";
								} else {
									circledataAgri[cirname] = ciragriculturalround;
									strcirAgri += seperator + cirname;
									seperator = ", ";
								}

								if (ntga) {
									circledataTga[cirname] = circledataTga[cirname] + cirtgaround;
									strcirTga += seperator + cirname;
									seperator = ", ";
								} else {
									circledataTga[cirname] = cirtgaround;
									strcirTga += seperator + cirname;
									seperator = ", ";
								}

							} else if ((divi != "All" && distname != "All" && talname != "All" && circlename != "All")) {

								graphTitle = "Revenue Circle Wise " + seasonName + " Sown Area (Ha)";
								dom.byId("statwise").innerHTML = "Revenue Circle Wise " + seasonName + " Sown Area (Ha)";
								var n = strcir.includes(cirname);
								var n1 = strcircrp.includes(cropname);
								if (n) {
									circledata[cirname] = circledata[cirname] + areaha;
									strcir += seperator + cirname;
									seperator = ", ";

								} else {
									var jsonData = {
										cropname : areaha
									};
									//console.log(cropname);
									circledata[cirname] = areaha;
									strcir += seperator + cirname;
									seperator = ", ";
								}

								if ( cirname in finalData === true) {
									var existData = finalData[cirname];
									if ( cropname in existData === true) {

										var cropArea = finalData[cirname][cropname];
										finalData[cirname][cropname] = areaha + cropArea;

									} else {
										finalData[cirname][cropname] = areaha;
									}

								} else {
									var obj = {};
									obj[cropname] = areaha;
									finalData[cirname] = obj;
								}

								//******************TGA and agriculture area*******************
								var nagri = strcirAgri.includes(cirname);
								var ntga = strcirTga.includes(cirname);
								if (nagri) {
									circledataAgri[cirname] = circledataAgri[cirname] + ciragriculturalround;
									strcirAgri += seperator + cirname;
									seperator = ", ";
								} else {
									circledataAgri[cirname] = ciragriculturalround;
									strcirAgri += seperator + cirname;
									seperator = ", ";
								}

								if (ntga) {
									circledataTga[cirname] = circledataTga[cirname] + cirtgaround;
									strcirTga += seperator + cirname;
									seperator = ", ";
								} else {
									circledataTga[cirname] = cirtgaround;
									strcirTga += seperator + cirname;
									seperator = ", ";
								}

							}
						}

						//-------------------------------------------------------------------------
						tablebody = document.getElementById("tableBodyCropSownPart1");
						$("#dataTablePart1 tbody").empty();

						if (tableIterationFlag == true) {

							/******************************table t2****************************/
							if ((divi == "All" && distname == "" && talname == "" && circlename == "") || (divi == "All" && distname == "All" && talname == "" && circlename == "") || (divi == "All" && distname == "All" && talname == "All" && circlename == "") || (divi == "All" && distname == "All" && talname == "" && circlename == "All")) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							} else if ((distname == "" && talname == "" && circlename == "") || (distname == "All" && talname == "" && circlename == "")) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							} else if ((talname == "" && circlename == "") || (talname == "All" && circlename == "")) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							} else if ((talname != "All" && circlename == "")) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Taluka</b><td style='padding-left: 6%;'>" + talname + "</td></tr>\n\<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							} else if ((talname != "All" && circlename != "All") || (talname == "All" && circlename != "All")) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Taluka</b><td style='padding-left: 6%;'>" + talname + "</td></tr>\n\<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Revenue Circle</b><td style='padding-left: 6%;'>" + circlename + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							} else if (talname != "All" && circlename == "All") {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Taluka</b><td style='padding-left: 6%;'>" + talname + "</td></tr>\n\<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							} else if ((talname == "All" && circlename == "All")) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							}
							dataTableObj = $('#dataTablePart1').DataTable({
								"sorting" : false,
								"searching" : false,
								"paging" : false,
								"info" : false,
								"lengthChange" : false
							});
							tableIterationFlag = false;
						} else {

							$("#dataTablePart1 tbody").empty();
							dataTableObj.clear();
							dataTableObj.destroy();
							/******************************table t2****************************/
							if ((divi == "All" && distname == "" && talname == "" && circlename == "") || (divi == "All" && distname == "All" && talname == "" && circlename == "") || (divi == "All" && distname == "All" && talname == "All" && circlename == "") || (divi == "All" && distname == "All" && talname == "" && circlename == "All")) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							} else if ((distname == "" && talname == "" && circlename == "") || (distname == "All" && talname == "" && circlename == "")) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							} else if ((talname == "" && circlename == "") || (talname == "All" && circlename == "")) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							} else if ((talname != "All" && circlename == "")) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Taluka</b><td style='padding-left: 6%;'>" + talname + "</td></tr>\n\<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							} else if ((talname != "All" && circlename != "All") || (talname == "All" && circlename != "All")) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Taluka</b><td style='padding-left: 6%;'>" + talname + "</td></tr>\n\<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Revenue Circle</b><td style='padding-left: 6%;'>" + circlename + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							} else if (talname != "All" && circlename == "All") {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Taluka</b><td style='padding-left: 6%;'>" + talname + "</td></tr>\n\<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							} else if ((talname == "All" && circlename == "All")) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td  style='padding-left: 6%;width: 54%;'><b>Year</b><td  style='padding-left: 6%;width: 54%;'>" + cropyear + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Season</b><td style='padding-left: 6%;'>" + seasonName + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Crop</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divi + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + totcountarearound + "</td></tr>");
							}

							dataTableObj = $('#dataTablePart1').DataTable({
								"sorting" : false,
								"searching" : false,
								"paging" : false,
								"info" : false,
								"lengthChange" : false
							});
						}

					}));
					// console.log(finalData);
					if (cropnaame == "All") {
						if ((divi == "All" && distname == "" && talname == "" && circlename == "") || (divi == "All" && distname == "All" && talname == "" && circlename == "") || (divi == "All" && distname == "All" && talname == "All" && circlename == "") || (divi == "All" && distname == "All" && talname == "All" && circlename == "All")) {

							gdata = [];
							drillData = [];
							for (var k in divisiondata) {
								if ( typeof divisiondata[k] !== 'function') {
									catarr.push(k);
									arrgraph.push(divisiondata[k]);
								}
								//---------------
								var obj = {};
								var drillID = "";
								drillID = "drill-" + k;
								obj["name"] = k;
								obj['y'] = divisiondata[k];

								obj['drilldown'] = "drill-" + k;
								gdata.push(obj);
								var crops = finalData[k];
								var cropDrillData = [];
								$.each(crops, function(key, data) {
									var tempData = [key, data];
									cropDrillData.push(tempData);
								});
								var drillObj = {
									stack : 'Crop Area',
									showInLegend : true,
									enableMouseTracking : true,

									name : 'Crops',
									dataLabels : {
										enabled : true,
										format : '{point.y:,.2f}'
									},
									tooltip : {
										valueDecimals : 2,
										crosshairs : true,
										shared : true,
										style : {
											fontFamily : 'arial'
										}

									},
									id : drillID,
									data : cropDrillData
								};
								drillData.push(drillObj);
							}
						} else if ((divi != "All" && distname == "" && talname == "" && circlename == "") || (divi != "All" && distname == "All" && talname == "" && circlename == "") || (divi != "All" && distname == "All" && talname == "All" && circlename == "") || (divi != "All" && distname == "All" && talname == "All" && circlename == "All")) {
							//alert("2");
							gdata = [];
							drillData = [];
							for (var k in districtdata) {
								if ( typeof districtdata[k] !== 'function') {
									catarr.push(k);
									arrgraph.push(districtdata[k]);
								}
								//---------------
								var obj = {};
								var drillID = "";
								drillID = "drill-" + k;
								obj["name"] = k;
								obj['y'] = districtdata[k];

								obj['drilldown'] = "drill-" + k;
								gdata.push(obj);
								var crops = finalData[k];
								var cropDrillData = [];
								$.each(crops, function(key, data) {
									var tempData = [key, data];
									cropDrillData.push(tempData);
								});
								var drillObj = {
									stack : 'Crop Area',
									showInLegend : true,
									enableMouseTracking : true,

									name : 'Crops',
									dataLabels : {
										enabled : true,
										format : '{point.y:,.2f}'
									},
									tooltip : {
										valueDecimals : 2,
										crosshairs : true,
										shared : true,
										style : {
											fontFamily : 'arial'
										}

									},
									id : drillID,
									data : cropDrillData
								};
								drillData.push(drillObj);
							}
						} else if ((divi != "All" && distname != "All" && talname == "" && circlename == "") || (divi != "All" && distname != "All" && talname == "All" && circlename == "") || (divi != "All" && distname != "All" && talname == "All" && circlename == "All")) {

							gdata = [];
							drillData = [];
							colorsug = {};
							for (var k in talukadata) {
								if ( typeof talukadata[k] !== 'function') {
									catarr.push(k);
									arrgraph.push(talukadata[k]);
								}
								//---------------
								var obj = {};
								var drillID = "";
								drillID = "drill-" + k;
								obj["name"] = k;
								obj['y'] = talukadata[k];

								obj['drilldown'] = "drill-" + k;
								gdata.push(obj);
								var crops = finalData[k];
								var cropDrillData = [];
								$.each(crops, function(key, data) {
									var tempData = [key, data];

									cropDrillData.push(tempData);

								});
								//console.log(cropDrillData);
								var drillObj = {
									stack : 'Crop Area',
									showInLegend : true,
									enableMouseTracking : true,

									name : 'Crops',
									dataLabels : {
										enabled : true,
										format : '{point.y:,.2f}'
									},
									tooltip : {
										valueDecimals : 2,
										crosshairs : true,
										shared : true,
										style : {
											fontFamily : 'arial'
										}

									},
									id : drillID,
									data : cropDrillData,

								};
								drillData.push(drillObj);

							}
						} else if ((divi != "All" && distname != "All" && talname != "All" && circlename == "") || (divi != "All" && distname != "All" && talname != "All" && circlename == "All") || (divi != "All" && distname != "All" && talname != "All" && circlename != "All")) {
							gdata = [];
							drillData = [];
							for (var k in circledata) {
								if ( typeof circledata[k] !== 'function') {
									catarr.push(k);
									arrgraph.push(circledata[k]);
								}
								//---------------
								var obj = {};
								var drillID = "";
								drillID = "drill-" + k;
								obj["name"] = k;
								obj['y'] = circledata[k];

								obj['drilldown'] = "drill-" + k;
								gdata.push(obj);
								var crops = finalData[k];
								var cropDrillData = [];
								$.each(crops, function(key, data) {
									var tempData = [key, data];
									cropDrillData.push(tempData);

								});
								var drillObj = {
									stack : 'Crop Area',
									showInLegend : true,
									enableMouseTracking : true,

									name : 'Crops',
									dataLabels : {
										enabled : true,
										format : '{point.y:,.2f}'
									},
									tooltip : {
										valueDecimals : 2,
										crosshairs : true,
										shared : true,
										style : {
											fontFamily : 'arial'
										}
									},
									id : drillID,
									data : cropDrillData
								};
								drillData.push(drillObj);

							}
						}

					}
					//------------------------------Graph TGA And Agriculture --------------------------

					var tga = [];
					var aga = [];
					var ca = [];
					$.each(catarr, function(i) {
						if ((divi == "All" && distname == "" && talname == "" && circlename == "") || (divi == "All" && distname == "All" && talname == "" && circlename == "") || (divi == "All" && distname == "All" && talname == "All" && circlename == "") || (divi == "All" && distname == "All" && talname == "All" && circlename == "All")) {

							tga[i] = divisiondataTga[catarr[i]];
							aga[i] = divisiondataAgri[catarr[i]];

						} else if ((divi != "All" && distname == "" && talname == "" && circlename == "") || (divi != "All" && distname == "All" && talname == "" && circlename == "") || (divi != "All" && distname == "All" && talname == "All" && circlename == "") || (divi != "All" && distname == "All" && talname == "All" && circlename == "All")) {

							tga[i] = districtdataTga[catarr[i]];
							aga[i] = districtdataAgri[catarr[i]];

						} else if ((divi != "All" && distname != "All" && talname == "" && circlename == "") || (divi != "All" && distname != "All" && talname == "All" && circlename == "") || (divi != "All" && distname != "All" && talname == "All" && circlename == "All")) {

							tga[i] = talukadataTga[catarr[i]];
							aga[i] = talukadataAgri[catarr[i]];

						} else if ((divi != "All" && distname != "All" && talname != "All" && circlename == "") || (divi != "All" && distname != "All" && talname != "All" && circlename == "All") || (divi != "All" && distname != "All" && talname != "All" && circlename != "All") || (divi != "All" && distname != "All" && talname == "All" && circlename == "All")) {

							tga[i] = circledataTga[catarr[i]];
							aga[i] = circledataAgri[catarr[i]];

						}
					});
					// console.log("-----------Categ data----------");

					if (cropnaame == "All") {

						Highcharts.chart('cropChart', {
							chart : {
								type : 'column',
								height : 220,

							},
							title : {
								text : graphTitle,
							},
							colors : ['#349fa4'],
							credits : {
								enabled : false
							},
							xAxis : {

								type : 'category',
								labels : {
									useHTML : true,
									allowOverlap : true,
									style : {
										fontFamily : 'arial',
										fontSize : '8pt',
										fontWeight : 'bold',
										wordBreak : 'break-all',
										textOverflow : 'allow'
									}
								},
								crosshairs : true,
								categories : catarr
							},
							yAxis : {
								title : {
									text : 'Sown Area (Ha)',
									style : {
										fontFamily : 'arial',
										fontWeight : 'bold',
										fontSize : '10pt',
									}
								},

							},

							legend : {
								/*layout : 'horizontal',
								 itemMarginTop : 0,
								 margin : 0,
								 padding : 0*/
								align : 'right',
								x : -30,
								verticalAlign : 'top',
								y : -10,
								floating : true,
								backgroundColor : Highcharts.defaultOptions.legend.backgroundColor || 'transparent',
								borderColor : '#CCC',
								borderWidth : 1,
								shadow : false,
								itemStyle : {
									fontFamily : 'arial',
									fontSize : '9pt'
								},
								symbolRadius : 0

							},

							tooltip : {
								enabled : true,
								shared : true,
								valueDecimals : 2,
								style : {
									fontFamily : 'arial'
								}
								// headerFormat : '<b>{point.x}</b><hr><br/>',
								//pointFormat : '<span style="color:{point.color}">\u25CF</span> {series.name}: <b>{point.percentage:.1f} %</b><br/>'

							},
							plotOptions : {
								series : {
									pointWidth : 10,
									stacking : 'normal',
									borderWidth : 0,
									dataLabels : {
										inside : false,
										enabled : false,
									},
									animation : {
										enabled : true,
										duration : 400,
										easing : 'linear'
									}

								}
							},
							series : [{
								stack : 'Total Crop Area',
								name : 'Total Crop Area',
								data : gdata

							}],
						});
					}

				}

			});

		},

		ViewReport : function() {
			debugger;
			dom.byId("divLoadingIndicator").style.display = 'block';
			var year = document.getElementById("year").value;
			var season = document.getElementById("seasonSelect").value;
			var division = document.getElementById("division").value;
			var district = document.getElementById("district").value;
			var taluka = document.getElementById("taluka").value;
			var circle = document.getElementById("circle").value;

			if (year === "" || season === "" || division === "") {
				swal("Please select proper input");
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});
				map.basemap = "topo";
				view.graphics.removeAll();
				dom.byId("print").style.display = 'none';
				map.add(featureLayer);
				map.add(noncropmask);
				dom.byId("divLoadingIndicator").style.display = 'none';
			} else {

				for (var i = 0; i < zoneGetcropchange.length; i++) {
					if (zoneGetcropchange[i].name === division) {
						dvncode = zoneGetcropchange[i].code;
					}
				}
				for (var i = 0; i < zoneGetdivchange.length; i++) {
					if (zoneGetdivchange[i].name === district) {
						dtncode = zoneGetdivchange[i].code;
					}
				}
				for (var i = 0; i < zoneGetdistchange.length; i++) {
					if (zoneGetdistchange[i].name === taluka) {
						talcode = zoneGetdistchange[i].code;
					}
				}

				for (var i = 0; i < zoneGettalchange.length; i++) {
					if (zoneGettalchange[i].name === cirname) {
						circleCode = zoneGettalchange[i].code;
					}
				}

				if (document.getElementById("district").value === "") {
					dtncode = "All";
					district = "All";
				}

				if (document.getElementById("taluka").value === "") {
					talcode = "All";
					taluka = "All";
				}
				if (document.getElementById("circle").value === "") {
					circleCode = "All";
					circle = "All";
				}

				document.getElementById("mainContent").style.display = "block";

				$("#mainContent").load("http://117.240.213.118:6080/cropacreagereport1/acreagestathtml?division=" + dvncode + "&district=" + dtncode + "&taluka=" + talcode + "&season=" + season + "&circle=" + circleCode + "&division_n=" + division + "&district_n=" + district + "&taluka_n=" + taluka + "&circle_n=" + circle + "&year=" + year, function() {

					//alert("Load was performed.");
					$('#datatable').DataTable();
					dom.byId("divLoadingIndicator").style.display = 'none';
				});

			}

		},

		generatemap : function() {

			dom.byId("divLoadingIndicator").style.display = 'block';

			var year = document.getElementById("year").value;
			var season = document.getElementById("seasonSelect").value;
			var division = document.getElementById("division").value;
			var district = document.getElementById("district").value;
			var taluka = document.getElementById("taluka").value;
			var cirname = document.getElementById("circle").value;

			for (var i = 0; i < zoneGetcropchange.length; i++) {
				if (zoneGetcropchange[i].name === division) {
					dvncode = zoneGetcropchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === district) {
					dtncode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === taluka) {
					talcode = zoneGetdistchange[i].code;
				}
			}

			for (var i = 0; i < zoneGettalchange.length; i++) {
				if (zoneGettalchange[i].name === cirname) {
					circleCode = zoneGettalchange[i].code;
				}
			}

			if (document.getElementById("district").value === "") {
				dtncode = "All";
			}

			if (document.getElementById("taluka").value === "") {
				talcode = "All";
			}

			if (document.getElementById("circle").value === "") {
				circleCode = "All";
			}

			var gpUrl = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/cropaceragetemplate/GPServer/cropacreagetemplate";
			var gp = new Geoprocessor(gpUrl);
			var parameters = {
				"season" : season,
				"div_cd" : dvncode,
				"division" : division,
				"dist_cd" : dtncode,
				"district" : district,
				"tal_cd" : talcode,
				"taluka" : taluka,
				"cir_cd" : circleCode,
				"circle" : cirname,
				"year" : year
			};

			console.log(parameters);
			gp.execute(parameters).then(ShowResultData);
			// gp.submitJob(params).then(function(jobInfo) {
			// debugger;
			// v jobid = jobInfo.jobId;
			//
			// let options = {
			// interval: 1500,
			// statusCallback: function(j) {
			// console.log("Job Status: ", j.jobStatus);
			// }
			// };
			//
			// geoprocessor.waitForJobCompletion(jobid, options).then(function() {
			// let layer = geoprocessor.getResultMapImageLayer(jobid);
			// map.add(layer);
			// });

			function ShowResultData(result) {
				// alert(result);
				console.log(result.results[0].value);
				var resultImg = result.results[0].value.url;
				var center_left = (screen.width / 2.5) - (400 / 2);
				var center_top = (screen.height / 2.5) - (400 / 2);
				window.open(resultImg, target = '_blank', 'width=1000,height=750, top=' + center_top + ', left=' + center_left);
				dom.byId("divLoadingIndicator").style.display = 'none';
			}

		},
	});
});
