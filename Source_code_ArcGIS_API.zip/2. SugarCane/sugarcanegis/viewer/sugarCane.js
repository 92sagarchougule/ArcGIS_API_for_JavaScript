/**
 * @author prachi
 */
define(["dojo/Deferred", "dojo/_base/declare", "dijit/registry", "dijit/_WidgetBase", "dijit/_TemplatedMixin", "dojo/text!./templates/sugarCane.html", "dojo/_base/window", "dijit/_WidgetsInTemplateMixin", "dijit/layout/AccordionContainer", "esri/Map", "esri/views/MapView", "esri/widgets/Expand", "esri/layers/KMLLayer", "esri/geometry/geometryEngine", "esri/layers/Layer", "esri/WebMap", "esri/widgets/Search", "esri/Basemap", "esri/widgets/Locate", "esri/widgets/Track", "esri/Graphic", "esri/widgets/Compass", "esri/layers/MapImageLayer", "esri/widgets/CoordinateConversion", "esri/tasks/Geoprocessor", "dijit/Tooltip", "esri/tasks/support/RelationshipQuery", "esri/tasks/Locator", "esri/widgets/Home", "esri/widgets/BasemapToggle", "esri/widgets/Swipe", "esri/widgets/ScaleBar", "esri/geometry/Extent", "dojo/_base/lang", "dojo/topic", "esri/config", "esri/identity/ServerInfo", "esri/identity/IdentityManager", "esri/layers/FeatureLayer", "esri/tasks/support/FeatureSet", "esri/layers/ImageryLayer", "esri/layers/MapImageLayer", "esri/tasks/ClosestFacilityTask", "esri/tasks/support/ClosestFacilityParameters", "dojo/_base/array", "dojo/on", "dojo/dom", "dojo/dom-construct", "dojo/dom-style", "dojo/dom-attr", "dojo/dom-class", "esri/symbols/PictureMarkerSymbol", "esri/renderers/SimpleRenderer", "esri/symbols/SimpleMarkerSymbol", "esri/Graphic", "esri/widgets/Popup", "esri/PopupTemplate", "dijit/TooltipDialog", "esri/core/lang", "esri/tasks/QueryTask", "esri/tasks/support/Query", "dojo/query", "dojo/store/Memory", "dijit/form/ComboBox", "dijit/form/DateTextBox", "dojo/data/ItemFileReadStore", "dijit/form/Select", "dijit/form/FilteringSelect", "esri/layers/GraphicsLayer", "esri/widgets/Sketch", "esri/geometry/Point", "esri/geometry/Circle", "esri/geometry/SpatialReference", "esri/symbols/SimpleLineSymbol", "esri/symbols/SimpleFillSymbol", "esri/Color", "esri/Graphic", "esri/request", "dojo/dom-style", "esri/widgets/Legend", "esri/tasks/FindTask", "dojo/request/xhr", 'dojo/data/ObjectStore', "dojo/request", "dojo/number", "dijit/layout/BorderContainer", "dijit/layout/TabContainer", "dijit/layout/ContentPane", "dijit/TitlePane", "dijit/form/Form", "esri/widgets/BasemapGallery", "dijit/form/TextBox", "dijit/Dialog", "dijit/form/CheckBox", "dijit/form/RadioButton", "dijit/Menu", "esri/layers/ImageryLayer", "esri/layers/support/RasterFunction", "esri/layers/support/DimensionalDefinition", "esri/layers/support/MosaicRule", "dijit/MenuItem", "dijit/layout/ContentPane", "dijit/Toolbar", "dijit/form/Button", "dojox/widget/TitleGroup", "esri/core/urlUtils", "dojo/_base/json", "dojo/domReady!"], function(Deferred, declare, registry, _WidgetBase, _TemplatedMixin, template, win, _WidgetsInTemplateMixin, AccordionContainer, Map, MapView, Expand, KMLLayer, geometryEngine, Layer, WebMap, Search, Basemap, Locate, Track, Graphic, Compass, MapImageLayer, CoordinateConversion, Geoprocessor, Tooltip, RelationshipQuery, Locator, Home, BasemapToggle, Swipe, ScaleBar, Extent, lang, topic, esriConfig, ServerInfo, esriId, FeatureLayer, FeatureSet, ImageryLayer, MapImageLayer, ClosestFacilityTask, ClosestFacilityParameters, array, on, dom, domConstruct, domStyle, domAttr, domClass, PictureMarkerSymbol, SimpleRenderer, SimpleMarkerSymbol, Graphic, Popup, PopupTemplate, TooltipDialog, esriLang, QueryTask, Query, query, Memory, ComboBox, DateTextBox, ItemFileReadStore, FilteringSelect, Select, GraphicsLayer, Sketch, Point, Circle, SpatialReference, SimpleLineSymbol, SimpleFillSymbol, Color, Graphic, esriRequest, domStyle, Legend, FindTask, xhr, ObjectStore, request, number, BorderContainer, TabContainer, ContentPane, TitlePane, Form, BasemapGallery, TextBox, Dialog, CheckBox, RadioButton, Menu, ImageryLayer, RasterFunction, DimensionalDefinition, MosaicRule, urlUtils, MenuItem, json) {
	return declare("mrsac.viewer.sugarCane", [_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {

		constructor : function() {
			valueOther = [];
			valuesRabi = [];
			otherCrop1 = [];
			circleCodeArray = [];
			zoneGetcropchange = [];
			zoneGetdivchange = [];
			zoneGetdistchange = [];
			zoneGettalchange = [];

			//-----------Kharif total sown---------
			zFKhdivchange = [];
			zFKhdistchange = [];
			agriArrayPrint = [];
			zF = [];
			tableIterationFlag = true;
			dataTableObj = null;
			tableIterationFlag2 = true;
			dataTableObj2 = null;
			othersstat = [],
			// val = [],
			totcirareacount = 0;
			totcountarearound = 0;
			graphTitle = "";
			finalData = [];

		},
		currentTab : "horticulture",
		agriarea : null,
		ringgeom : null,
		queryZm : null,
		contextMenu : null,
		queryUsedFurther : null,
		remapRFnoncrp : null,
		resultAgriLandUseArea : null,
		// othersstat : "",
		templateString : template,
		postMixInProperties : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				alert("err" + err);
				console.error(err);
			}
		},
		postCreate : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				console.error(err);
			}
		},
		startup : function() {
			if (this._started) {

				return;
			}
			try {

				//--------services  used-------------
				this.state = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/0";
				this.division = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/1";
				this.district = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/2";
				this.taluka = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/3";

				this.othersstat = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/acerage_statistics/MapServer/1";

				//-----------------sugarcane stat---------------
				debugger;

				// function asyncProcess() {
					// var deferred = new Deferred();

					// dom.byId("output").innerHTML = "I'm running...";
					// var url = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/acerage_statistics/MapServer?f=pjson";
					// " /MapServer?f=pjson";
					// esriRequest(url, {
						// responseType : "json"
					// }).then(function(response) {
						// // The requested data
						// var geoJson = response.data;
						// var layersArray = geoJson.tables;
						// // console.log(layersArray);
						// array.forEach(layersArray, lang.hitch(this, function(LayerAll) {
							// // console.log(LayerAll.name);
							// // console.log(LayerAll.id);
							// if (LayerAll.name == "sugarcane_cropwise") {
								// idDistLyr = LayerAll.id;
								// x = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/acerage_statistics/MapServer/" + idDistLyr;
								// othersstat.push(x);
								// console.log(othersstat[0]);
							// }
						// }));
					// });
					// // alert();
					// console.log(othersstat);

					// setTimeout(function() {
						// deferred.resolve(othersstat);
					// }, 1000);
// 
					// return deferred.promise;
				// }
// 
				// // var process = asyncProcess();
// 				
				// when(asyncProcess());
// 
				// console.log(process);
				// process.then(function(results) {
					// console.log(results[0]);
				// });

				featureLayer = new MapImageLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
					outFields : ["*"],
					mode : FeatureLayer.MODE_ONDEMAND,
				});
				map.add(featureLayer);

				noncropmask = new ImageryLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/noncropmask_2019/ImageServer",
					opacity : 0.3,
					id : "noncropmaskId"

				});
				map.add(noncropmask);

				this.getSeasonChange();

			} catch (err) {
				console.error("SearchWidget::startup", err);

			}

		},

		getSeasonChange : function() {
			debugger;

			var testVals = {};
			document.getElementById("years").value = " ";
			document.getElementById("divisions").value = " ";
			document.getElementById("districts").value = " ";
			document.getElementById("talukas").value = " ";
			// document.getElementById("circles").value = " ";

			// year = document.getElementById("yearh").value;
			// seasonName = document.getElementById("seasonSelects").value;
			selectcropx = document.getElementById("years");
			// selectseason = document.getElementById("seasonSelecth");

			queryTaskYearSown = new QueryTask(this.othersstat);
			var queryYear = new Query();
			queryYear.outFields = ["crop_year", "crop_code"];
			queryYear.returnGeometry = false;
			queryYear.returnDistinctValues = true;
			queryYear.where = "1=1";

			queryTaskYearSown.execute(queryYear).then(function(featureset) {

				var result = featureset.features;

				array.forEach(result, lang.hitch(this, function(value) {

					cropyear = value.attributes.crop_year;
					cropcode = value.attributes.crop_code;
					if (cropyear) {
						if (!testVals[cropyear]) {
							testVals[cropyear] = true;
							otherCrop1.push({
								name : cropyear,
								code : cropcode
							});
						}
					}
				}));

				// otherCrop1.sort();

				otherCrop1.sort(function(a, b) {
					return a - b
				});

				otherCrop1.sort(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});

				// console.log(otherCrop1);
				// otherCrop1.reverse();
				// otherCrop.push({
				// name : "All",
				// code : "All"
				// });

				testValsn = {};

				array.forEach(otherCrop1, lang.hitch(this, function(vals) {
					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;
							// if(vals.name ===  "Unconfirmed Orchard"){
							// vals.name === "";
							// console.log(vals.name);
							// }
							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectcropx.add(option, 0);
						}
					}
				}));
				document.getElementById("years").value = "";

			});
		},
		getdivision : function() {
			debugger;
			//******************Division Populate*****************
			//cropyear = document.getElementById("yearh").value;
			cropyear = document.getElementById("years").value;

			document.getElementById("districts").value = " ";
			document.getElementById("talukas").value = " ";
			// document.getElementById("circles").value = " ";

			//===========Division Name in Setence Case================
			function upperCaseFirstLetter(string) {
				return string.charAt(0).toUpperCase() + string.slice(1);
			}

			function lowerCaseAllWordsExceptFirstLetters(string) {
				return string.replace(/\w\S*/g, function(word) {
					return word.charAt(0) + word.slice(1).toLowerCase();
				});
			}

			//if (seasonName === 'Others') {
			// for (var i = 0; i < otherCrop1.length; i++) {
			// if (otherCrop1[i].name === cropname) {
			// cropCode = otherCrop1[i].code;
			// }
			// }
			//}

			var cropCode = "SU01";

			zoneGetcropchange = [];
			var values = [];
			var testVals = {};

			selectDiv = document.getElementById("divisions");
			// if (seasonName === 'Others') {
			while (selectDiv.firstChild) {
				selectDiv.removeChild(selectDiv.firstChild);
			}
			queryTaskdiv = new QueryTask(this.othersstat);

			// }
			var query = new Query();
			query.outFields = ["advename", "advncode"];
			query.returnGeometry = false;
			query.returnDistinctValues = true;
			if (cropyear === "All") {
				query.where = "crop_code <> '' ";
			} else {
				query.where = "crop_year  = '" + cropyear + "' and crop_code = '" + cropCode + "'";
			}
			// console.log(query.where);
			queryTaskdiv.execute(query).then(function(featureset) {

				var result = featureset.features;
				array.forEach(result, lang.hitch(this, function(value) {

					div_name = value.attributes.advename;
					div_code = value.attributes.advncode;
					//division_name = upperCaseFirstLetter(lowerCaseAllWordsExceptFirstLetters(div_name));
					if (div_name) {
						if (!testVals[div_name]) {
							testVals[div_name] = true;
							zoneGetcropchange.push({
								name : div_name,
								code : div_code
							});
						}
					}
				}));
				if (zoneGetcropchange.length == 0) {
					swal("Data not available");
				} else {
					zoneGetcropchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetcropchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});

					zoneGetcropchange.push({
						name : "All",
						code : "All"
					});

					testValsn = {};

					array.forEach(zoneGetcropchange, lang.hitch(this, function(vals) {

						if (vals.name) {
							if (!testValsn[vals.name]) {
								testValsn[vals.name] = true;

								var option = document.createElement('option');
								option.text = option.value = vals.name;
								selectDiv.add(option, 0);
							}
						}
					}));
					document.getElementById("divisions").value = "";
				}

			});

		},
		getdivchange : function() {
			//******************District Populate*****************
			//cropyear = document.getElementById("yearh").value;
			cropyear = document.getElementById("years").value;
			divi = document.getElementById("divisions").value;
			document.getElementById("talukas").value = "";
			//dvename = divi.toUpperCase();

			// for (var i = 0; i < otherCrop1.length; i++) {
			// if (otherCrop1[i].name === cropname) {
			// cropCode = otherCrop1[i].code;
			// }
			// }

			var cropCode = "SU01";

			function upperCaseFirstLetter(string) {
				return string.charAt(0).toUpperCase() + string.slice(1);
			}

			function lowerCaseAllWordsExceptFirstLetters(string) {
				return string.replace(/\w\S*/g, function(word) {
					return word.charAt(0) + word.slice(1).toLowerCase();
				});
			}

			dvename = upperCaseFirstLetter(lowerCaseAllWordsExceptFirstLetters(divi));

			zoneGetdivchange = [];
			// this.removeLayersWithId();
			view.graphics.removeAll();
			var values = [];
			var testVals = {};

			if (divi == "All") {
				var queryTaskZm = new QueryTask({
					url : this.state
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "STENAME = 'Maharashtra'";

				stateLayer = new FeatureLayer({
					url : this.state,
					id : "stateLayerDisplay"
				});
				stateLayer.definitionExpression = queryZm.where;
				map.add(stateLayer);

			} else if (divi != "All") {
				var queryTaskZm = new QueryTask({
					url : this.division
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "ADVENAME  = '" + dvename + "'";
				divisionLayer = new FeatureLayer({
					url : this.division,
					id : "diviLayerDisplay"
				});
				divisionLayer.definitionExpression = queryZm.where;
				map.add(divisionLayer);

			}
			// console.log(queryZm.where);

			queryTaskZm.execute(queryZm).then(function(results) {
				//alert();
				// console.log(results);
				var result_features = results.features;
				// console.log(result_features);
				array.forEach(result_features, lang.hitch(this, function(value) {

					bufgeometry = value.geometry;
					// console.log(value);
					zF.push(value);

					var symbol = {
						type : "simple-line",
						color : "black",
						width : "2px",
						style : "solid"
					};
					var districtGraphic = new Graphic(value.geometry, symbol);
					view.graphics.add(districtGraphic, 0);
					ringgeom = value.geometry.rings;

				}));

			});

			selectDist = document.getElementById("districts");
			// if (seasonName === 'Others') {
			while (selectDist.firstChild) {
				selectDist.removeChild(selectDist.firstChild);
			}
			queryTaskdist = new QueryTask(this.othersstat);

			// }

			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["dtename", "dtncode"];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.returnDistinctValues = true;
			if (cropyear == "All" && divi == "All") {
				queryUsedFurther.where = "crop_code <> '' and advename <> ''";
			} else if (cropyear == "All" && divi != "All") {
				queryUsedFurther.where = "crop_code <> '' and advename = '" + divi + "' ";
			} else if (cropyear != "All" && divi == "All") {
				queryUsedFurther.where = "crop_year  = '" + cropyear + "' and crop_code = '" + cropCode + "' and advename <> '' ";
			} else if (cropyear != "All" && divi != "All") {
				queryUsedFurther.where = "crop_year  = '" + cropyear + "' and crop_code = '" + cropCode + "' and advename = '" + divi + "' ";
			}
			// console.log(queryUsedFurther.where);
			queryTaskdist.execute(queryUsedFurther).then(function(featureset) {

				var result = featureset.features;
				if (divi != "All") {
					array.forEach(result, lang.hitch(this, function(value) {
						dis_name = value.attributes.dtename;
						dist_code = value.attributes.dtncode;
						if (dis_name) {
							if (!testVals[dis_name]) {
								testVals[dis_name] = true;
								zoneGetdivchange.push({
									name : dis_name,
									code : dist_code,
								});
							};
						}
					}));

					zoneGetdivchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});

					zoneGetdivchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdivchange.push({
						name : "All",
						code : "All"
					});
				}

				testValsn = {};

				array.forEach(zoneGetdivchange, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectDist.add(option, 0);
						}
					}
				}));
				document.getElementById("districts").value = "";
			});
			// map.basemap = "";
		},
		getdistchange : function() {
			distname = document.getElementById("districts").value;
			talname = document.getElementById("talukas").value;
			//cropyear = document.getElementById("yearh").value;
			divi = document.getElementById("divisions").value;
			cropyear = document.getElementById("years").value;
			document.getElementById("talukas").value = " ";
			// document.getElementById("circles").value = " ";
			//dvename = divi.toUpperCase();

			// for (var i = 0; i < otherCrop1.length; i++) {
			// if (otherCrop1[i].name === cropname) {
			// cropCode = otherCrop1[i].code;
			// }
			// }

			var cropCode = "SU01";

			//===========Division Name in Sentence Case================
			function upperCaseFirstLetter(string) {
				return string.charAt(0).toUpperCase() + string.slice(1);
			}

			function lowerCaseAllWordsExceptFirstLetters(string) {
				return string.replace(/\w\S*/g, function(word) {
					return word.charAt(0) + word.slice(1).toLowerCase();
				});
			}

			division = upperCaseFirstLetter(lowerCaseAllWordsExceptFirstLetters(divi));
			//========================================================
			// this.removeLayersWithId();
			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					distrcitCode = zoneGetdivchange[i].code;
				}
			}
			view.graphics.removeAll();

			zoneGetdistchange = [];
			var testVals = {};
			zF = [];
			var district_LayerUrlZm = this.district;
			if ((division == "All" && distname == "All" && talname == "") || (division == "All" && distname == "" && talname == "")) {
				var queryTaskZm = new QueryTask({
					url : this.state
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "STENAME = 'Maharashtra'";

				stateLayer = new FeatureLayer({
					url : this.state,
					id : "stateLayerDisplay"
				});
				stateLayer.definitionExpression = queryZm.where;
				map.add(stateLayer);

			} else if ((division == "All" && distname != "All") || (division != "All" && distname != "All")) {
				var queryTaskZm = new QueryTask({
					url : district_LayerUrlZm
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "'";

				//----------------------Get Crop Layers All-----------
				distLayer = new FeatureLayer({
					url : this.district,
					id : "distLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);

			} else if (division != "All" && distname == "All") {
				var queryTaskZm = new QueryTask({
					url : this.division
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "ADVENAME = '" + divi + "'";

				divisionLayer = new FeatureLayer({
					url : this.division,
					id : "diviLayerDisplay"
				});
				divisionLayer.definitionExpression = queryZm.where;
				map.add(divisionLayer);
			}
			// console.log(queryZm.where);
			queryTaskZm.execute(queryZm).then(function(results) {

				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {

					bufgeometry = value.geometry;
					zF.push(value);
					var symbol = {
						type : "simple-line", // autocasts as new SimpleLineSymbol()
						color : "black",
						width : "2px",
						style : "solid"
					};
					var districtGraphic = new Graphic(value.geometry, symbol);
					view.graphics.add(districtGraphic, 0);
					// view.goTo(zF);
					geomextent = value.geometry.extent;

					ringgeom = value.geometry.rings;
					areageom = value.geometry;
					// this.noncropMaskClip();
				}));

			});

			//this.pixelfilter();

			selecttal = document.getElementById("talukas");
			// if (seasonName === 'Others') {
			while (selecttal.firstChild) {
				selecttal.removeChild(selecttal.firstChild);
			}

			debugger;
			queryTasktal = new QueryTask(this.othersstat);
			// }

			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["thename", "thncode"];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.outSpatialReference = {
				"wkid" : 102100
			};
			queryUsedFurther.returnDistinctValues = true;

			if (cropyear == 'All' && divi == 'All' && distname == 'All') {
				queryUsedFurther.where = "crop_code <> '' and advename <> '' ";
			} else if (cropyear == 'All' && divi != 'All' && distname != 'All') {
				queryUsedFurther.where = "crop_code <> '' and advename = '" + divi + "' and dtename = '" + distname + "' ";
			} else if (cropyear == 'All' && divi != 'All' && distname == 'All') {
				queryUsedFurther.where = "crop_code <> '' and advename = '" + divi + "' and dtename <> '' ";
			} else if (cropyear != 'All' && divi == 'All' && distname == 'All') {
				queryUsedFurther.where = "crop_year  = '" + cropyear + "' and crop_code = '" + cropCode + "' and advename <> '' ";
			} else if (cropyear != 'All' && divi != 'All' && distname == 'All') {
				queryUsedFurther.where = "crop_year  = '" + cropyear + "' and crop_code = '" + cropCode + "' and advename = '" + divi + "' and dtename <> '' ";
			} else if (cropyear != 'All' && divi != 'All' && distname != 'All') {
				queryUsedFurther.where = "crop_year  = '" + cropyear + "' and crop_code = '" + cropCode + "' and advename = '" + divi + "' and dtename = '" + distname + "' ";
			}
			// console.log(queryUsedFurther.where);
			queryTasktal.execute(queryUsedFurther).then(function(featureset) {

				var result = featureset.features;
				if (distname != "All") {
					array.forEach(result, lang.hitch(this, function(value) {

						tal_name = value.attributes.thename;
						tal_code = value.attributes.thncode;
						if (tal_name) {
							if (!testVals[tal_name]) {
								testVals[tal_name] = true;
								zoneGetdistchange.push({
									name : tal_name,
									code : tal_code
								});
							}
						}
					}));

					zoneGetdistchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.push({
						name : "All",
						code : "All"
					});
				} else if (distname == "All") {
					zoneGetdistchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGetdistchange.push({
						name : "All",
						code : "All"
					});
				}

				testValsn = {};

				array.forEach(zoneGetdistchange, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selecttal.add(option, 0);
						}
					}
				}));
				document.getElementById("talukas").value = "";

			});
			// map.basemap = "";

		},
		gettalchange : function() {
			debugger;
			divi = document.getElementById("divisions").value;
			distname = document.getElementById("districts").value;
			talname = document.getElementById("talukas").value;
			//cropyear = document.getElementById("yearh").value;
			cropyear = document.getElementById("years").value;
			// document.getElementById("circles").value = " ";
			divname = divi.toUpperCase();

			var values = [];
			zoneGettalchange = [];
			var testVals = {};
			zF = [];
			view.graphics.removeAll();

			// this.removeLayersWithId();
			// for (var i = 0; i < otherCrop1.length; i++) {
			// if (otherCrop1[i].name === cropname) {
			// cropCode = otherCrop1[i].code;
			// }
			// }

			var cropCode = "SU01";

			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					distrcitCode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talukaCode = zoneGetdistchange[i].code;
				}
			}
			if (divi == "All" && distname == "All" && talname == "All") {
				var queryTaskZm = new QueryTask({
					url : this.state
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "STENAME = 'Maharashtra'";
				stateLayer = new FeatureLayer({
					url : this.state,
					id : "stateLayerDisplay"
				});
				stateLayer.definitionExpression = queryZm.where;
				map.add(stateLayer);
			} else if ((divi != "All" && distname == "All" && talname == "All")) {
				var queryTaskZm = new QueryTask({
					url : this.division
				});

				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "ADVENAME = '" + divi + "'";
				distLayer = new FeatureLayer({
					url : this.district,
					id : "distalLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);

			} else if ((divi != "All" && distname != "All" && talname == "All")) {
				var district_LayerUrlZm = this.district;

				var queryTaskZm = new QueryTask({
					url : district_LayerUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};

				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "'";

				distLayer = new FeatureLayer({
					url : this.district,
					id : "distalLayerDisplay"
				});
				distLayer.definitionExpression = queryZm.where;
				map.add(distLayer);
			} else if ((divi != "All" && distname != "All" && talname != "All")) {
				var taluka_LayerUrlZm = this.taluka;
				var queryTaskZm = new QueryTask({
					url : taluka_LayerUrlZm
				});
				var queryZm = new Query();
				queryZm.returnGeometry = true;
				queryZm.outSpatialReference = {
					wkid : 102100
				};
				queryZm.outFields = ["*"];
				queryZm.where = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";

				talLayer = new FeatureLayer({
					url : this.taluka,
					id : "talLayerDisplay"
				});
				talLayer.definitionExpression = queryZm.where;
				map.add(talLayer);

			}
			// console.log(queryZm.where);
			queryTaskZm.execute(queryZm).then(function(results) {
				var result_features = results.features;
				array.forEach(result_features, lang.hitch(this, function(value) {
					bufgeometry = value.geometry;
					zF.push(value);
					var symbol = {
						type : "simple-line", // autocasts as new SimpleLineSymbol()
						color : "black",
						width : "2px",
						style : "solid"
					};
					var districtGraphic = new Graphic(value.geometry, symbol);
					view.graphics.add(districtGraphic, 0);
					// view.goTo(zF);
					geomextent = value.geometry.extent;
					ringgeom = value.geometry.rings;
					areageom = value.geometry;

				}));

			});

			// this.pixelfilter()

			//-----------------------circle poppulate----------------------
			// selectcir = document.getElementById("circles");

			// if (seasonName === 'Others') {
			// while (selectcir.firstChild) {
			// selectcir.removeChild(selectcir.firstChild);
			// }
			queryTaskcir = new QueryTask(this.othersstat);
			// }

			queryUsedFurther = new Query();
			queryUsedFurther.outFields = ["cirname", "circode"];
			queryUsedFurther.returnGeometry = false;
			queryUsedFurther.outSpatialReference = {
				"wkid" : 102100
			};
			queryUsedFurther.returnDistinctValues = true;

			if (cropyear == 'All' && divi == 'All' && distname == 'All' && talname == 'All') {
				queryUsedFurther.where = "crop_code <> '' and advename <> '' ";
			} else if (cropyear == 'All' && divi != 'All' && distname == 'All' && talname == 'All') {
				queryUsedFurther.where = "crop_code <> '' and advename ='" + divi + "' ";
			} else if (cropyear == 'All' && divi != 'All' && distname != 'All' && talname == 'All') {
				queryUsedFurther.where = "crop_code <> '' and advename ='" + divi + "' and dtename = '" + distname + "' ";
			} else if (cropyear == 'All' && divi != 'All' && distname != 'All' && talname != 'All') {
				queryUsedFurther.where = "crop_code <> '' and advename ='" + divi + "' and dtename = '" + distname + "' and  thename ='" + talname + "' ";
			} else if (cropyear != 'All' && divi == 'All' && distname == 'All' && talname == 'All') {
				queryUsedFurther.where = "crop_year  = '" + cropyear + "' and crop_code ='" + cropCode + "' and advename <> '' ";
			} else if (cropyear != 'All' && divi != 'All' && distname == 'All' && talname == 'All') {
				queryUsedFurther.where = "crop_year  = '" + cropyear + "' and crop_code ='" + cropCode + "' and advename ='" + divi + "' ";
			} else if (cropyear != 'All' && divi != 'All' && distname != 'All' && talname == 'All') {
				queryUsedFurther.where = "crop_year  = '" + cropyear + "' and crop_code ='" + cropCode + "' and advename ='" + divi + "' and dtename = '" + distname + "' ";
			} else if (cropyear != 'All' && divi != 'All' && distname != 'All' && talname != 'All') {
				queryUsedFurther.where = "crop_year  = '" + cropyear + "' and crop_code ='" + cropCode + "' and advename ='" + divi + "' and dtename = '" + distname + "' and  thename ='" + talname + "' ";
			}
			// console.log(queryUsedFurther.where);
			queryTaskcir.execute(queryUsedFurther).then(function(featureset) {
				// alert();
				// console.log(featureset);
				// debugger;
				var result = featureset.features;
				if (talname != "All") {
					array.forEach(result, lang.hitch(this, function(value) {
						// console.log(value);
						circlename = value.attributes.cirname;
						circlecode = value.attributes.circode;
						areaha = value.attributes.acreage_area;
						if (circlename) {
							if (!testVals[circlename]) {
								testVals[circlename] = true;
								zoneGettalchange.push({
									name : circlename,
									code : circlecode,
									area : areaha
								});
							}
						}
					}));
					zoneGettalchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGettalchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					// zoneGettalchange.push({
					// name : "All",
					// code : "All",
					// area : "All"
					// });
				} else if (talname == "All") {
					zoneGettalchange.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zoneGettalchange.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					// zoneGettalchange.push({
					// name : "All",
					// code : "All",
					// area : "All"
					// });
				}

				// testValsn = {};
				// array.forEach(zoneGettalchange, lang.hitch(this, function(vals) {
				// // alert();
				// if (vals.name) {
				// if (!testValsn[vals.name]) {
				// testValsn[vals.name] = true;
				//
				// var option = document.createElement('option');
				// option.text = option.value = vals.name;
				// selectcir.add(option, 0);
				// }
				// }
				// }));
				// document.getElementById("circles").value = "";

			});
			// map.basemap = "";

		},

		clearbutton : function() {
			// alert();
			debugger;
			view.graphics.removeAll();
			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.basemap = "topo";

			map.remove(layer);
			document.getElementById("divisions").value = "";
			document.getElementById("districts").value = "";
			document.getElementById("talukas").value = " ";
			// document.getElementById("circle").value = " ";
			document.getElementById("years").value = " ";
			// dom.byId("viewDiv").style.height = '95%';
			dom.byId("cropSownCharts").style.display = 'none';
			dom.byId("mainContent").style.display = 'none';
			dom.byId("legend").style.display = 'none';
			dom.byId("legend1").style.display = 'none';

			map.add(featureLayer);
			noncropmask = new ImageryLayer({
				url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/noncropmask_2019/ImageServer",
				opacity : 0.3,
				id : "noncropmaskId"

			});
			map.add(noncropmask);

		},
		submitbtn : function() {
			// debugger;
			dom.byId("divLoadingIndicator").style.display = 'block';
			dom.byId("tablinks").classList.add("active");
			// dom.byId("tablinks1").classList.remove("active");
			// dom.byId("tablinks2").classList.remove("active");

			document.getElementById("mainContent").style.display = "none";
			document.getElementById("sugarcane").style.display = "block";
			dom.byId("print").style.display = 'block';
			dom.byId("legend1").style.display = 'block';
			dom.byId("legend").style.display = 'block';

			// map.basemap = "";
			map.removeAll(featureLayer);

			// ----------------------Raster Layer display with geometry----------------------
			divname = document.getElementById("divisions").value;
			distname = document.getElementById("districts").value;
			talname = document.getElementById("talukas").value;
			// cirname = document.getElementById("circle").value;
			cropnaame = document.getElementById("years").value;

			// for (var i = 0; i < otherCrop1.length; i++) {
			// if (otherCrop1[i].name === cropname) {
			// cropCode = otherCrop1[i].code;
			// }
			// }

			var cropCode = "SU01";

			for (var i = 0; i < zoneGetcropchange.length; i++) {
				if (zoneGetcropchange[i].name === divi) {
					dvncode = zoneGetcropchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					distrcitCode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talukaCode = zoneGetdistchange[i].code;
				}
			}

			if (cropnaame === "" || divname === "") {
				swal("Please Select Proper input");
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});
				map.basemap = "topo";
				view.graphics.removeAll();
				dom.byId("legend").style.display = 'none';
				dom.byId("legend1").style.display = 'none';
				map.add(featureLayer);
				map.add(noncropmask);
				dom.byId("divLoadingIndicator").style.display = 'none';
			} else {
				view.goTo(zF);
				if ( currentTab = "cropsown") {
					remapRF = new RasterFunction();
					remapRF.functionName = "Clip";
					remapRF.functionArguments = {
						"ClippingGeometry" : {
							"rings" : ringgeom,
							"ClippingType" : 1
						}
					};
					this.pixelfilter();

					layer.renderingRule = remapRF;

					if (document.getElementById("districts").value === "") {
						distname = "All";
					}
					if (document.getElementById("talukas").value === "") {
						talname = "All";
					}

					//----------------------Swipe Tool------------------------

					if (cropnaame === "2018-19") {
						swal("Data Not Available");
					} else if (cropnaame === "2019-20") {
						noncropmask = new ImageryLayer({
							url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/others_2019_20/ImageServer",
							opacity : 0.8
						});
						map.add(layer);

						//-------------------division boundary------------
						if (divi != 'All' && distname == 'All' && talname == 'All') {
							// alert();
							var bikeTrailsRenderer = {
								type : "simple",
								symbol : {
									type : "simple-line",
									color : "#666869",
									width : "1px"
								}
							};
							this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/2", {
								mode : FeatureLayer.MODE_SNAPSHOT,
								outFields : ["*"],
								renderer : bikeTrailsRenderer,
							});

							this.featureLayer.definitionExpression = "ADVNCODE = '" + dvncode + "' and DTNCODE  <>''";

							map.add(this.featureLayer);
						}

						//-------------------district boundary------------
						if (divi != 'All' && distname != 'All' && talname == 'All') {
							var bikeTrailsRenderer = {
								type : "simple",
								symbol : {
									type : "simple-line",
									color : "#666869",
									width : "1px"
								}
							};
							this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/3", {
								mode : FeatureLayer.MODE_SNAPSHOT,
								outFields : ["*"],
								renderer : bikeTrailsRenderer,
							});

							this.featureLayer.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE  <>''";

							map.add(this.featureLayer);
						}

						//-------------------taluka boundary------------
						if (divi != 'All' && distname != 'All' && talname != 'All') {
							var bikeTrailsRenderer = {
								type : "simple",
								symbol : {
									type : "simple-line",
									color : "#666869",
									width : "1px"
								}
							};
							this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/baselayers/circle_boundary/MapServer/0", {
								mode : FeatureLayer.MODE_SNAPSHOT,
								outFields : ["*"],
								renderer : bikeTrailsRenderer,
							});

							this.featureLayer.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";

							map.add(this.featureLayer);
						}

						//---------------------------------------------------

					} else if (cropnaame === "2020-21") {
						noncropmask = new ImageryLayer({
							url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/sugarcane_2020_21/ImageServer",
							opacity : 0.8
						});
						map.add(layer);

						//-------------------division boundary------------
						if (divi != 'All' && distname == 'All' && talname == 'All') {
							// alert();
							var bikeTrailsRenderer = {
								type : "simple",
								symbol : {
									type : "simple-line",
									color : "#666869",
									width : "1px"
								}
							};
							this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/2", {
								mode : FeatureLayer.MODE_SNAPSHOT,
								outFields : ["*"],
								renderer : bikeTrailsRenderer,
							});

							this.featureLayer.definitionExpression = "ADVNCODE = '" + dvncode + "' and DTNCODE  <>''";

							map.add(this.featureLayer);
						}

						//-------------------district boundary------------
						if (divi != 'All' && distname != 'All' && talname == 'All') {
							var bikeTrailsRenderer = {
								type : "simple",
								symbol : {
									type : "simple-line",
									color : "#666869",
									width : "1px"
								}
							};
							this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/3", {
								mode : FeatureLayer.MODE_SNAPSHOT,
								outFields : ["*"],
								renderer : bikeTrailsRenderer,
							});

							this.featureLayer.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE  <>''";

							map.add(this.featureLayer);
						}

						//-------------------taluka boundary------------
						if (divi != 'All' && distname != 'All' && talname != 'All') {
							var bikeTrailsRenderer = {
								type : "simple",
								symbol : {
									type : "simple-line",
									color : "#666869",
									width : "1px"
								}
							};
							this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/baselayers/circle_boundary/MapServer/0", {
								mode : FeatureLayer.MODE_SNAPSHOT,
								outFields : ["*"],
								renderer : bikeTrailsRenderer,
							});

							this.featureLayer.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";

							map.add(this.featureLayer);
						}

						//---------------------------------------------------

					} else if (cropnaame === "2021-22") {
						noncropmask = new ImageryLayer({
							url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/sugarcane_2021_22/ImageServer",
							opacity : 0.8
						});
						map.add(layer);

						//-------------------division boundary------------
						if (divi != 'All' && distname == 'All' && talname == 'All') {
							// alert();
							var bikeTrailsRenderer = {
								type : "simple",
								symbol : {
									type : "simple-line",
									color : "#666869",
									width : "1px"
								}
							};
							this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/2", {
								mode : FeatureLayer.MODE_SNAPSHOT,
								outFields : ["*"],
								renderer : bikeTrailsRenderer,
							});

							this.featureLayer.definitionExpression = "ADVNCODE = '" + dvncode + "' and DTNCODE  <>''";

							map.add(this.featureLayer);
						}

						//-------------------district boundary------------
						if (divi != 'All' && distname != 'All' && talname == 'All') {
							var bikeTrailsRenderer = {
								type : "simple",
								symbol : {
									type : "simple-line",
									color : "#666869",
									width : "1px"
								}
							};
							this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/3", {
								mode : FeatureLayer.MODE_SNAPSHOT,
								outFields : ["*"],
								renderer : bikeTrailsRenderer,
							});

							this.featureLayer.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE  <>''";

							map.add(this.featureLayer);
						}

						//-------------------taluka boundary------------
						if (divi != 'All' && distname != 'All' && talname != 'All') {
							var bikeTrailsRenderer = {
								type : "simple",
								symbol : {
									type : "simple-line",
									color : "#666869",
									width : "1px"
								}
							};
							this.featureLayer = new FeatureLayer("https://portal.mrsac.org.in/webadpgis8/rest/services/baselayers/circle_boundary/MapServer/0", {
								mode : FeatureLayer.MODE_SNAPSHOT,
								outFields : ["*"],
								renderer : bikeTrailsRenderer,
							});

							this.featureLayer.definitionExpression = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";

							map.add(this.featureLayer);
						}

						//---------------------------------------------------

					}

					swipe.leadingLayers.add(layer);
					swipe.trailingLayers.add(noncropmask);

					featureLayer1 = new MapImageLayer({
						url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/basemap_cropacreage/MapServer",
						outFields : ["*"],
						mode : FeatureLayer.MODE_ONDEMAND,
					});
					map.add(featureLayer1);

					this.getBarGraph();
					// this.getpieChartAgri();
				}
			}
		},
		noncropMaskClip : function() {
			remapRFnoncrp = new RasterFunction();
			remapRFnoncrp.functionName = "Clip";
			remapRFnoncrp.functionArguments = {
				"ClippingGeometry" : {
					"rings" : ringgeom,
					"ClippingType" : 1
				}
			};
			this.pixelfilterCrop();
			layerimage.renderingRule = remapRFnoncrp;
			map.add(layerimage);

		},
		pixelfilter : function() {
			distname = document.getElementById("districts").value;
			talname = document.getElementById("talukas").value;
			cropnaame = document.getElementById("years").value;
			// seasonName = document.getElementById("seasonSelect").value;
			// cropyear = document.getElementById("year").value;

			// seasonUrl = seasonName.toLowerCase();
			// yearUrl = cropyear.replace("-", "_");

			departmentarray = [];

			if (cropnaame === "2018-19") {
				swal("Data Not Available");
			}
			if (cropnaame === "2019-20") {
				filterUrl = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/others_2019_20/ImageServer";
			} else if (cropnaame === "2020-21") {
				filterUrl = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/sugarcane_2020_21/ImageServer";
			} else if (cropnaame === "2021-22") {
				filterUrl = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/sugarcane_2021_22/ImageServer";
			}
			departmentarray = [];

			//dom.byId("divLoadingIndicator").style.display = 'block';

			layer = new ImageryLayer({
				url : filterUrl,
				pixelFilter : colorize,
				id : "imageLayer"

			});
			layer.when(function() {
				rasterAttributes = layer.rasterAttributeTable.features;
				fields = rasterAttributes.filter(function(item, i) {
					className = item.attributes.Class_Names;
					return className === 'Sugarcane';
				});
			});
			function colorize1(pixelData) {

				if (pixelData === null || pixelData.pixelBlock === null || pixelData.pixelBlock.pixels === null) {
					return;
				}
				var pixelBlock = pixelData.pixelBlock;

				var pixels = pixelBlock.pixels;

				var band1 = pixels[0];

				var rBand = [];
				var gBand = [];
				var bBand = [];

				var mask = [];

				var numPixels = pixelBlock.width * pixelBlock.height;

				for (var i = 0; i < numPixels; i++) {
					var val = band1[i];

					if (val === fields[0].attributes.Value) {
						mask[i] = 1;
						rBand[i] = fields[0].attributes.Red;
						gBand[i] = fields[0].attributes.Green;
						bBand[i] = fields[0].attributes.Blue;

					} else if (val === fields[1].attributes.Value) {

						mask[i] = 2;
						rBand[i] = fields[1].attributes.Red;
						gBand[i] = fields[1].attributes.Green;
						bBand[i] = fields[1].attributes.Blue;

					} else {
						mask[i] = 0;
						rBand[i] = 0;
						gBand[i] = 0;
						bBand[i] = 0;
					}

				}
				// Set the new pixel values on the pixelBlock
				pixelData.pixelBlock.pixels = [rBand, gBand, bBand];
				pixelData.pixelBlock.statistics = null;
				pixelData.pixelBlock.pixelType = "U4";
				// U8 is used for color
				pixelData.pixelBlock.mask = mask;
			}

			function colorize2(pixelData) {

				if (pixelData === null || pixelData.pixelBlock === null || pixelData.pixelBlock.pixels === null) {
					return;
				}
				var pixelBlock = pixelData.pixelBlock;

				var pixels = pixelBlock.pixels;

				var band1 = pixels[0];

				var rBand = [];
				var gBand = [];
				var bBand = [];

				var mask = [];

				var numPixels = pixelBlock.width * pixelBlock.height;

				for (var i = 0; i < numPixels; i++) {
					var val = band1[i];

					if (val === fields[0].attributes.Value) {
						mask[i] = 1;
						rBand[i] = fields[0].attributes.Red;
						gBand[i] = fields[0].attributes.Green;
						bBand[i] = fields[0].attributes.Blue;

					} else if (val === fields[1].attributes.Value) {

						mask[i] = 2;
						rBand[i] = fields[1].attributes.Red;
						gBand[i] = fields[1].attributes.Green;
						bBand[i] = fields[1].attributes.Blue;

					} else if (val === fields[2].attributes.Value) {

						mask[i] = 3;
						rBand[i] = fields[2].attributes.Red;
						gBand[i] = fields[2].attributes.Green;
						bBand[i] = fields[2].attributes.Blue;

					} else if (val === fields[3].attributes.Value) {

						mask[i] = 4;
						rBand[i] = fields[3].attributes.Red;
						gBand[i] = fields[3].attributes.Green;
						bBand[i] = fields[3].attributes.Blue;

					} else if (val === fields[4].attributes.Value) {
						mask[i] = 5;
						rBand[i] = fields[4].attributes.Red;
						gBand[i] = fields[4].attributes.Green;
						bBand[i] = fields[4].attributes.Blue;

					} else if (val === fields[5].attributes.Value) {

						mask[i] = 6;
						rBand[i] = fields[5].attributes.Red;
						gBand[i] = fields[5].attributes.Green;
						bBand[i] = fields[5].attributes.Blue;

					} else if (val === fields[6].attributes.Value) {

						mask[i] = 7;
						rBand[i] = fields[6].attributes.Red;
						gBand[i] = fields[6].attributes.Green;
						bBand[i] = fields[6].attributes.Blue;

					} else if (val === fields[7].attributes.Value) {

						mask[i] = 8;
						rBand[i] = fields[7].attributes.Red;
						gBand[i] = fields[7].attributes.Green;
						bBand[i] = fields[7].attributes.Blue;

					} else if (val === fields[8].attributes.Value) {

						mask[i] = 9;
						rBand[i] = fields[8].attributes.Red;
						gBand[i] = fields[8].attributes.Green;
						bBand[i] = fields[8].attributes.Blue;

					} else {
						mask[i] = 0;
						rBand[i] = 0;
						gBand[i] = 0;
						bBand[i] = 0;
					}

				}

				// Set the new pixel values on the pixelBlock
				pixelData.pixelBlock.pixels = [rBand, gBand, bBand];
				pixelData.pixelBlock.statistics = null;
				pixelData.pixelBlock.pixelType = "U4";
				// U8 is used for color
				pixelData.pixelBlock.mask = mask;
			}

			function colorize3(pixelData) {

				if (pixelData === null || pixelData.pixelBlock === null || pixelData.pixelBlock.pixels === null) {
					return;
				}
				var pixelBlock = pixelData.pixelBlock;

				var pixels = pixelBlock.pixels;

				var band1 = pixels[0];

				var rBand = [];
				var gBand = [];
				var bBand = [];

				var mask = [];

				var numPixels = pixelBlock.width * pixelBlock.height;

				for (var i = 0; i < numPixels; i++) {
					var val = band1[i];

					if (val === fields[0].attributes.Value) {
						mask[i] = 1;
						rBand[i] = fields[0].attributes.Red;
						gBand[i] = fields[0].attributes.Green;
						bBand[i] = fields[0].attributes.Blue;

					} else if (val === fields[1].attributes.Value) {

						mask[i] = 2;
						rBand[i] = fields[1].attributes.Red;
						gBand[i] = fields[1].attributes.Green;
						bBand[i] = fields[1].attributes.Blue;

					} else if (val === fields[2].attributes.Value) {

						mask[i] = 3;
						rBand[i] = fields[2].attributes.Red;
						gBand[i] = fields[2].attributes.Green;
						bBand[i] = fields[2].attributes.Blue;

					} else if (val === fields[3].attributes.Value) {

						mask[i] = 4;
						rBand[i] = fields[3].attributes.Red;
						gBand[i] = fields[3].attributes.Green;
						bBand[i] = fields[3].attributes.Blue;

					} else {
						mask[i] = 0;
						rBand[i] = 0;
						gBand[i] = 0;
						bBand[i] = 0;
					}

				}

				// Set the new pixel values on the pixelBlock
				pixelData.pixelBlock.pixels = [rBand, gBand, bBand];
				pixelData.pixelBlock.statistics = null;
				pixelData.pixelBlock.pixelType = "U4";
				// U8 is used for color
				pixelData.pixelBlock.mask = mask;
			}

			function colorize(pixelData) {

				if (pixelData === null || pixelData.pixelBlock === null || pixelData.pixelBlock.pixels === null) {
					return;
				}
				var pixelBlock = pixelData.pixelBlock;

				var pixels = pixelBlock.pixels;

				var band1 = pixels[0];

				var rBand = [];
				var gBand = [];
				var bBand = [];

				var mask = [];
				var numPixels = pixelBlock.width * pixelBlock.height;

				for (var i = 0; i < numPixels; i++) {
					var val = band1[i];

					if (val === fields[0].attributes.Value) {
						mask[i] = 1;
						rBand[i] = fields[0].attributes.Red;
						gBand[i] = fields[0].attributes.Green;
						bBand[i] = fields[0].attributes.Blue;

					} else {
						mask[i] = 0;
						rBand[i] = 0;
						gBand[i] = 0;
						bBand[i] = 0;
					}

				}

				pixelData.pixelBlock.pixels = [rBand, gBand, bBand];
				pixelData.pixelBlock.statistics = null;
				pixelData.pixelBlock.pixelType = "U4";
				pixelData.pixelBlock.mask = mask;
			}

		},
		getBarGraph : function() {
			debugger;
			// cropyear = document.getElementById("yearh").value;
			divi = document.getElementById("divisions").value;
			distname = document.getElementById("districts").value;
			talname = document.getElementById("talukas").value;
			cropnaame = document.getElementById("years").value;
			// seasonName = document.getElementById("seasonSelecth").value;

			//divname = divi.toUpperCase();

			var circleArea;
			// for (var i = 0; i < valueKharif.length; i++) {
			// if (valueKharif[i].name === cropnaame) {
			// cropCode = valueKharif[i].code;
			// }
			// }
			for (var i = 0; i < zoneGetcropchange.length; i++) {
				if (zoneGetcropchange[i].name === divi) {
					dvncode = zoneGetcropchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					dtncode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talcode = zoneGetdistchange[i].code;
				}
			}
			// for (var i = 0; i < zoneGettalchange.length; i++) {
			// if (zoneGettalchange[i].name === circlename) {
			// circleArea = zoneGettalchange[i].area;
			// }
			// if (zoneGettalchange[i].name === circlename) {
			// circode = zoneGettalchange[i].code;
			// }
			// }
			dom.byId("divLoadingIndicator").style.display = 'block';
			roundareaha = Math.round(circleArea * 100) / 100;
			totcirareacount = 0;

			arrgraph = [];
			catarr = [];
			totcountarearound = 0;
			var zone = [];
			var values = [];
			var testVals = {};

			divisiondata = [];
			strdivi = "";
			districtdata = [];
			strdist = "";
			talukadata = [];
			strtal = "";
			circledata = [];
			strcir = "";
			seperator = "";

			divisiondataTga = [];
			strdiviTga = "";
			districtdataTga = [];
			strdistTga = "";
			talukadataTga = [];
			strtalTga = "";
			circledataTga = [];
			strcirTga = "";

			divisiondataAgri = [];
			strdiviAgri = [];
			districtdataAgri = [];
			strdistAgri = "";
			talukadataAgri = [];
			strtalAgri = "";
			circledataAgri = [];
			strcirAgri = "";

			graphTitle = "";

			//---------for all Crops---------
			strdivicrp = "";
			strdistcrp = "";
			strtalcrp = "";
			strcircrp = "";
			cropdata = [];
			//----------for all crops----------

			// if (seasonName == 'Others') {
			stastask = new QueryTask(this.othersstat);
			// }

			//------------------- Bar Graph  Table-----------------------------
			var gramE = [];
			statsquery = new Query();
			statsquery.outFields = ["*"];
			// statsquery.returnDistinctValues = true;
			statsquery.returnGeometry = true;
			statsquery.outSpatialReference = {
				"wkid" : 102100
			};

			queryStatistic = queryUsedFurther.where;
			statsquery.where = queryStatistic;
			// console.log(queryStatistic);

			finalData = [];
			stastask.execute(statsquery).then(function(results2) {

				var features = results2.features;
				if (features.length < 1) {
					swal("Crop statistics not available for this Region");
				} else {
					array.forEach(features, lang.hitch(this, function(feature2, index) {
						gramE.push(feature2);
						// console.log(feature2);
						advename = feature2.attributes.advename;
						dtename = feature2.attributes.dtename;
						cirname = feature2.attributes.cirname;
						circode = feature2.attributes.circode;
						areahanotround = feature2.attributes.acreage_area;
						// console.log(areahanotround);
						areaha = Math.round(areahanotround * 100) / 100;
						thename = feature2.attributes.thename;
						thecode = feature2.attributes.thecode;
						cropname = feature2.attributes.crop_name;

						cirtga = feature2.attributes.cir_tga;
						cirtgaround = Math.round(cirtga * 100) / 100;
						ciragricultural = feature2.attributes.cir_agricultural;
						ciragriculturalround = Math.round(ciragricultural * 100) / 100;

						cirbuiltup = feature2.attributes.cir_builtup;
						cirforest = feature2.attributes.cir_forest;
						cirwasteland = feature2.attributes.cir_wasteland;
						cirwaterbodies = feature2.attributes.cir_waterbodies;

						totcirareacount += areaha;

						cirtgaround = Math.round(totcirareacount * 100) / 100;
						totcountarearound = Math.round(totcirareacount * 100) / 100;
						roundareaha = Math.round(areaha * 100) / 100;
						//console.log(" Dist Name : " + distname + " Tal Name : " + talname + " Circle Name: " + circlename);

						if ((divi == "All" && distname == "" && talname == "") || (divi == "All" && distname == "All" && talname == "" ) || (divi == "All" && distname == "All" && talname == "All" ) || (divi == "All" && distname == "All" && talname == "All" )) {
							graphTitle = "Division Wise Sown Area (Ha)";
							dom.byId("statwise").innerHTML = "Division Wise Sown Area (Ha)";
							var n = strdivi.includes(advename);
							if (n) {
								divisiondata[advename] = divisiondata[advename] + areaha;
								strdivi += seperator + advename;
								seperator = ", ";
							} else {
								divisiondata[advename] = areaha;
								strdivi += seperator + advename;
								seperator = ", ";
							}
							//******************TGA and agriculture area*******************
							var nagri = strdiviAgri.includes(advename);
							var ntga = strdiviTga.includes(advename);

							if (nagri) {
								divisiondataAgri[advename] = divisiondataAgri[advename] + ciragriculturalround;
								strdiviAgri += seperator + advename;
								seperator = ", ";
							} else {
								divisiondataAgri[advename] = ciragriculturalround;
								strdiviAgri += seperator + advename;
								seperator = ", ";
							}
							if (ntga) {
								divisiondataTga[advename] = divisiondataTga[advename] + cirtgaround;
								strdiviTga += seperator + advename;
								seperator = ", ";
							} else {
								divisiondataTga[advename] = cirtgaround;
								strdiviTga += seperator + advename;
								seperator = ", ";
							}
						} else if ((divi != "All" && distname == "" && talname == "" ) || (divi != "All" && distname == "All" && talname == "" ) || (divi != "All" && distname == "All" && talname == "All" ) || (divi != "All" && distname == "All" && talname == "All" )) {

							graphTitle = "District Wise Sown Area (Ha)";
							dom.byId("statwise").innerHTML = "Division Wise Sown Area (Ha)";
							var n = strdist.includes(dtename);
							if (n) {
								districtdata[dtename] = districtdata[dtename] + areaha;
								strdist += seperator + dtename;
								seperator = ", ";
							} else {
								districtdata[dtename] = areaha;
								strdist += seperator + dtename;
								seperator = ", ";
							}
							//******************TGA and agriculture area*******************
							var nagri = strdistAgri.includes(dtename);
							var ntga = strdistTga.includes(dtename);

							if (nagri) {
								districtdataAgri[dtename] = districtdataAgri[dtename] + ciragriculturalround;
								strdistAgri += seperator + dtename;
								seperator = ", ";
							} else {
								districtdataAgri[dtename] = ciragriculturalround;
								strdistAgri += seperator + dtename;
								seperator = ", ";
							}
							if (ntga) {
								districtdataTga[dtename] = districtdataTga[dtename] + cirtgaround;
								strdistTga += seperator + dtename;
								seperator = ", ";
							} else {
								districtdataTga[dtename] = cirtgaround;
								strdistTga += seperator + dtename;
								seperator = ", ";
							}
						} else if ((divi != "All" && distname != "All" && talname == "") || (divi != "All" && distname != "All" && talname == "All" ) || (divi != "All" && distname != "All" && talname == "All" )) {
							graphTitle = "Taluka Wise Sown Area (Ha)";
							dom.byId("statwise").innerHTML = "District Wise Sown Area (Ha)";
							var n = strtal.includes(thename);
							if (n) {
								talukadata[thename] = talukadata[thename] + areaha;
								strtal += seperator + thename;
								seperator = ", ";
							} else {
								talukadata[thename] = areaha;
								strtal += seperator + thename;
								seperator = ", ";
							}
							//******************TGA and agriculture area*******************
							var nagri = strtalAgri.includes(thename);
							var ntga = strtalTga.includes(thename);

							if (nagri) {
								talukadataAgri[thename] = talukadataAgri[thename] + ciragriculturalround;
								strtalAgri += seperator + thename;
								seperator = ", ";
							} else {
								talukadataAgri[thename] = ciragriculturalround;
								strtalAgri += seperator + thename;
								seperator = ", ";
							}
							if (ntga) {
								talukadataTga[thename] = talukadataTga[thename] + cirtgaround;
								strtalTga += seperator + thename;
								seperator = ", ";
							} else {
								talukadataTga[thename] = cirtgaround;
								strtalTga += seperator + thename;
								seperator = ", ";
							}

						} else if ((divi != "All" && distname != "All" && talname !== "") || (divi != "All" && distname != "All" && talname !== "All" ) || (divi != "All" && distname != "All" && talname !== "All" )) {
							// alert();
							graphTitle = "Revenue Circle Wise Sown Area (Ha)";
							dom.byId("statwise").innerHTML = "Taluka Wise Sown Area (Ha)";
							var n = strtal.includes(cirname);
							if (n) {
								circledata[thename] = circledata[cirname] + areaha;
								strtal += seperator + cirname;
								seperator = ", ";
							} else {
								circledata[cirname] = areaha;
								strtal += seperator + cirname;
								seperator = ", ";
							}
							//******************TGA and agriculture area*******************
							var nagri = strtalAgri.includes(cirname);
							var ntga = strtalTga.includes(cirname);

							if (nagri) {
								circledataAgri[cirname] = circledataAgri[cirname] + ciragriculturalround;
								strtalAgri += seperator + cirname;
								seperator = ", ";
							} else {
								circledataAgri[cirname] = ciragriculturalround;
								strtalAgri += seperator + cirname;
								seperator = ", ";
							}
							if (ntga) {
								circledataTga[cirname] = circledataTga[cirname] + cirtgaround;
								strtalTga += seperator + cirname;
								seperator = ", ";
							} else {
								circledataTga[cirname] = cirtgaround;
								strtalTga += seperator + cirname;
								seperator = ", ";
							}

						}
						//

						//-------------------------------------------------------------------------
						tablebody = document.getElementById("tableBodyCropSownPart1");
						$("#dataTablePart1 tbody").empty();

						if (tableIterationFlag == true) {

							/******************************table t2****************************/
							if ((divi == "All" && distname == "" && talname == "" ) || (divi == "All" && distname == "All" && talname == "" ) || (divi == "All" && distname == "All" && talname == "All" ) || (divi == "All" && distname == "All" && talname == "")) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							} else if ((distname == "" && talname == "" ) || (distname == "All" && talname == "" )) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							} else if ((talname == "" ) || (talname == "All" )) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							} else if ((talname != "All" )) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Taluka</b><td style='padding-left: 6%;'>" + talname + "</td></tr>\n\<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							} else if ((talname != "All" ) || (talname == "All" )) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Taluka</b><td style='padding-left: 6%;'>" + talname + "</td></tr>\n\<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							} else if (talname != "All") {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Taluka</b><td style='padding-left: 6%;'>" + talname + "</td></tr>\n\<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							} else if ((talname == "All" )) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							}
							dataTableObj = $('#dataTablePart1').DataTable({
								"sorting" : false,
								"searching" : false,
								"paging" : false,
								"info" : false,
								"lengthChange" : false
							});
							tableIterationFlag = false;
						} else {

							$("#dataTablePart1 tbody").empty();
							dataTableObj.clear();
							dataTableObj.destroy();
							/******************************table t2****************************/
							if ((divi == "All" && distname == "" && talname == "") || (divi == "All" && distname == "All" && talname == "" ) || (divi == "All" && distname == "All" && talname == "All" ) || (divi == "All" && distname == "All" && talname == "" )) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							} else if ((distname == "" && talname == "" ) || (distname == "All" && talname == "" )) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							} else if ((talname == "" ) || (talname == "All" )) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							} else if ((talname != "All" )) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Taluka</b><td style='padding-left: 6%;'>" + talname + "</td></tr>\n\<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							} else if ((talname != "All" ) || (talname == "All" )) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Taluka</b><td style='padding-left: 6%;'>" + talname + "</td></tr>\n\<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							} else if (talname != "All") {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Taluka</b><td style='padding-left: 6%;'>" + talname + "</td></tr>\n\<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							} else if ((talname == "All" )) {
								$("#dataTablePart1 tbody").append("<tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Year</b><td style='padding-left: 6%;'>" + cropnaame + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Division</b><td style='padding-left: 6%;'>" + divname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>District</b><td style='padding-left: 6%;'>" + distname + "</td></tr><tr style='color: black;font-size: 14px;'><td style='padding-left: 6%;'><b>Area (Ha) </b><td style='padding-left: 6%;'>" + cirtgaround + "</td></tr>");
							}

							dataTableObj = $('#dataTablePart1').DataTable({
								"sorting" : false,
								"searching" : false,
								"paging" : false,
								"info" : false,
								"lengthChange" : false
							});
						}

						dom.byId("cropSownCharts").style.display = 'block';
						dom.byId("divLoadingIndicator").style.display = 'none';

					}));
					//console.log(finalData);

					if ((divi == "All" && distname == "" && talname == "" ) || (divi == "All" && distname == "All" && talname == "" ) || (divi == "All" && distname == "All" && talname == "All" ) || (divi == "All" && distname == "All" && talname == "All" )) {
						for (var k in divisiondata) {
							if ( typeof divisiondata[k] !== 'function') {
								catarr.push(k);
								arrgraph.push(divisiondata[k]);
							}
						}
					} else if ((divi != "All" && distname == "" && talname == "" ) || (divi != "All" && distname == "All" && talname == "" ) || (divi != "All" && distname == "All" && talname == "All" ) || (divi != "All" && distname == "All" && talname == "All" )) {
						for (var k in districtdata) {
							if ( typeof districtdata[k] !== 'function') {
								catarr.push(k);
								arrgraph.push(districtdata[k]);
							}
						}
					} else if ((divi != "All" && distname != "All" && talname == "" ) || (divi != "All" && distname != "All" && talname == "All" ) || (divi != "All" && distname != "All" && talname == "All" )) {
						for (var k in talukadata) {
							if ( typeof talukadata[k] !== 'function') {
								catarr.push(k);
								arrgraph.push(talukadata[k]);

							}
						}

					} else if ((divi != "All" && distname != "All" && talname != "All" ) || (divi != "All" && distname != "All" && talname != "All") || (divi != "All" && distname != "All" && talname != "All" )) {
						for (var k in circledata) {
							if ( typeof circledata[k] !== 'function') {
								catarr.push(k);
								arrgraph.push(circledata[k]);

							}
						}
					}
					//------------------------------Graph TGA And Agriculture --------------------------

					var tga = [];
					var aga = [];
					var ca = [];
					$.each(catarr, function(i) {
						if ((divi == "All" && distname == "" && talname == "" ) || (divi == "All" && distname == "All" && talname == "" ) || (divi == "All" && distname == "All" && talname == "All" ) || (divi == "All" && distname == "All" && talname == "All" )) {

							tga[i] = divisiondataTga[catarr[i]];
							aga[i] = divisiondataAgri[catarr[i]];

						} else if ((divi != "All" && distname == "" && talname == "" ) || (divi != "All" && distname == "All" && talname == "" ) || (divi != "All" && distname == "All" && talname == "All" ) || (divi != "All" && distname == "All" && talname == "All" )) {

							tga[i] = districtdataTga[catarr[i]];
							aga[i] = districtdataAgri[catarr[i]];

						} else if ((divi != "All" && distname != "All" && talname == "" ) || (divi != "All" && distname != "All" && talname == "All" ) || (divi != "All" && distname != "All" && talname == "All" )) {

							tga[i] = talukadataTga[catarr[i]];
							aga[i] = talukadataAgri[catarr[i]];

						} else if ((divi != "All" && distname != "All" && talname !== "" ) || (divi != "All" && distname != "All" && talname !== "All" ) || (divi != "All" && distname != "All" && talname !== "All" )) {

							tga[i] = circledataTga[catarr[i]];
							aga[i] = circledataAgri[catarr[i]];

						}
					});
					// console.log(arrgraph);
					// console.log(tga);
					// console.log(aga);
					// console.log(ca);

					Highcharts.chart('cropChart', {
						chart : {
							type : 'column',
							height : 220,

						},
						title : {
							text : graphTitle,
						},
						colors : ['#349fa4'],
						credits : {
							enabled : false
						},
						xAxis : {
							type : 'category',
							labels : {
								useHTML : true,
								allowOverlap : true,
								style : {
									fontFamily : 'arial',
									fontSize : '8pt',
									fontWeight : 'bold',
									wordBreak : 'break-all',
									textOverflow : 'allow',
									fontWeight : 'bold'
								}
							},
							crosshairs : true,
							categories : catarr
						},
						yAxis : {
							title : {
								text : 'Sown Area (Ha)',
								style : {
									fontFamily : 'arial',
									fontWeight : 'bold',
									fontSize : '10pt',
								}
							},

						},

						legend : {
							/*layout : 'horizontal',
							 itemMarginTop : 0,
							 margin : 0,
							 padding : 0*/
							align : 'right',
							x : -30,
							verticalAlign : 'top',
							y : -10,
							floating : true,
							backgroundColor : Highcharts.defaultOptions.legend.backgroundColor || 'transparent',
							borderColor : '#CCC',
							borderWidth : 1,
							shadow : false,
							itemStyle : {
								fontFamily : 'arial',
								fontSize : '9pt'
							},
							symbolRadius : 0

						},

						tooltip : {
							enabled : true,
							shared : true,
							valueDecimals : 2,
							style : {
								fontFamily : 'arial'
							}
							// headerFormat : '<b>{point.x}</b><hr><br/>',
							//pointFormat : '<span style="color:{point.color}">\u25CF</span> {series.name}: <b>{point.percentage:.1f} %</b><br/>'

						},
						plotOptions : {
							series : {
								pointWidth : 10,
								stacking : 'normal',
								borderWidth : 0,
								dataLabels : {
									inside : false,
									enabled : false,
								},
								animation : {
									enabled : true,
									duration : 400,
									easing : 'linear'
								}

							}
						},
						series : [{
							stack : 'Crop Area',
							name : 'Crop Area',
							data : arrgraph

						}],
					});

				}
				// dom.byId("floatingmenu").style.display = 'block';
				// dom.byId("floatingmenu").style.bottom = '0px';
				// dom.byId("viewDiv").style.height = '67%';

			});

		},

		generatemap : function() {

			// dom.byId("divLoadingIndicator1").style.display = 'block';
			divname = document.getElementById("divisions").value;
			distname = document.getElementById("districts").value;
			talname = document.getElementById("talukas").value;
			year = document.getElementById("years").value;
			dom.byId("divLoadingIndicator").style.display = 'block';

			var cropCode = "SU01";

			for (var i = 0; i < zoneGetcropchange.length; i++) {
				if (zoneGetcropchange[i].name === divi) {
					dvncode = zoneGetcropchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdivchange.length; i++) {
				if (zoneGetdivchange[i].name === distname) {
					distrcitCode = zoneGetdivchange[i].code;
				}
			}
			for (var i = 0; i < zoneGetdistchange.length; i++) {
				if (zoneGetdistchange[i].name === talname) {
					talukaCode = zoneGetdistchange[i].code;
				}
			}

			var gpUrl = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/sugarcanetemplate/GPServer/sugarcanetemplate";
			var gp = new Geoprocessor(gpUrl);
			var parameters = {
				"division" : divname,
				"district" : distname,
				"taluka" : talname,
				"div_cd" : dvncode,
				"dist_cd" : distrcitCode,
				"tal_cd" : talukaCode,
				"year" : year
			};

			// console.log(parameters);
			gp.execute(parameters).then(ShowResultData);

			function ShowResultData(result) {
				// alert(result);
				// console.log(result.results[0].value);
				var resultImg = result.results[0].value.url;
				var center_left = (screen.width / 2.5) - (400 / 2);
				var center_top = (screen.height / 2.5) - (400 / 2);
				window.open(resultImg, target = '_blank', 'width=1000,height=750, top=' + center_top + ', left=' + center_left);
				dom.byId("divLoadingIndicator").style.display = 'none';
			}

		},

		ViewReport : function() {
			debugger;
			divi = document.getElementById("divisions").value;
			distname = document.getElementById("districts").value;
			talname = document.getElementById("talukas").value;
			year = document.getElementById("years").value;

			if (year === "" || divi === "") {
				swal("Please Select Proper input");
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});
				map.basemap = "topo";
				featureLayer = new MapImageLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
					outFields : ["*"],
					mode : FeatureLayer.MODE_ONDEMAND,
				});
				map.add(featureLayer);
				dom.byId("divLoadingIndicator").style.display = 'none';
			} else {

				for (var i = 0; i < zoneGetcropchange.length; i++) {
					if (zoneGetcropchange[i].name === divi) {
						dvncode = zoneGetcropchange[i].code;
					}
				}
				for (var i = 0; i < zoneGetdivchange.length; i++) {
					if (zoneGetdivchange[i].name === distname) {
						dtncode = zoneGetdivchange[i].code;
					}
				}
				for (var i = 0; i < zoneGetdistchange.length; i++) {
					if (zoneGetdistchange[i].name === talname) {
						talcode = zoneGetdistchange[i].code;
					}
				}

				if (document.getElementById("divisions").value === "") {
					dvncode = "All";
					divi = "All";
				}

				if (document.getElementById("districts").value === "") {
					dtncode = "All";
					distname = "All";
				}

				if (document.getElementById("talukas").value === "") {
					talcode = "All";
					talname = "All";
				}

				document.getElementById("mainContent").style.display = "block";
				dom.byId("divLoadingIndicator").style.display = 'block';

				$("#mainContent").load("http://117.240.213.118:6080/cropacreagereport1/sugarcanestathtml?division=" + dvncode + "&district=" + dtncode + "&taluka=" + talcode + "&circle=All&division_n=" + divi + "&district_n=" + distname + "&taluka_n=" + talname + "&circle_n=All&season=Kharif&year=" + year, function() {

					$('#datatable').DataTable();
					dom.byId("divLoadingIndicator").style.display = 'none';
				});

			}

		},
	});
});
