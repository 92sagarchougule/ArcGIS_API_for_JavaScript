/**
 * @author prachi
 */
define(["dojo/_base/declare", "dijit/registry", "dijit/_WidgetBase", "dijit/_OnDijitClickMixin", "dijit/_TemplatedMixin", "dojo/text!./templates/cropsap.html", "dojo/_base/window", "dijit/_WidgetsInTemplateMixin", "dijit/layout/AccordionContainer", "esri/Map", "esri/views/MapView", "esri/widgets/Expand", "esri/layers/KMLLayer", "esri/geometry/geometryEngine", "esri/layers/Layer", "esri/WebMap", "esri/widgets/Search", "esri/widgets/Locate", "esri/widgets/Track", "esri/Graphic", "esri/widgets/Compass", "esri/layers/MapImageLayer", "esri/widgets/CoordinateConversion", "esri/tasks/Geoprocessor", "dijit/Tooltip", "esri/tasks/support/RelationshipQuery", "esri/tasks/Locator", "esri/widgets/Home", "esri/widgets/Search", "esri/widgets/BasemapToggle", "esri/widgets/Swipe", "esri/widgets/ScaleBar", "esri/geometry/Extent", "dojo/_base/lang", "dojo/topic", "esri/config", "esri/identity/ServerInfo", "esri/identity/IdentityManager", "esri/layers/FeatureLayer", "esri/tasks/support/FeatureSet", "esri/layers/ImageryLayer", "esri/layers/MapImageLayer", "esri/tasks/ClosestFacilityTask", "esri/tasks/support/ClosestFacilityParameters", "dojo/_base/array", "dojo/on", "dojo/dom", "dojo/dom-construct", "dojo/dom-style", "dojo/dom-attr", "dojo/dom-class", "esri/symbols/PictureMarkerSymbol", "esri/renderers/SimpleRenderer", "esri/symbols/SimpleMarkerSymbol", "esri/Graphic", "esri/widgets/Popup", "esri/PopupTemplate", "dijit/TooltipDialog", "esri/core/lang", "esri/tasks/QueryTask", "esri/tasks/support/Query", "dojo/query", "dojo/store/Memory", "dijit/form/ComboBox", "dijit/form/DateTextBox", "dojo/data/ItemFileReadStore", "dijit/form/Select", "dijit/form/FilteringSelect", "esri/layers/GraphicsLayer", "esri/widgets/Sketch", "esri/geometry/Point", "esri/geometry/Circle", "esri/geometry/SpatialReference", "esri/symbols/SimpleLineSymbol", "esri/symbols/SimpleFillSymbol", "esri/Color", "esri/Graphic", "esri/request", "dojo/dom-style", "esri/widgets/Legend", "esri/tasks/FindTask", "dojo/request/xhr", 'dojo/data/ObjectStore', "dojo/request", "dojo/number", "dijit/layout/BorderContainer", "dijit/layout/TabContainer", "dijit/layout/ContentPane", "dijit/TitlePane", "dijit/form/Form", "esri/widgets/BasemapGallery", "dijit/form/TextBox", "dijit/Dialog", "dijit/form/CheckBox", "dijit/form/RadioButton", "dijit/Menu", "esri/layers/ImageryLayer", "esri/layers/support/RasterFunction", "esri/layers/support/DimensionalDefinition", "esri/layers/support/MosaicRule", "dijit/MenuItem", "dijit/layout/ContentPane", "dijit/Toolbar", "dijit/form/Button", "dojox/widget/TitleGroup", "esri/core/urlUtils", "dojo/_base/json", "dojo/domReady!"], function(declare, registry, _WidgetBase, _OnDijitClickMixin, _TemplatedMixin, template, win, _WidgetsInTemplateMixin, AccordionContainer, Map, MapView, Expand, KMLLayer, geometryEngine, Layer, WebMap, Search, Locate, Track, Graphic, Compass, MapImageLayer, CoordinateConversion, Geoprocessor, Tooltip, RelationshipQuery, Locator, Home, Search, BasemapToggle, Swipe, ScaleBar, Extent, lang, topic, esriConfig, ServerInfo, esriId, FeatureLayer, FeatureSet, ImageryLayer, MapImageLayer, ClosestFacilityTask, ClosestFacilityParameters, array, on, dom, domConstruct, domStyle, domAttr, domClass, PictureMarkerSymbol, SimpleRenderer, SimpleMarkerSymbol, Graphic, Popup, PopupTemplate, TooltipDialog, esriLang, QueryTask, Query, query, Memory, ComboBox, DateTextBox, ItemFileReadStore, FilteringSelect, Select, GraphicsLayer, Sketch, Point, Circle, SpatialReference, SimpleLineSymbol, SimpleFillSymbol, Color, Graphic, esriRequest, domStyle, Legend, FindTask, xhr, ObjectStore, request, number, BorderContainer, TabContainer, ContentPane, TitlePane, Form, BasemapGallery, TextBox, Dialog, CheckBox, RadioButton, Menu, ImageryLayer, RasterFunction, DimensionalDefinition, MosaicRule, urlUtils, MenuItem, json) {
	return declare("mrsac.viewer.cropsap", [_WidgetBase, _OnDijitClickMixin, _TemplatedMixin, _WidgetsInTemplateMixin], {

		constructor : function() {
			zoneGetcrop = [];
			zonegetdist = [];
			zonegettal = [];
			zonegetcon = [];
			cropSAPInfoDisplayArr = [];
			cropSAPInfoDateDisplayArr = [];
			tableIterationFlag = true;
			dataTableObj = null;
		},
		currentTab : "cropsap",
		templateString : template,
		postMixInProperties : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				alert("err" + err);
				console.error(err);
			}
		},
		postCreate : function() {
			try {
				this.inherited(arguments);
			} catch (err) {
				console.error(err);
			}
		},
		startup : function() {
			if (this._started) {

				return;
			}
			try {

				featureLayer = new MapImageLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
					outFields : ["*"],
					mode : FeatureLayer.MODE_ONDEMAND,
				});
				map.add(featureLayer);

				//--------services  used-------------
				this.state = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/0";
				this.division = "https://portal.mrsac.org.inwebadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/1";
				this.district = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/2";
				this.taluka = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer/3";

				this.cropsap2019 = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/crop_sap_2019/MapServer/0";

				this.cropsap2019drop = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/crop_sap_2019/MapServer/1";
				debugger;

				noncropmask = new ImageryLayer({
					url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/noncropmask_2019/ImageServer",
					opacity : 0.3,
					id : "noncropmaskId"

				});
				map.add(noncropmask);
				this.getcropnames();

			} catch (err) {
				console.error("SearchWidget::startup", err);

			}

		},

		getcropnames : function() {
			debugger;
			zoneGetcrop = [];
			var testVals = {};
			layergraphic = new GraphicsLayer({
				visible : true,
				id : "cropsapGraphichId"
			});
			selectcropSAP = document.getElementById("cropSAPname");
			queryTaskCropSap = new QueryTask(this.cropsap2019);
			var query = new Query();
			query.outFields = ["crop_name"];
			query.returnGeometry = false;
			query.returnDistinctValues = true;
			query.where = "1=1";
			queryTaskCropSap.execute(query).then(function(featureset) {
				var result = featureset.features;
				array.forEach(result, lang.hitch(this, function(value) {
					cropname = value.attributes.crop_name;
					if (cropname) {
						if (!testVals[cropname]) {
							testVals[cropname] = true;
							zoneGetcrop.push({
								name : cropname
							});
						}
					}
				}));

				zoneGetcrop.sort(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				zoneGetcrop.reverse(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				zoneGetcrop.push({
					name : "All",
					code : "All"
				});

				testValsn = {};

				array.forEach(zoneGetcrop, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectcropSAP.add(option, 0);
						}
					}
				}));
				document.getElementById("cropSAPname").value = "";
				dom.byId("divLoadingIndicator").style.display = 'none';
			});

		},
		crpsapchange : function() {
			zonegetdist = [];
			var values = [];
			var testVals = {};

			cropSelect = document.getElementById("cropSAPname").value;
			document.getElementById("datelive1").value = "";
			document.getElementById("datelive2").value = "";
			document.getElementById("talSAPname").value = "";
			selectdisSAP = document.getElementById("disSAPname");
			while (selectdisSAP.firstChild) {
				selectdisSAP.removeChild(selectdisSAP.firstChild);
			}
			view.graphics.removeAll();

			queryTaskdiv = new QueryTask(this.cropsap2019drop);
			var query = new Query();
			query.outFields = ["dtname ,dtncode"];
			query.returnGeometry = false;
			query.returnDistinctValues = true;
			// if (cropSelect === "All") {
			// query.where = "crop_name <> '' ";
			// } else {
			// query.where = "crop_name = '" + cropSelect + "'";
			// }
			query.where = "1=1";

			queryTaskdiv.execute(query).then(function(featureset) {

				var result = featureset.features;

				array.forEach(result, lang.hitch(this, function(value) {

					distname = value.attributes.dtname;
					distcode = value.attributes.dtncode;
					if (distname) {
						if (!testVals[distname]) {
							testVals[distname] = true;
							zonegetdist.push({
								name : distname,
								code : distcode
							});
						}
					}
				}));

				zonegetdist.sort(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				zonegetdist.reverse(function(a, b) {

					if (a.name < b.name)
						return -1;
					if (a.name > b.name)
						return 1;
					return 0;
				});
				// zonegetdist.push({
				// name : "All",
				// code : "All"
				// });

				testValsn = {};

				array.forEach(zonegetdist, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selectdisSAP.add(option, 0);
						}
					}
				}));
				document.getElementById("disSAPname").value = "";

			});
		},
		distcrpsapchange : function() {

			zonegettal = [];
			var values = [];
			var testVals = {};

			view.graphics.removeAll();

			cropnamesap = document.getElementById("cropSAPname").value;
			distSapName = document.getElementById("disSAPname").value;
			selecttalSap = document.getElementById("talSAPname");
			document.getElementById("datelive1").value = "";
			document.getElementById("datelive2").value = "";

			while (selecttalSap.firstChild) {
				selecttalSap.removeChild(selecttalSap.firstChild);
			}

			queryTaskdiv = new QueryTask(this.cropsap2019drop);

			var query = new Query();
			query.outFields = ["thname", "thncode"];
			query.returnGeometry = false;
			query.returnDistinctValues = true;

			for (var i = 0; i < zonegetdist.length; i++) {
				if (zonegetdist[i].name === distSapName) {
					distrcitCode = zonegetdist[i].code;
				}
			}

			if (cropnamesap === "All" && distSapName === "All") {
				query.where = "dtncode = '" + distrcitCode + "' ";
				zonegettal.push({
					name : "All",
					code : "All"
				});
				testValsn = {};

				array.forEach(zonegettal, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							selecttalSap.add(option, 0);
						}
					}
				}));
				document.getElementById("talSAPname").value = "";
			} else {

				query.where = "dtncode = '" + distrcitCode + "'";
				queryTaskdiv.execute(query).then(function(featureset) {

					var result = featureset.features;

					array.forEach(result, lang.hitch(this, function(value) {

						talname = value.attributes.thname;
						talcode = value.attributes.thncode;

						if (talname) {
							if (!testVals[talname]) {
								testVals[talname] = true;
								zonegettal.push({
									name : talname,
									code : talcode
								});
							}
						}
					}));

					console.log(zonegettal);

					zonegettal.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zonegettal.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});

					testValsn = {};

					array.forEach(zonegettal, lang.hitch(this, function(vals) {

						if (vals.name) {
							if (!testValsn[vals.name]) {
								testValsn[vals.name] = true;

								var option = document.createElement('option');
								option.text = option.value = vals.name;
								selecttalSap.add(option, 0);
							}
						}
					}));
					document.getElementById("talSAPname").value = "";

				});
			}
		},

		cropcondition : function() {
			var values = [];
			var testVals = {};
			zF = [];

			view.graphics.removeAll();

			cropnamesap = document.getElementById("cropSAPname").value;
			distSapName = document.getElementById("disSAPname").value;
			selecttalSap = document.getElementById("talSAPname").value;
			cropcondition = document.getElementById("conSAPname");

			document.getElementById("datelive1").value = "";
			document.getElementById("datelive2").value = "";

			while (cropcondition.firstChild) {
				cropcondition.removeChild(cropcondition.firstChild);
			}

			queryTaskdiv = new QueryTask(this.cropsap2019);

			var query = new Query();
			query.outFields = ["district", "taluka", "crop_name", "crop_condition"];
			query.returnGeometry = false;
			query.returnDistinctValues = true;
			if (cropnamesap === "All" && distSapName === "All" && selecttalSap === "All") {
				query.where = "crop_name <> '' and district <> '' and taluk <> ''";
				zonegetcon.push({
					name : "All",
					code : "All"
				});
				testValsn = {};

				array.forEach(zonegetcon, lang.hitch(this, function(vals) {

					if (vals.name) {
						if (!testValsn[vals.name]) {
							testValsn[vals.name] = true;

							var option = document.createElement('option');
							option.text = option.value = vals.name;
							cropcondition.add(option, 0);
						}
					}
				}));
				document.getElementById("conSAPname").value = "";
			} else {

				if (cropnamesap != "All" && distSapName === "All" && selecttalSap === "All") {
					query.where = "crop_name ='" + cropnamesap + "' and district <> '' and taluka <> '' ";
				} else if (cropnamesap === "All" && distSapName != "All" && selecttalSap === "All") {
					query.where = "crop_name <>'' and district = '" + distSapName + "' and taluka <> ''";
				} else if (cropnamesap === "All" && distSapName === "All" && selecttalSap != "All") {
					query.where = "crop_name <> '' and district <> '' and taluka ='" + selecttalSap + "'";
				} else if (cropnamesap != "All" && distSapName != "All" && selecttalSap === "All") {
					query.where = "crop_name ='" + cropnamesap + "' and district ='" + distSapName + "' and district <> ''";
				} else if (cropnamesap === "All" && distSapName != "All" && selecttalSap != "All") {
					query.where = "crop_name <> '' and district ='" + distSapName + "' and taluka ='" + selecttalSap + "'";
				} else if (cropnamesap != "All" && distSapName === "All" && selecttalSap != "All") {
					query.where = "crop_name ='" + cropnamesap + "' and district <> '' and taluka = '" + selecttalSap + "'";
				} else if (cropnamesap != "All" && distSapName != "All" && selecttalSap != "All") {
					query.where = "crop_name ='" + cropnamesap + "' and district ='" + distSapName + "' and taluka ='" + selecttalSap + "'";
				}

				queryTaskdiv.execute(query).then(function(featureset) {

					var result = featureset.features;

					array.forEach(result, lang.hitch(this, function(value) {

						talname = value.attributes.crop_condition;

						if (talname) {
							if (!testVals[talname]) {
								testVals[talname] = true;
								zonegetcon.push({
									name : talname
								});
							}
						}
					}));

					zonegetcon.sort(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zonegetcon.reverse(function(a, b) {

						if (a.name < b.name)
							return -1;
						if (a.name > b.name)
							return 1;
						return 0;
					});
					zonegetcon.push({
						name : "All",
						code : "All"
					});

					testValsn = {};

					array.forEach(zonegetcon, lang.hitch(this, function(vals) {

						if (vals.name) {
							if (!testValsn[vals.name]) {
								testValsn[vals.name] = true;

								var option = document.createElement('option');
								option.text = option.value = vals.name;
								cropcondition.add(option, 0);
							}
						}
					}));
					document.getElementById("conSAPname").value = "";

				});
			}

		},
		getLegendDiv : function() {

		},

		clearbutton : function() {
			// alert();
			debugger;
			view.graphics.removeAll();
			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.remove(noncropmask);
			map.remove(layer);
			document.getElementById("cropSAPname").value = "";
			document.getElementById("disSAPname").value = "";
			document.getElementById("talSAPname").value = " ";
			document.getElementById("datelive1").value = " ";
			document.getElementById("datelive2").value = " ";
			document.getElementById("conSAPname").value = "";
			// document.getElementById("year").value = " ";
			dom.byId("cropSapSelect").style.display = 'none';
			dom.byId("cropsownlink").style.display = 'none';
			dom.byId("cropstatlink").style.display = 'none';
			// dom.byId("cropSownCharts").style.display = 'none';
			// dom.byId("Stat").style.display = 'none';
			dom.byId("rowcropSown").style.display = 'none';
			// dom.byId("cropInfoBeg").style.display = 'block';
			document.getElementById("cottonnormal").style.display = 'none';
			document.getElementById("cottonpoor").style.display = 'none';
			document.getElementById("cottonvg").style.display = 'none';
			document.getElementById("gramnormal").style.display = 'none';
			document.getElementById("grampoor").style.display = 'none';
			document.getElementById("gramvg").style.display = 'none';
			document.getElementById("pignormal").style.display = 'none';
			document.getElementById("pigpoor").style.display = 'none';
			document.getElementById("pigvg").style.display = 'none';
			document.getElementById("ricenormal").style.display = 'none';
			document.getElementById("ricepoor").style.display = 'none';
			document.getElementById("ricevg").style.display = 'none';
			document.getElementById("soyanormal").style.display = 'none';
			document.getElementById("soyapoor").style.display = 'none';
			document.getElementById("soyavg").style.display = 'none';

		},
		submitsapbtn : function() {

			document.getElementById("cottonnormal").style.display = 'none';
			document.getElementById("cottonpoor").style.display = 'none';
			document.getElementById("cottonvg").style.display = 'none';
			document.getElementById("gramnormal").style.display = 'none';
			document.getElementById("grampoor").style.display = 'none';
			document.getElementById("gramvg").style.display = 'none';
			document.getElementById("pignormal").style.display = 'none';
			document.getElementById("pigpoor").style.display = 'none';
			document.getElementById("pigvg").style.display = 'none';
			document.getElementById("ricenormal").style.display = 'none';
			document.getElementById("ricepoor").style.display = 'none';
			document.getElementById("ricevg").style.display = 'none';
			document.getElementById("soyanormal").style.display = 'none';
			document.getElementById("soyapoor").style.display = 'none';
			document.getElementById("soyavg").style.display = 'none';

			cropSap = document.getElementById("cropSAPname").value;
			distSap = document.getElementById("disSAPname").value;
			talSap = document.getElementById("talSAPname").value;
			date1 = document.getElementById("datelive1").value;
			date2 = document.getElementById("datelive2").value;
			cropcond = document.getElementById("conSAPname").value;

			dom.byId("mainContent").style.display = 'none';
			if (cropSap == "" || distSap == "" || talSap == "" || date1 == "" || date2 == "") {
				swal("Please select proper input");
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});
				map.basemap = "topo";
				view.graphics.removeAll();
				dom.byId("print").style.display = 'none';
				map.add(featureLayer);
				map.add(noncropmask);
				dom.byId("divLoadingIndicator").style.display = 'none';
			} else {

				for (var i = 0; i < zonegetdist.length; i++) {
					if (zonegetdist[i].name === distSap) {
						distrcitCode = zonegetdist[i].code;
					}
				}
				for (var i = 0; i < zonegettal.length; i++) {
					if (zonegettal[i].name === talSap) {
						talukaCode = zonegettal[i].code;
					}
				}

				cropSAPInfoDisplayArr = [];
				cropSAPInfoDateDisplayArr = [];
				strSAPTableRows = "";
				currentTab = "cropsap";
				layergraphic.graphics.removeAll();
				map.removeAll(featureLayer);
				var zF = [];

				console.log(date1, date2);

				dom.byId("cropsapchart").style.display = 'block';
				// dom.byId("printReport").style.display = 'block';
				dom.byId("legend").style.display = 'block';
				dom.byId("legend1").style.display = 'block';
				dom.byId("print").style.display = 'block';
				//dom.byId("dataTable").style.display = 'block';
				if ( currentTab = "cropsap") {
					//------------------All district Zoom-----------
					if (distSap === "All" && talSap === "All") {
						var queryTaskZm = new QueryTask(this.district);
						var queryZm = new Query();
						queryZm.returnGeometry = true;
						queryZm.outSpatialReference = {
							wkid : 102100
						};
						queryZm.outFields = ["*"];
						queryZm.where = "DTENAME <> ''";

					}//------------------district Zoom-----------
					else if (distSap != "All" && talSap === "All") {
						var queryTaskZm = new QueryTask(this.district);
						var queryZm = new Query();
						queryZm.returnGeometry = true;
						queryZm.outSpatialReference = {
							wkid : 102100
						};
						queryZm.outFields = ["*"];
						queryZm.where = "DTNCODE = '" + distrcitCode + "'";

						//---------------------taluka Zoom----------------
					} else if ((distSap != "All" && talSap != "All") || (distSap === "All" && talSap != "All")) {
						var queryTaskZm = new QueryTask(this.taluka);
						var queryZm = new Query();
						queryZm.returnGeometry = true;
						queryZm.outSpatialReference = {
							wkid : 102100
						};
						queryZm.outFields = ["*"];
						queryZm.where = "DTNCODE = '" + distrcitCode + "' and THNCODE = '" + talukaCode + "'";
					}
					console.log(queryZm.where);
					queryTaskZm.execute(queryZm).then(function(results) {
						var result_features = results.features;
						array.forEach(result_features, lang.hitch(this, function(value) {

							bufgeometry = value.geometry;
							var symbol = {
								type : "simple-line",
								color : "black",
								width : "2px",
								style : "solid"
							};
							var graphic = new Graphic(value.geometry, symbol);
							view.graphics.add(graphic, 0);
							// view.goTo(zF);
							geomextent = value.geometry.extent;

							zF.push(value);

						}));
					});
					//-----------------------------------------Zoom Completed-------------------------------------------------
					var zone = [];
					var values = [];
					var testVal = {};
					var namevalue;

					var crplayer = new FeatureLayer({
						url : this.cropsap2019
					});
					queryTaskdate = new QueryTask(this.cropsap2019);

					var query = new Query();
					query.outFields = ["*"];
					query.returnGeometry = true;
					if (cropcond != "") {
						if (cropSap === "All") {
							if (distSap === "All" && talSap === "All") {
								query.where = "1=1";
							} else if (cropcond != "All" && distSap === "All" && talSap === "All") {
								query.where = "crop_condition ='" + cropcond + "' and district <> '' and taluka <> '' ";
							} else if (cropcond === "All" && distSap != "All" && talSap === "All") {
								query.where = "crop_condition <>'' and district = '" + distSap + "' and taluka <> ''";
							} else if (cropcond != "All" && distSap != "All" && talSap === "All") {
								query.where = "crop_condition ='" + cropcond + "' and district ='" + distSap + "' and district <> ''";
							} else if (cropcond === "All" && distSap != "All" && talSap != "All") {
								query.where = "crop_condition <> '' and district ='" + distSap + "' and taluka ='" + talSap + "'";
							} else if (cropcond != "All" && distSap != "All" && talSap != "All") {
								query.where = "crop_condition ='" + cropcond + "' and district ='" + distSap + "' and taluka ='" + talSap + "'";
							}

						} else if (cropSap != "All") {
							if (distSap === "All" && talSap === "All") {
								query.where = "crop_name ='" + cropSap + "' and district <> '' and taluka <> ''";
							} else if (cropcond === "All" && distSap != "All" && talSap === "All") {
								query.where = "crop_name ='" + cropSap + "' and crop_condition <>'' and district = '" + distSap + "' and taluka <> ''";
							} else if (cropcond != "All" && distSap != "All" && talSap === "All") {
								query.where = "crop_name ='" + cropSap + "' and crop_condition ='" + cropcond + "' and district ='" + distSap + "' and district <> ''";
							} else if (cropcond === "All" && distSap != "All" && talSap != "All") {
								query.where = "crop_name ='" + cropSap + "' and crop_condition <> '' and district ='" + distSap + "' and taluka ='" + talSap + "'";
							} else if (cropcond != "All" && distSap != "All" && talSap != "All") {
								query.where = "crop_name ='" + cropSap + "' and crop_condition ='" + cropcond + "' and district ='" + distSap + "' and taluka ='" + talSap + "'";
							}
						}
					}

					if (cropcond === "") {
						if (cropSap === "All") {
							if (distSap === "All" && talSap === "All") {
								query.where = "crop_name <> '' and district <> '' and taluka <> ''";
							} else if (distSap != "All" && talSap === "All") {
								query.where = "crop_name <> '' and district = '" + distSap + "'";
							} else if (distSap != "All" && talSap != "All") {
								query.where = "crop_name <> '' and district = '" + distSap + "' and taluka = '" + talSap + "'";
							} else if (distSap === "All" && talSap != "All") {
								query.where = "crop_name <> '' and district <> '' and taluka = '" + talSap + "'";
							}
						} else if (cropSap != "All") {
							if (distSap === "All" && talSap === "All") {
								query.where = "crop_name ='" + cropSap + "' and district <> ''";
							} else if (distSap != "All" && talSap === "All") {
								query.where = "crop_name ='" + cropSap + "' and district = '" + distSap + "'";
							} else if (distSap != "All" && talSap != "All") {
								query.where = "crop_name ='" + cropSap + "' and district = '" + distSap + "' and taluka = '" + talSap + "'";
							} else if (distSap === "All" && talSap != "All") {
								query.where = "crop_name ='" + cropSap + "' and district <> '' and taluka = '" + talSap + "'";
							}
						}
					}
					console.log(query.where);
					dom.byId("divLoadingIndicator").style.display = 'block';
					queryTaskdate.execute(query).then(function(featureset) {

						// debugger;
						var result = featureset.features;
						console.log(result);
						if (result.length == 0) {
							swal("Data not Available");
						} else {
							array.forEach(result, lang.hitch(this, function(value) {
								crpName = value.attributes.crop_name;
								cropCond = value.attributes.crop_condition;
								sowdate = value.attributes.sowing_date;
								obvdate = value.attributes.obv_date;
								actdate = new Date(sowdate);
								actdate1 = new Date(obvdate);

								// console.log(actdate);

								var sub = actdate.toString();
								var year = actdate.getFullYear();
								var day = sub.substr(8, 2);
								var mth = sub.substr(4, 3);

								var sub1 = actdate1.toString();
								var year1 = actdate1.getFullYear();
								var day1 = sub1.substr(8, 2);
								var mth1 = sub1.substr(4, 3);

								for (var i = 0; i < 11; i++) {
									if (mth == 'Jan') {
										mth = '01';
									} else if (mth == 'Feb') {
										mth = '02';

									} else if (mth == 'Mar') {
										mth = '03';

									} else if (mth == 'Apr') {
										mth = '04';

									} else if (mth == 'May') {
										mth = '05';

									} else if (mth == 'Jun') {
										mth = '06';

									} else if (mth == 'Jul') {
										mth = '07';

									} else if (mth == 'Aug') {
										mth = '08';

									} else if (mth == 'Sep') {
										mth = '09';

									} else if (mth == 'Oct') {
										mth = '10';

									} else if (mth == 'Nov') {
										mth = '11';

									} else if (mth == 'Dec') {
										mth = '12';

									}
								}

								for (var i = 0; i < 11; i++) {
									if (mth1 == 'Jan') {
										mth1 = '01';
									} else if (mth1 == 'Feb') {
										mth1 = '02';

									} else if (mth1 == 'Mar') {
										mth1 = '03';

									} else if (mth1 == 'Apr') {
										mth1 = '04';

									} else if (mth1 == 'May') {
										mth1 = '05';

									} else if (mth1 == 'Jun') {
										mth1 = '06';

									} else if (mth1 == 'Jul') {
										mth1 = '07';

									} else if (mth1 == 'Aug') {
										mth1 = '08';

									} else if (mth1 == 'Sep') {
										mth1 = '09';

									} else if (mth1 == 'Oct') {
										mth1 = '10';

									} else if (mth1 == 'Nov') {
										mth1 = '11';

									} else if (mth1 == 'Dec') {
										mth1 = '12';

									}
								}

								// console.log(year + "-" + mth + "-" + day);
								var sowingdatefinal = year + "-" + mth + "-" + day;
								var obvdatefinal = year1 + "-" + mth1 + "-" + day1;

								// console.log(sowingdatefinal,"sowingdatefinal");
								// console.log(obvdatefinal,"obvdatefinal");
								// console.log(date1,"date1");
								// console.log(date2,"date2");

								// var yearx = date1.slice(0, 25);

								var yeara = new Date(date1);
								var yearx = yeara.getFullYear();
								var dayx = yeara.getDate();
								// console.log(monthx, "yearx");

								var yearb = new Date(date2);
								var yeary = yearb.getFullYear();
								var dayy = yearb.getDate();

								if (year1 >= yearx) {

									if (day1 >= dayx && day1 <= dayy) {

										if (((obvdatefinal) >= (date1)) && ((obvdatefinal) <= (date2))) {
											if (crpName === "Cotton                                            ") {
												if (cropCond === "Normal              ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/cottonnormal.png",
														width : "10",
														height : "10"
													};
												} else if (cropCond === "Poor                ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/cottonpoor.png",
														width : "10",
														height : "10"
													};
												} else if (cropCond === "Very Good           ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/cottonvg.png",
														width : "13",
														height : "13"
													};
												}
											} else if (crpName === "Gram / Chickpea / Bengal gram                     ") {
												if (cropCond === "Normal              ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/gramnormal.png",
														width : "10",
														height : "10"
													};
												} else if (cropCond === "Poor                ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/grampoor.png",
														width : "10",
														height : "10"
													};
												} else if (cropCond === "Very Good           ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/gramvg.png",
														width : "10",
														height : "10"
													};
												}
											} else if (crpName === "Pigeonpea / Tur                                   ") {
												if (cropCond === "Normal              ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/pignormal.png",
														width : "10",
														height : "10"
													};
												} else if (cropCond === "Poor                ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/pigpoor.png",
														width : "10",
														height : "10"
													};
												} else if (cropCond === "Very Good           ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/pigvg.png",
														width : "13",
														height : "13"
													};
												}
											} else if (crpName === "Rice/ Paddy                                       ") {
												if (cropCond === "Normal              ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/ricenormal.png",
														width : "10",
														height : "10"
													};
												} else if (cropCond === "Poor                ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/ricepoor.png",
														width : "10",
														height : "10"
													};
												} else if (cropCond === "Very Good           ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/ricevg.png",
														width : "13",
														height : "13"
													};
												}
											} else if (crpName === "Soybean                                           ") {
												if (cropCond === "Normal              ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/soyanormal.png",
														width : "10",
														height : "10"
													};
												} else if (cropCond === "Poor                ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/soyapoor.png",
														width : "10",
														height : "10"
													};
												} else if (cropCond === "Very Good           ") {
													var symbolpo = {
														type : "picture-marker",
														url : "img/cropsapnpv/soyavg.png",
														width : "8",
														height : "8"
													};
												}
											}

											if (crpName === "Cotton                                            ") {
												if (cropCond === "Normal              ") {
													document.getElementById("cottonnormal").style.display = "block";
												} else if (cropCond === "Poor                ") {
													document.getElementById("cottonpoor").style.display = "block";
												} else if (cropCond === "Very Good           ") {
													document.getElementById("cottonvg").style.display = "block";
												}
											} else if (crpName === "Gram / Chickpea / Bengal gram                     ") {
												if (cropCond === "Normal              ") {
													document.getElementById("gramnormal").style.display = "block";
												} else if (cropCond === "Poor                ") {
													document.getElementById("grampoor").style.display = "block";
												} else if (cropCond === "Very Good           ") {
													document.getElementById("gramvg").style.display = "block";
												}
											} else if (crpName === "Pigeonpea / Tur                                   ") {
												if (cropCond === "Normal              ") {
													document.getElementById("pignormal").style.display = "block";
												} else if (cropCond === "Poor                ") {
													document.getElementById("pigpoor").style.display = "block";
												} else if (cropCond === "Very Good           ") {
													document.getElementById("pigvg").style.display = "block";
												}
											} else if (crpName === "Rice/ Paddy                                       ") {
												if (cropCond === "Normal              ") {
													document.getElementById("ricenormal").style.display = "block";
												} else if (cropCond === "Poor                ") {
													document.getElementById("ricepoor").style.display = "block";
												} else if (cropCond === "Very Good           ") {
													document.getElementById("ricevg").style.display = "block";
												}
											} else if (crpName === "Soybean                                           ") {
												if (cropCond === "Normal              ") {
													document.getElementById("soyanormal").style.display = "block";
												} else if (cropCond === "Poor                ") {
													document.getElementById("soyapoor").style.display = "block";
												} else if (cropCond === "Very Good           ") {
													document.getElementById("soyavg").style.display = "block";
												}
											}
											var featuregeom = value.geometry;
											values.push(featuregeom);

											cropSAPInfoDisplayArr.push(value);
											cropSAPInfoDateDisplayArr.push([obvdatefinal, sowingdatefinal]);
											//	console.log(cropSAPInfoDisplayArr);
											//  console.log(cropSAPInfoDateDisplayArr);
											if (values.length === 0) {
												dom.byId("divLoadingIndicator").style.display = 'none';
												swal(cropnameselect + "is not Sown in selected Period");
											}

											popuptemp = new PopupTemplate();
											popuptemp.title = "<p style = 'font-size:16px;'>Crop SAP 2019 Information</p>";
											//popuptemp.content = "<p>Cropsap Data Here</p>";
											popuptemp.content = "<table style='height: 100%;width: 100%;'>\n\<tr style='font-size: 13px'><td style='background-color: #e5f1fa;font-weight: bold ;padding-left: 10px;'>Farm Unique Code</td><td style = ''></td><td style='    padding-left: 10px;background-color: #e5f1fa;'>" + value.attributes.farm_unique_code + "</td></tr><tr style='font-size: 13px'><td style='font-weight: bold;background-color: #cde8fd;padding-left: 10px;'>District</td><td></td><td style='background-color: #cde8fd;    padding-left: 10px;'>" + value.attributes.district + "</td></tr><tr style='font-size: 13px'><td style='background-color: #e5f1fa;font-weight: bold;padding-left: 10px;'>Taluka</td><td></td><td style='background-color: #e5f1fa;    padding-left: 10px;'>" + value.attributes.taluka + "</td></tr><tr style='font-size: 13px'><td style='font-weight: bold;background-color: #cde8fd;padding-left: 10px;'>Village</td><td></td><td style='background-color: #cde8fd;    padding-left: 10px;'>" + value.attributes.village + "</td></tr><tr style='font-size: 13px'><td style='background-color: #e5f1fa;font-weight: bold;padding-left: 10px;'>Village Census Code</td><td></td><td style='background-color: #e5f1fa;    padding-left: 10px;'>" + value.attributes.village_census_code + "</td></tr><tr style='font-size: 13px'><td style='font-weight: bold;background-color: #cde8fd;padding-left: 10px;'>Latitude</td><td></td><td style='background-color: #cde8fd;    padding-left: 10px;'>" + value.attributes.latitude + "</td></tr><tr style='font-size: 13px'><td style='background-color: #e5f1fa;font-weight: bold;padding-left: 10px;'>Longitude</td><td></td><td style='background-color: #e5f1fa;    padding-left: 10px;'>" + value.attributes.longitude + "</td></tr><tr style='font-size: 13px'><td style='font-weight: bold;background-color: #cde8fd;padding-left: 10px;'>Area Farm</td><td></td><td style='background-color: #cde8fd;    padding-left: 10px;'>" + value.attributes.area_farm + "</td></tr><tr style='font-size: 13px'><td style='background-color: #e5f1fa;font-weight: bold;padding-left: 10px;'>Farmer Name</td><td></td><td style='background-color: #e5f1fa;    padding-left: 10px;'>" + value.attributes.farmer_name + "</td></tr><tr style='font-size: 13px'><td style='font-weight: bold;background-color: #cde8fd;    padding-left: 10px;'>7/12</td><td></td><td style='background-color: #cde8fd;    padding-left: 10px;'>" + value.attributes.seven_tweleve_farm + "</td></tr><tr style='font-size: 13px'><td style='    padding-left: 10px;background-color: #e5f1fa;font-weight: bold'>Crop Season</td><td></td><td style='    padding-left: 10px;background-color: #e5f1fa;'>" + value.attributes.crop_season + "</td></tr><tr style='font-size: 13px'><td style='font-weight: bold;background-color: #cde8fd;    padding-left: 10px;'>Crop Name</td><td></td><td style='background-color: #cde8fd;    padding-left: 10px;'>" + value.attributes.crop_name + "</td></tr><tr style='font-size: 13px'><td style='    padding-left: 10px;background-color: #e5f1fa;font-weight: bold'>Crop Variety</td><td></td><td style='background-color: #e5f1fa;    padding-left: 10px;'>" + value.attributes.crop_variety + "</td></tr><tr style='font-size: 13px'><td style='font-weight: bold;background-color: #cde8fd;    padding-left: 10px;'>Crop Spacing</td><td></td><td style='background-color: #cde8fd;    padding-left: 10px;'>" + value.attributes.crop_spacing + "</td></tr><tr style='font-size: 13px'><td style='font-weight: bold;background-color:#e5f1fa;    padding-left: 10px;'>Crop Growth Stage</td><td></td><td style='background-color: #e5f1fa;    padding-left: 10px;'>" + value.attributes.crop_growth_stage + "</td></tr><tr style='font-size: 13px'><td style='background-color: #cde8fd;font-weight: bold;    padding-left: 10px;'>Crop Condition</td><td></td><td style='background-color: #cde8fd;    padding-left: 10px;'>" + value.attributes.crop_condition + "</td></tr><tr style='font-size: 13px'><td style='background-color: #e5f1fa;font-weight: bold;    padding-left: 10px;'>Soil Type</td><td></td><td style='background-color: #e5f1fa;    padding-left: 10px;'>" + value.attributes.soil_type + "</td></tr><tr style='font-size: 13px;'><td style='font-weight: bold;background-color: #cde8fd;    padding-left: 10px;'>Irrigated Rainfed</td><td></td><td style='background-color: #cde8fd;    padding-left: 10px;'>" + value.attributes.irrigated_rainfed + "</td></tr><tr style='font-size: 13px;'><td style='background-color: #e5f1fa;font-weight: bold;    padding-left: 10px;'>Survey Code</td><td></td><td style='background-color: #e5f1fa;    padding-left: 10px;'>" + value.attributes.survey_code + "</td></tr></table>";
											// console.log(popuptemp.content);
											view.popup.autoOpenEnabled = true;
											grphcNA = new Graphic({
												geometry : featuregeom,
												symbol : symbolpo,
												popupTemplate : popuptemp
											});
											layergraphic.graphics.add(grphcNA);
											map.add(layergraphic);
										}
									}
								}
							}));

						}

						tablebody = document.getElementById("tableBodyCropSap");
						$("#dataTable tbody").empty();

						if (tableIterationFlag == true) {

							for (var i = 0; i < cropSAPInfoDisplayArr.length; i++) {
								$("#dataTable tbody").append("<tr><td style='color: #514a4a;text-align: right;font-size: 11px;'>" + (i + 1) + "<td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.village + "</td><td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.farmer_name + "<td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.seven_tweleve_farm + "</td><td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.crop_name + "<td style='text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.crop_variety + "</td><td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.crop_spacing + "<td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDateDisplayArr[i][1] + "</td><td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.crop_growth_stage + "<td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.crop_condition + "</td><td style='color:#514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.soil_type + "<td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.irrigated_rainfed + "</td><td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDateDisplayArr[i][0] + "</td></tr>");
							}
							dataTableObj = $('#dataTable').DataTable({
								"buttons" : ['print'],
								"scrollY" : 150
							});
							$("#dataTable").on('click', 'tbody td', function() {
								// $("#dataTable").on("click", function() {
								var data = dataTableObj.row(this).data();
								//alert(this.textContent);
							});
							tableIterationFlag = false;
						} else {

							$("#dataTable tbody").empty();
							dataTableObj.clear();
							dataTableObj.destroy();
							for (var i = 0; i < cropSAPInfoDisplayArr.length; i++) {
								$("#dataTable tbody").append("<tr><td style='color: #514a4a;text-align: right;font-size: 11px;'>" + (i + 1) + "<td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.village + "</td><td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.farmer_name + "<td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.seven_tweleve_farm + "</td><td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.crop_name + "<td style='text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.crop_variety + "</td><td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.crop_spacing + "<td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDateDisplayArr[i][1] + "</td><td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.crop_growth_stage + "<td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.crop_condition + "</td><td style='text-align: left;font-size: 11px;color:#514a4a;'>" + cropSAPInfoDisplayArr[i].attributes.soil_type + "<td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDisplayArr[i].attributes.irrigated_rainfed + "</td><td style='color: #514a4a;text-align: left;font-size: 11px;'>" + cropSAPInfoDateDisplayArr[i][0] + "</td></tr>");
							}
							dataTableObj = $('#dataTable').DataTable({
								"buttons" : ['print'],
								"scrollY" : 150
							});
							$("#dataTable").on('click', 'tbody td', function() {
								// $("#dataTable").on("click", function() {
								var data = dataTableObj.row(this).data();
								//alert(data);
							});
						}

						// dom.byId("floatingmenu").style.display = 'block';
						// dom.byId("floatingmenu").style.bottom = '0px';
						// dom.byId("viewDiv").style.height = '67%';
						dom.byId("divLoadingIndicator").style.display = 'none';
						view.goTo(zF);
					});
				}
			}
		},

		generatemap : function() {
			dom.byId("divLoadingIndicator").style.display = 'block';
			cropSap = document.getElementById("cropSAPname").value;
			distSap = document.getElementById("disSAPname").value;
			talSap = document.getElementById("talSAPname").value;
			date1 = document.getElementById("datelive1").value;
			date2 = document.getElementById("datelive2").value;
			cropcond = document.getElementById("conSAPname").value;

			for (var i = 0; i < zonegetdist.length; i++) {
				if (zonegetdist[i].name === distSap) {
					distrcitCode = zonegetdist[i].code;
				}
			}
			for (var i = 0; i < zonegettal.length; i++) {
				if (zonegettal[i].name === talSap) {
					talukaCode = zonegettal[i].code;
				}
			}

			console.log(zonegettal);
			var str1 = "Normal";
			var str2 = "Very Good";
			var str3 = "Poor";

			if (cropcond === "" || cropcond === "All") {

				cropcond = str1.concat(",", str2, ",", str3);

			}

			var st1 = "Cotton";
			var st2 = "Soybean";
			var st3 = "Pigeonpea / Tur";
			var st4 = "Rice/ Paddy";
			var st5 = "Gram / Chickpea / Bengal gram";

			if (cropSap === "All" || cropSap === "") {

				cropSap = st1.concat(",", st2, ",", st3, ",", st4, ",", st5);

			}

			var myarray = date1.concat(",", date2);
			console.log(myarray);
			var gpUrl = "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agritechcrpsap/GPServer/agritechcrpsap";
			var gp = new Geoprocessor(gpUrl);

			var parameters = {
				district : distSap,
				taluka : talSap,
				dist_cd : distrcitCode,
				tal_cd : talukaCode,
				crop_name : cropSap,
				date : myarray,
				crop_condition : cropcond
			};

			console.log(parameters);
			gp.execute(parameters).then(ShowResultData);

			function ShowResultData(result) {
				// alert(result);
				console.log(result.results[0].value);
				var resultImg = result.results[0].value.url;
				var center_left = (screen.width / 2.5) - (400 / 2);
				var center_top = (screen.height / 2.5) - (400 / 2);
				window.open(resultImg, target = '_blank', 'width=1000,height=750, top=' + center_top + ', left=' + center_left);
				dom.byId("divLoadingIndicator").style.display = 'none';
			}

		},

		clear : function() {

			view.graphics.removeAll();
			view.when(function(evt) {
				this.initExtent = new Extent({
					"xmin" : 68.9995834543952,
					"ymin" : 14.9995834301808,
					"xmax" : 85.0004167877285,
					"ymax" : 23.0004167635141,
					"spatialReference" : {
						"wkid" : 4326
					}
				});
				view.extent = this.initExtent;
			});
			map.removeAll(this.cropsap2019);
			dom.byId("mainContent").style.display = 'none';
			document.getElementById("cropSAPname").value = "";
			document.getElementById("disSAPname").value = "";
			document.getElementById("talSAPname").value = "";
			document.getElementById("datelive1").value = "";
			document.getElementById("datelive2").value = "";
			document.getElementById("conSAPname").value = "";

			dom.byId("legend").style.display = 'none';
			dom.byId("legend1").style.display = 'none';
			// dom.byId("floatingmenu").style.display = 'none';
			// dom.byId("floatingmenu").style.bottom = '0px';
			// dom.byId("viewDiv").style.height = '95%';

			// dom.byId("cropsapchart").style.display = 'none';
			featureLayer = new MapImageLayer({
				url : "https://portal.mrsac.org.in/webadpgis8/rest/services/agriculture/agriculture_admin_bnd/MapServer",
				outFields : ["*"],
				mode : FeatureLayer.MODE_ONDEMAND,
			});
			map.add(featureLayer);
			map.add(noncropmask);

		},

		ViewReport : function() {
			debugger;
			cropSap = document.getElementById("cropSAPname").value;
			distSap = document.getElementById("disSAPname").value;
			talSap = document.getElementById("talSAPname").value;
			date1 = document.getElementById("datelive1").value;
			date2 = document.getElementById("datelive2").value;
			cropcond = document.getElementById("conSAPname").value;

			if (cropSap == "" || distSap == "" || talSap == "" || date1 == "" || date2 == "") {
				swal("Please select proper input");
				view.when(function(evt) {
					this.initExtent = new Extent({
						"xmin" : 68.9995834543952,
						"ymin" : 14.9995834301808,
						"xmax" : 85.0004167877285,
						"ymax" : 23.0004167635141,
						"spatialReference" : {
							"wkid" : 4326
						}
					});
					view.extent = this.initExtent;
				});
				map.basemap = "topo";
				view.graphics.removeAll();
				dom.byId("print").style.display = 'none';
				map.add(featureLayer);
				map.add(noncropmask);
				dom.byId("divLoadingIndicator").style.display = 'none';
			} else {

				for (var i = 0; i < zonegetdist.length; i++) {
					if (zonegetdist[i].name === distSap) {
						distrcitCode = zonegetdist[i].code;
					}
				}
				for (var i = 0; i < zonegettal.length; i++) {
					if (zonegettal[i].name === talSap) {
						talukaCode = zonegettal[i].code;
					}
				}
				
				  //var daterep1 = date1.replaceAll("-", "/");
				  
				  //var daterep2 = date2.replaceAll("-", "/");
				  var dateFrom=date1.split("-");
				  var dateTo=date2.split("-");
				  
				  // console.log(dateFrom[0]+"/"+dateFrom[1]+"/"+dateFrom[2]);
				  // console.log(dateTo[0]+"/"+dateTo[1]+"/"+dateTo[2]);
				  
				document.getElementById("mainContent").style.display = "block";
				$("#mainContent").load("http://117.240.213.118:6080/cropacreagereport1/cropconditionhtml?season=Kharif&division_n=All&district_n=" + distSap + "&taluka_n=" + talSap + "&village_n=All&division=All&district=" + distSap + "&taluka=" + talSap + "&village=All&year=All&daterange=" + dateFrom[2]+"/"+dateFrom[1]+"/"+dateFrom[0] + "-" + dateTo[2]+"/"+dateTo[1]+"/"+dateTo[0], function() {

					//alert("Load was performed.");
					$('#datatable').DataTable();
				});

			}

		},
	});
});
