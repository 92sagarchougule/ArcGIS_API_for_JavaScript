var fc_layer;

require(["esri/Map","esri/views/MapView", "esri/layers/FeatureLayer"], (Map, MapView, FeatureLayer) => { /* code goes here */ 


    var map = new Map({
        basemap: "streets-vector"
    });

    var view = new MapView({
        container: "viewDiv",
        map:map,
        center: [72, 18],
        zoom: 5
    });

    // Folder api
    var url = "https://sampleserver6.arcgisonline.com/arcgis/rest/services?f=pjson";
    var xhttp = new XMLHttpRequest();
    xhttp.responseType = 'json';
    // Use 'GET' instead of 'get'
    xhttp.open("GET", url, true);  // Add 'true' for asynchronous request
    xhttp.send();  // No need to pass null for a GET request
    xhttp.onload = function() {
        if (xhttp.status == 200) {  // Check the status, not the response                                                nnnnnnmmmmmmmmmm                                                                                                                                                                
            //console.log(xhttp.response.folders[0]);
            let select = document.getElementById('folder');
            let folder = xhttp.response.folders;
            let a = 0
            for (let val of folder){
                var option = document.createElement('option');
                let b = a+=1
                option.value = b;
                option.text = val;
                select.appendChild(option);
            }

            map.remove(fc_layer);
        } else {
            console.error('Error:', xhttp.status);
        }
    };
    xhttp.onerror = function() {
        console.error('Network error');
    };

    // onchange function for services
    document.getElementById('folder').onchange = function () {
        // code goes here
        document.getElementById('Service').value = 0;
        var folderSelect = document.getElementById('folder');
        var folder_Name = folderSelect.options[folderSelect.selectedIndex].text;
        //console.log(folder_Name);
    
        var url = "https://sampleserver6.arcgisonline.com/arcgis/rest/services/" + folder_Name + "?f=pjson";
        var xhttp = new XMLHttpRequest();
        xhttp.responseType = 'json';
    
        xhttp.open("GET", url, true);
        xhttp.send();
    
        xhttp.onload = function () {
            if (xhttp.status == 200) {
                //console.log(xhttp.response.services);
    
                let select = document.getElementById('Service');
    
                // Clear existing options before adding new ones
                select.innerHTML = '<option value="0">Select Service</option>';
    
                // Iterate over services and add options to the dropdown
                xhttp.response.services.forEach(function (service, index) {
                    var option = document.createElement('option');
                    option.value = index + 1; // Assuming you want the index as the value
                    option.text = service.name;
                    select.appendChild(option);
                });
            } else {
                console.error('Error:', xhttp.status);
            }
        };
    
        xhttp.onerror = function () {
            console.error('Network error');
        };
    };
    

    // onchange function for layers
    document.getElementById('Service').onchange = function () {   
        //document.getElementById('Service').value = 0;
        var ServiceSelect = document.getElementById('Service');
        var Service_Name = ServiceSelect.options[ServiceSelect.selectedIndex].text; // Corrected variable name
        //console.log(Service_Name);

        var url  = "https://sampleserver6.arcgisonline.com/arcgis/rest/services/"+ Service_Name + "/FeatureServer?f=pjson";
        //console.log(url);
        var xhttp = new XMLHttpRequest();
        xhttp.responseType = 'json';
    
        xhttp.open("GET", url);
        xhttp.send();
    
        xhttp.onload = function () {
            if (xhttp.status == 200) {
                //console.log(xhttp.response);
    
                let select = document.getElementById('Layer');
                let Layers = xhttp.response.layers;
                //console.log(Layers);
                
                //Clear existing options before adding new ones
                select.innerHTML = '<option value="0">Select Layer</option>';
                for (let layer of Layers) {
                    var option = document.createElement('option');
                    option.value = layer.id;
                    option.text = layer.name;
                    select.appendChild(option);
                }
            } else {
                console.error('Error:', xhttp.status);
            }
        };
    
        xhttp.onerror = function () {
            console.error('Network error');
        };
    };


    // onchange function for layers
    document.getElementById('Layer').onchange = function () {
        // code goes here
        //alert('working here');
    
        //document.getElementById('Service').value = 0;

        var ServiceSelect = document.getElementById('Service');
        var Service_Name = ServiceSelect.options[ServiceSelect.selectedIndex].text; // Corrected variable name
        //console.log(Service_Name);


        var LayerSelect = document.getElementById('Layer');
        var Layer_Name = LayerSelect.options[LayerSelect.selectedIndex].text; // Corrected variable name
        var Layer_value = document.getElementById('Layer').value;
        //console.log(Layer_Name);

        var url  = "https://sampleserver6.arcgisonline.com/arcgis/rest/services/"+ Service_Name +"/FeatureServer/"+Layer_value+"?f=pjson";

        //console.log(url);
        var xhttp = new XMLHttpRequest();
        xhttp.responseType = 'json';
    
        xhttp.open("GET", url);
        xhttp.send();
    
        xhttp.onload = function () {
            if (xhttp.status == 200) {
                //console.log(xhttp.response);
    
                let select = document.getElementById('Layer');
                let fc_layer = xhttp.response;
                console.log(fc_layer);
                
                //Clear existing options before adding new ones
                // select.innerHTML = '<option value="0">Select Layer</option>';
                // for (let layer of Layers) {
                //     var option = document.createElement('option');
                //     option.value = layer.id;
                //     option.text = layer.name;
                //     select.appendChild(option);
                // }
                
                url = "https://sampleserver6.arcgisonline.com/arcgis/rest/services/Earthquakes_Since1970/FeatureServer/0";

                fc_layer = new FeatureLayer({
                    // URL to the service
                    url: url
                  });

                map.add(fc_layer);



            } else {
                console.error('Error:', xhttp.status);
            }
        };
    
        xhttp.onerror = function () {
            console.error('Network error');
        };
    };


    





});


